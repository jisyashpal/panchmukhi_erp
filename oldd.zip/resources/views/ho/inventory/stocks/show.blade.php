@extends('layouts.ho')
@section('title', $product->name.' — Stock Movements')
@section('content')
@php
    $unit = $product->unit->abbreviation ?? $product->unit->name ?? '';
    $isFilteredPeriod = $dateFrom !== $financialYearRange->dateFrom || $dateTo !== $financialYearRange->dateTo;
    $periodLabel = $isFilteredPeriod
        ? \Carbon\Carbon::parse($dateFrom)->format('d M Y').' – '.\Carbon\Carbon::parse($dateTo)->format('d M Y')
        : $financialYearRange->displayLabel();
@endphp
<x-admin-page-header
    title="{{ $product->name }}"
    subtitle="{{ $site->name }} · {{ $periodLabel }}">
    <a href="{{ route('ho.stocks.index') }}" class="btn btn-admin-outline btn-sm">Back</a>
</x-admin-page-header>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <input type="hidden" name="site_id" value="{{ request('site_id') }}">
        <input type="hidden" name="product_id" value="{{ request('product_id') }}">
        <div class="col-6 col-md-2">
            <label class="form-label small" for="date_from">From</label>
            <input type="date" name="date_from" id="date_from" value="{{ $dateFrom }}"
                min="{{ $financialYearRange->dateFrom }}" max="{{ $financialYearRange->dateTo }}"
                class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small" for="date_to">To</label>
            <input type="date" name="date_to" id="date_to" value="{{ $dateTo }}"
                min="{{ $financialYearRange->dateFrom }}" max="{{ $financialYearRange->dateTo }}"
                class="form-control form-control-sm">
        </div>
        <div class="col-auto d-flex gap-1">
            <button type="submit" class="btn btn-admin-primary btn-sm">
                <i class="bi bi-funnel me-1"></i>Filter
            </button>
            @if($isFilteredPeriod)
                <a href="{{ route('ho.stocks.show', ['site_id' => request('site_id'), 'product_id' => request('product_id')]) }}"
                    class="btn btn-admin-outline btn-sm">Clear</a>
            @endif
        </div>
    </form>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Current Qty</div>
            <div class="h5 mb-0">{{ $balance?->quantity ?? 0 }} {{ $unit }}</div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Stock In</div>
            <div class="h5 mb-0 text-success">{{ $periodStockIn }} {{ $unit }}</div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Stock Out</div>
            <div class="h5 mb-0 text-danger">{{ $periodStockOut }} {{ $unit }}</div>
        </div>
    </div>
</div>

<div class="admin-card admin-table-card">
    <div class="admin-card-header"><h2 class="h6 mb-0">When &amp; where</h2></div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th class="text-end">Qty</th>
                    <th>Where / Source</th>
                    <th>Notes</th>
                    <th>By</th>
                </tr>
            </thead>
            <tbody>
                @forelse($movements as $m)
                <tr>
                    <td>{{ $m->moved_at->format('d M Y H:i') }}</td>
                    <td>
                        @if($m->type === \App\Enums\StockMovementType::In)
                            <span class="badge bg-success-subtle text-success">In</span>
                        @else
                            <span class="badge bg-danger-subtle text-danger">Out</span>
                        @endif
                    </td>
                    <td class="text-end">{{ $m->quantity }} {{ $unit }}</td>
                    <td>
                        @if($m->type === \App\Enums\StockMovementType::In)
                            @if($m->reference_type === \App\Enums\StockReferenceType::Purchase && $m->reference_id)
                                PO: {{ $purchaseReferences[$m->reference_id] ?? '#'.$m->reference_id }}
                            @else
                                Stock In
                            @endif
                        @elseif($m->machine)
                            Machine: {{ $m->machine->name }} ({{ $m->machine->code }})
                        @elseif(filled($m->reason))
                            Other / site use — {{ $m->reason }}
                        @else
                            —
                        @endif
                    </td>
                    <td class="text-muted small">{{ $m->notes ?? '—' }}</td>
                    <td class="text-muted small">{{ $m->performer?->name ?? '—' }}</td>
                </tr>
                @empty
                <tr>
                    <td colspan="6">
                        <div class="admin-empty">No movements for {{ $periodLabel }}</div>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">{{ $movements->links() }}</div>
@endsection
