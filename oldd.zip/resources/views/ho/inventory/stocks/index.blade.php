@extends('layouts.ho')
@section('title', 'Stocks')
@section('content')
<x-admin-page-header title="Stocks" subtitle="Current balances and {{ $financialYearRange->displayLabel() }} movement summary">
    <a href="{{ route('ho.stocks.stock-in') }}" class="btn btn-success btn-sm me-1">
        <i class="bi bi-box-arrow-in-down me-1"></i>Stock In
    </a>
    <a href="{{ route('ho.stocks.stock-out') }}" class="btn btn-warning btn-sm">
        <i class="bi bi-box-arrow-up me-1"></i>Stock Out
    </a>
</x-admin-page-header>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-md-3">
            <label class="form-label small">Site</label>
            <select name="site_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All sites</option>
                @foreach($sites as $s)
                    <option value="{{ $s->id }}" @selected(request('site_id') == $s->id)>{{ $s->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-12 col-md-3 position-relative">
            <label class="form-label small">Search Item Name / SKU</label>
            <input type="text" name="search" id="product-search" value="{{ request('search') }}" class="form-control form-control-sm" placeholder="Enter item name or SKU..." autocomplete="off">
            <div id="autocomplete-suggestions" class="autocomplete-suggestions d-none shadow border rounded-bottom bg-white"></div>
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label small">Filter by Product</label>
            <select name="product_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All products</option>
                @foreach($products as $p)
                    <option value="{{ $p->id }}" @selected(request('product_id') == $p->id)>{{ $p->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            @if(request()->anyFilled(['site_id', 'product_id', 'search']))
                <a href="{{ route('ho.stocks.index') }}" class="btn btn-admin-outline btn-sm">Clear</a>
            @endif
        </div>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Site</th>
                    <th>Product</th>
                    <th class="text-end">Current Qty</th>
                    <th class="text-end">FY Stock In</th>
                    <th class="text-end">FY Stock Out</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($balances as $b)
                <tr>
                    <td>{{ $b->site->name }}</td>
                    <td class="fw-semibold">{{ $b->product->name }}</td>
                    <td class="text-end">{{ $b->quantity }} {{ $b->product->unit->abbreviation ?? '' }}</td>
                    <td class="text-end text-success">{{ $b->fy_stock_in }} {{ $b->product->unit->abbreviation ?? '' }}</td>
                    <td class="text-end text-danger">{{ $b->fy_stock_out }} {{ $b->product->unit->abbreviation ?? '' }}</td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('ho.stocks.show', ['site_id' => $b->site_id, 'product_id' => $b->product_id]) }}"
                            class="btn btn-sm btn-admin-outline" title="View movements">
                            <i class="bi bi-eye"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6">
                        <div class="admin-empty"><i class="bi bi-boxes d-block"></i>No stock activity found for {{ $financialYearRange->displayLabel() }}</div>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">{{ $balances->links() }}</div>

@push('scripts')
<style>
.autocomplete-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    max-height: 250px;
    overflow-y: auto;
    z-index: 1050;
    margin-top: 2px;
}
.suggestion-item {
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}
.suggestion-item:hover {
    background-color: #f8f9fa;
}
.suggestion-item:last-child {
    border-bottom: none !important;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('product-search');
    const suggestionsBox = document.getElementById('autocomplete-suggestions');
    const products = @json($products->map(fn($p) => ['id' => $p->id, 'name' => $p->name, 'sku' => $p->sku]));

    searchInput.addEventListener('input', function() {
        const val = this.value.trim().toLowerCase();
        suggestionsBox.innerHTML = '';
        
        if (!val) {
            suggestionsBox.classList.add('d-none');
            return;
        }
        
        const filtered = products.filter(p => 
            p.name.toLowerCase().includes(val) || 
            (p.sku && p.sku.toLowerCase().includes(val))
        ).slice(0, 10);
        
        if (filtered.length === 0) {
            suggestionsBox.classList.add('d-none');
            return;
        }
        
        filtered.forEach(p => {
            const div = document.createElement('div');
            div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
            div.innerHTML = `<span class="fw-semibold text-dark d-block text-truncate" style="max-width:100%">${p.name}</span> <span class="text-muted small">${p.sku}</span>`;
            div.addEventListener('click', function() {
                searchInput.value = p.name;
                suggestionsBox.classList.add('d-none');
                searchInput.form.submit();
            });
            suggestionsBox.appendChild(div);
        });
        
        suggestionsBox.classList.remove('d-none');
    });

    // Hide dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
            suggestionsBox.classList.add('d-none');
        }
    });
});
</script>
@endpush
@endsection
