@props([
    'compact' => false,
    'name' => 'fy',
    'selected' => null,
    'formMethod' => null,
    'formAction' => null,
])

@php
    $selected = $selected ?? ($financialYear->label ?? null);
    $options = $financialYearOptions ?? [];
@endphp

@if($formAction)
    <form method="{{ $formMethod ?? 'POST' }}" action="{{ $formAction }}" class="d-inline">
        @csrf
@endif

<select
    name="{{ $name }}"
    class="form-select {{ $compact ? 'form-select-sm' : '' }} financial-year-select"
    @if($formAction) onchange="this.form.submit()" @endif
    {{ $attributes }}
>
    @foreach($options as $value => $label)
        <option value="{{ $value }}" @selected($selected === $value)>{{ $label }}</option>
    @endforeach
</select>

@if($formAction)
    </form>
@endif
