<?php $__env->startSection('title', $product->name.' — Stock Movements'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $unit = $product->unit->abbreviation ?? $product->unit->name ?? '';
    $isFilteredPeriod = $dateFrom !== $financialYearRange->dateFrom || $dateTo !== $financialYearRange->dateTo;
    $periodLabel = $isFilteredPeriod
        ? \Carbon\Carbon::parse($dateFrom)->format('d M Y').' – '.\Carbon\Carbon::parse($dateTo)->format('d M Y')
        : $financialYearRange->displayLabel();
?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => ''.e($product->name).'','subtitle' => ''.e($site->name).' · '.e($periodLabel).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($product->name).'','subtitle' => ''.e($site->name).' · '.e($periodLabel).'']); ?>
    <a href="<?php echo e(route('ho.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <input type="hidden" name="site_id" value="<?php echo e(request('site_id')); ?>">
        <input type="hidden" name="product_id" value="<?php echo e(request('product_id')); ?>">
        <div class="col-6 col-md-2">
            <label class="form-label small" for="date_from">From</label>
            <input type="date" name="date_from" id="date_from" value="<?php echo e($dateFrom); ?>"
                min="<?php echo e($financialYearRange->dateFrom); ?>" max="<?php echo e($financialYearRange->dateTo); ?>"
                class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small" for="date_to">To</label>
            <input type="date" name="date_to" id="date_to" value="<?php echo e($dateTo); ?>"
                min="<?php echo e($financialYearRange->dateFrom); ?>" max="<?php echo e($financialYearRange->dateTo); ?>"
                class="form-control form-control-sm">
        </div>
        <div class="col-auto d-flex gap-1">
            <button type="submit" class="btn btn-admin-primary btn-sm">
                <i class="bi bi-funnel me-1"></i>Filter
            </button>
            <?php if($isFilteredPeriod): ?>
                <a href="<?php echo e(route('ho.stocks.show', ['site_id' => request('site_id'), 'product_id' => request('product_id')])); ?>"
                    class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Current Qty</div>
            <div class="h5 mb-0"><?php echo e($balance?->quantity ?? 0); ?> <?php echo e($unit); ?></div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Stock In</div>
            <div class="h5 mb-0 text-success"><?php echo e($periodStockIn); ?> <?php echo e($unit); ?></div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="admin-card admin-card-body">
            <div class="text-muted small">Stock Out</div>
            <div class="h5 mb-0 text-danger"><?php echo e($periodStockOut); ?> <?php echo e($unit); ?></div>
        </div>
    </div>
</div>

<div class="admin-card admin-table-card">
    <div class="admin-card-header"><h2 class="h6 mb-0">When &amp; where</h2></div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th class="text-end">Qty</th>
                    <th>Where / Source</th>
                    <th>Notes</th>
                    <th>By</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->moved_at->format('d M Y H:i')); ?></td>
                    <td>
                        <?php if($m->type === \App\Enums\StockMovementType::In): ?>
                            <span class="badge bg-success-subtle text-success">In</span>
                        <?php else: ?>
                            <span class="badge bg-danger-subtle text-danger">Out</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end"><?php echo e($m->quantity); ?> <?php echo e($unit); ?></td>
                    <td>
                        <?php if($m->type === \App\Enums\StockMovementType::In): ?>
                            <?php if($m->reference_type === \App\Enums\StockReferenceType::Purchase && $m->reference_id): ?>
                                PO: <?php echo e($purchaseReferences[$m->reference_id] ?? '#'.$m->reference_id); ?>

                            <?php else: ?>
                                Stock In
                            <?php endif; ?>
                        <?php elseif($m->machine): ?>
                            Machine: <?php echo e($m->machine->name); ?> (<?php echo e($m->machine->code); ?>)
                        <?php elseif(filled($m->reason)): ?>
                            Other / site use — <?php echo e($m->reason); ?>

                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small"><?php echo e($m->notes ?? '—'); ?></td>
                    <td class="text-muted small"><?php echo e($m->performer?->name ?? '—'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">
                        <div class="admin-empty">No movements for <?php echo e($periodLabel); ?></div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($movements->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/inventory/stocks/show.blade.php ENDPATH**/ ?>