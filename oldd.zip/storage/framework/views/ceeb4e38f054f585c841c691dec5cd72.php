<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'portal' => 'site',
    'menuIdSuffix' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'portal' => 'site',
    'menuIdSuffix' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    use App\Support\MenuBuilder;
    use Illuminate\Support\Str;

    $items = MenuBuilder::visibleItems($portal);
    $menuLabel = MenuBuilder::portalLabel($portal);
?>

<p class="sidebar-menu-label px-2 mb-1"><?php echo e($menuLabel); ?></p>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(($item['type'] ?? 'link') === 'link'): ?>
        <a href="<?php echo e(route($item['route'])); ?>"
            class="sidebar-link <?php echo e(MenuBuilder::isActive($item['routes'] ?? []) ? 'active' : ''); ?>">
            <i class="bi <?php echo e($item['icon']); ?>"></i>
            <span><?php echo e($item['label']); ?></span>
        </a>
    <?php elseif(($item['type'] ?? '') === 'group'): ?>
        <?php
            $groupOpen = MenuBuilder::groupOpen($item);
            $groupId = 'menu-'.$portal.'-'.Str::slug($item['label']).($menuIdSuffix !== '' ? '-'.Str::slug($menuIdSuffix) : '');
        ?>
        <div class="sidebar-menu-group <?php echo e($groupOpen ? 'is-open' : ''); ?>">
            <button class="sidebar-menu-toggle <?php echo e($groupOpen ? '' : 'collapsed'); ?>" type="button"
                data-bs-toggle="collapse" data-bs-target="#<?php echo e($groupId); ?>"
                aria-expanded="<?php echo e($groupOpen ? 'true' : 'false'); ?>">
                <span class="d-flex align-items-center gap-2">
                    <i class="bi <?php echo e($item['icon']); ?>"></i>
                    <span><?php echo e($item['label']); ?></span>
                </span>
                <i class="bi bi-chevron-down sidebar-chevron"></i>
            </button>
            <div class="collapse <?php echo e($groupOpen ? 'show' : ''); ?>" id="<?php echo e($groupId); ?>">
                <div class="sidebar-submenu">
                    <?php $__currentLoopData = $item['children'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route($child['route'])); ?>"
                            class="sidebar-sublink <?php echo e(MenuBuilder::isActive($child['routes'] ?? []) ? 'active' : ''); ?>">
                            <i class="bi <?php echo e($child['icon']); ?>"></i> <?php echo e($child['label']); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (! $__env->hasRenderedOnce('7ebca644-5308-4f62-93df-bf9343be3b71')): $__env->markAsRenderedOnce('7ebca644-5308-4f62-93df-bf9343be3b71'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                document.querySelectorAll('.sidebar-menu-group .collapse').forEach(function (collapseEl) {
                    collapseEl.addEventListener('show.bs.collapse', function () {
                        this.closest('.sidebar-menu-group')?.classList.add('is-open');
                    });
                    collapseEl.addEventListener('hide.bs.collapse', function () {
                        this.closest('.sidebar-menu-group')?.classList.remove('is-open');
                    });
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/components/portal-sidebar-menu.blade.php ENDPATH**/ ?>