<?php

namespace App\Http\Controllers\Ho\Inventory;

use App\Enums\StockMovementType;
use App\Enums\StockReferenceType;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Site;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Support\FinancialYear;
use App\Support\FinancialYearRange;
use App\Support\FinancialYearResolver;
use Illuminate\Http\Request;
use Illuminate\View\View;

class StockController extends Controller
{
    public function index(Request $request): View
    {
        $range = $this->fyRangeFromSession($request);

        $movementSub = StockMovement::query()
            ->select('site_id', 'product_id')
            ->selectRaw(
                'SUM(CASE WHEN type = ? THEN quantity ELSE 0 END) as fy_stock_in',
                [StockMovementType::In->value]
            )
            ->selectRaw(
                'SUM(CASE WHEN type = ? THEN quantity ELSE 0 END) as fy_stock_out',
                [StockMovementType::Out->value]
            )
            ->whereDate('moved_at', '>=', $range->dateFrom)
            ->whereDate('moved_at', '<=', $range->dateTo)
            ->when($request->filled('site_id'), fn ($q) => $q->where('site_id', $request->integer('site_id')))
            ->when($request->filled('product_id'), fn ($q) => $q->where('product_id', $request->integer('product_id')))
            ->groupBy('site_id', 'product_id');

        $balances = StockBalance::with(['site', 'product.unit'])
            ->joinSub($movementSub, 'fy_movements', function ($join) {
                $join->on('stock_balances.site_id', '=', 'fy_movements.site_id')
                    ->on('stock_balances.product_id', '=', 'fy_movements.product_id');
            })
            ->select('stock_balances.*', 'fy_movements.fy_stock_in', 'fy_movements.fy_stock_out')
            ->when($request->filled('search'), function ($q) use ($request) {
                $search = $request->string('search');
                $q->whereHas('product', function ($pq) use ($search) {
                    $pq->where('name', 'like', '%'.$search.'%')
                        ->orWhere('sku', 'like', '%'.$search.'%');
                });
            })
            ->orderBy('stock_balances.site_id')
            ->paginate(30)
            ->withQueryString();

        return view('ho.inventory.stocks.index', [
            'balances' => $balances,
            'sites' => Site::orderBy('name')->get(),
            'products' => Product::orderBy('name')->get(),
            'financialYearRange' => $range,
        ]);
    }

    public function show(Request $request): View
    {
        $data = $request->validate([
            'site_id' => ['required', 'exists:sites,id'],
            'product_id' => ['required', 'exists:products,id'],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
        ]);

        $range = $this->fyRangeFromSession($request);
        $dates = $this->resolveDateFilter($request, $range);
        $site = Site::findOrFail($data['site_id']);
        $product = Product::with('unit')->findOrFail($data['product_id']);

        $balance = StockBalance::where('site_id', $site->id)
            ->where('product_id', $product->id)
            ->first();

        $movements = StockMovement::with(['machine', 'performer'])
            ->where('site_id', $site->id)
            ->where('product_id', $product->id)
            ->whereDate('moved_at', '>=', $dates['from'])
            ->whereDate('moved_at', '<=', $dates['to'])
            ->orderByDesc('moved_at')
            ->paginate(30)
            ->withQueryString();

        $purchaseIds = $movements->getCollection()
            ->filter(fn ($m) => $m->reference_type === StockReferenceType::Purchase && $m->reference_id)
            ->pluck('reference_id')
            ->unique()
            ->values();

        $purchaseReferences = $purchaseIds->isNotEmpty()
            ? Purchase::whereIn('id', $purchaseIds)->pluck('reference_no', 'id')
            : collect();

        $periodStockIn = StockMovement::where('site_id', $site->id)
            ->where('product_id', $product->id)
            ->where('type', StockMovementType::In)
            ->whereDate('moved_at', '>=', $dates['from'])
            ->whereDate('moved_at', '<=', $dates['to'])
            ->sum('quantity');

        $periodStockOut = StockMovement::where('site_id', $site->id)
            ->where('product_id', $product->id)
            ->where('type', StockMovementType::Out)
            ->whereDate('moved_at', '>=', $dates['from'])
            ->whereDate('moved_at', '<=', $dates['to'])
            ->sum('quantity');

        return view('ho.inventory.stocks.show', [
            'site' => $site,
            'product' => $product,
            'balance' => $balance,
            'movements' => $movements,
            'purchaseReferences' => $purchaseReferences,
            'financialYearRange' => $range,
            'dateFrom' => $dates['from'],
            'dateTo' => $dates['to'],
            'periodStockIn' => $periodStockIn,
            'periodStockOut' => $periodStockOut,
        ]);
    }

    private function fyRangeFromSession(Request $request): FinancialYearRange
    {
        $label = app(FinancialYearResolver::class)->ensureSessionDefault($request);
        $fyDates = FinancialYear::range($label);

        return new FinancialYearRange(
            label: $label,
            dateFrom: $fyDates['from']->toDateString(),
            dateTo: $fyDates['to']->toDateString(),
            isManual: false,
        );
    }

    /**
     * @return array{from: string, to: string}
     */
    private function resolveDateFilter(Request $request, FinancialYearRange $fyRange): array
    {
        $from = $request->filled('date_from')
            ? $request->string('date_from')->toString()
            : $fyRange->dateFrom;
        $to = $request->filled('date_to')
            ? $request->string('date_to')->toString()
            : $fyRange->dateTo;

        if ($from < $fyRange->dateFrom) {
            $from = $fyRange->dateFrom;
        }
        if ($to > $fyRange->dateTo) {
            $to = $fyRange->dateTo;
        }
        if ($from > $to) {
            $from = $fyRange->dateFrom;
            $to = $fyRange->dateTo;
        }

        return ['from' => $from, 'to' => $to];
    }
}
