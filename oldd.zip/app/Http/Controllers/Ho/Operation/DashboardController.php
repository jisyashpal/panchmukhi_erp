<?php

namespace App\Http\Controllers\Ho\Operation;

use App\Enums\PurchaseStatus;
use App\Enums\RequestStatus;
use App\Enums\StockMovementType;
use App\Http\Controllers\Controller;
use App\Models\ProductRequest;
use App\Models\Purchase;
use App\Models\PurchaseRequest;
use App\Models\Site;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Support\FinancialYearResolver;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(Request $request): View
    {
        $siteId = $request->integer('site_id') ?: null;
        $resolver = app(FinancialYearResolver::class);
        $range = $resolver->resolve($request);

        $stockQuery = StockBalance::with(['site', 'product']);
        $purchaseQuery = Purchase::query();
        $movementIn = StockMovement::where('type', StockMovementType::In);
        $movementOut = StockMovement::where('type', StockMovementType::Out);
        $productRequestQuery = ProductRequest::query();
        $purchaseRequestQuery = PurchaseRequest::query();

        if ($siteId) {
            $stockQuery->where('site_id', $siteId);
            $purchaseQuery->where('site_id', $siteId);
            $movementIn->where('site_id', $siteId);
            $movementOut->where('site_id', $siteId);
            $productRequestQuery->where('site_id', $siteId);
            $purchaseRequestQuery->where('site_id', $siteId);
        }

        $resolver->applyToQuery($purchaseQuery, 'ordered_at', $request);
        $resolver->applyToQuery($movementIn, 'moved_at', $request);
        $resolver->applyToQuery($movementOut, 'moved_at', $request);
        $resolver->applyToQuery($productRequestQuery, 'created_at', $request);
        $resolver->applyToQuery($purchaseRequestQuery, 'created_at', $request);

        $lowStock = (clone $stockQuery)
            ->join('products', 'products.id', '=', 'stock_balances.product_id')
            ->whereColumn('stock_balances.quantity', '<=', 'products.reorder_level')
            ->select('stock_balances.*')
            ->limit(8)
            ->get();

        $purchaseQtyQuery = Purchase::query()
            ->when($siteId, fn ($q) => $q->where('site_id', $siteId))
            ->join('purchase_items', 'purchase_items.purchase_id', '=', 'purchases.id');
        $resolver->applyToQuery($purchaseQtyQuery, 'purchases.ordered_at', $request);

        return view('ho.operation.dashboard', [
            'sites' => Site::orderBy('name')->get(),
            'siteId' => $siteId,
            'financialYearRange' => $range,
            'totalStockValue' => (clone $stockQuery)->sum('quantity'),
            'pendingOrders' => (clone $purchaseQuery)->where('status', PurchaseStatus::Ordered)->count(),
            'confirmedOrders' => (clone $purchaseQuery)->where('status', PurchaseStatus::Delivered)->count(),
            'totalPurchaseAmount' => (clone $purchaseQuery)->sum('grand_total'),
            'totalPurchaseQty' => $purchaseQtyQuery->sum('purchase_items.quantity'),
            'stockInCount' => (clone $movementIn)->count(),
            'stockOutCount' => (clone $movementOut)->count(),
            'submittedProductRequests' => (clone $productRequestQuery)
                ->where('status', RequestStatus::Submitted)->count(),
            'submittedPurchaseRequests' => (clone $purchaseRequestQuery)
                ->where('status', RequestStatus::Submitted)->count(),
            'lowStock' => $lowStock,
            'topStock' => (clone $stockQuery)->orderByDesc('quantity')->limit(8)->get(),
            'recentPurchases' => (clone $purchaseQuery)->with(['site', 'supplier'])->latest('ordered_at')->limit(5)->get(),
        ]);
    }
}
