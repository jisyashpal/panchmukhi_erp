@extends('layouts.admin')
@section('title', 'Add Sub Category')
@section('content')
<x-admin-page-header title="Add Sub Category" subtitle="Create a sub category under a parent category">
    @include('partials.catalog-create-back', ['fallback' => route('admin.sub-categories.index')])
</x-admin-page-header>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.sub-categories.store') }}">
            @csrf
            @include('partials.catalog-form-return')
            <div class="row g-3">
                <x-admin-form-group label="Category" name="category_id" required>
                    <select name="category_id" id="category_id" class="form-select" required>
                        @foreach($categories as $c)
                            <option value="{{ $c->id }}" @selected(old('category_id', request('category_id')) == $c->id)>{{ $c->name }}</option>
                        @endforeach
                    </select>
                </x-admin-form-group>
                <x-admin-form-input label="Name" name="name" required />
                <div class="col-12">
                    <div class="form-check">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" id="active" @checked(old('is_active', '1') == '1')>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-admin-primary">Save Sub Category</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
