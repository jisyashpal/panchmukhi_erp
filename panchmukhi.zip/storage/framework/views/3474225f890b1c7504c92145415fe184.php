<div class="admin-card mb-4">
    <div class="admin-card-header d-flex align-items-center justify-content-between">
        <h2 class="mb-0">HO comments</h2>
        <span class="badge bg-secondary"><?php echo e($purchase->hoComments->count()); ?></span>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('ho.purchases.comments.store', $purchase)); ?>" class="mb-3">
            <?php echo csrf_field(); ?>
            <label class="form-label small mb-1" for="ho_comment_body">Add comment</label>
            <textarea name="body" id="ho_comment_body" rows="3" class="form-control form-control-sm <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Internal HO note for this purchase order..." maxlength="2000" required><?php echo e(old('body')); ?></textarea>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="btn btn-admin-primary btn-sm mt-2">
                <i class="bi bi-chat-left-text me-1"></i>Post comment
            </button>
        </form>

        <?php if($purchase->hoComments->isEmpty()): ?>
            <p class="small text-muted mb-0">No HO comments yet.</p>
        <?php else: ?>
            <div class="d-flex flex-column gap-3">
                <?php $__currentLoopData = $purchase->hoComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-2 small">
                        <div class="d-flex justify-content-between gap-2 mb-1">
                            <strong><?php echo e($comment->user?->name ?? 'HO User'); ?></strong>
                            <span class="text-muted"><?php echo e($comment->created_at->format('d M Y, H:i')); ?></span>
                        </div>
                        <div class="text-body"><?php echo e($comment->body); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/request-po/purchases/partials/ho-comments.blade.php ENDPATH**/ ?>