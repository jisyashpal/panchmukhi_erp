<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $value = $status instanceof \BackedEnum ? $status->value : (string) $status;
    $class = match($value) {
        'draft' => 'bg-secondary',
        'submitted' => 'bg-info text-dark',
        'in_progress' => 'bg-warning text-dark',
        'completed', 'delivered' => 'bg-success',
        'cancelled' => 'bg-danger',
        'ordered' => 'bg-primary',
        'partial' => 'bg-info text-dark',
        default => 'bg-secondary',
    };
    $label = $status instanceof \BackedEnum && method_exists($status, 'label') ? $status->label() : ucfirst(str_replace('_', ' ', $value));
?>

<span <?php echo e($attributes->merge(['class' => "badge $class"])); ?>><?php echo e($label); ?></span>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/components/status-badge.blade.php ENDPATH**/ ?>