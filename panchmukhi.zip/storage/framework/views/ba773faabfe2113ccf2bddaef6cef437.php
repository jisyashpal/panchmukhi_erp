<?php $__env->startSection('title', 'New Product Request'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'New Product Request','subtitle' => 'Create product request for a plant']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'New Product Request','subtitle' => 'Create product request for a plant']); ?>
    <a href="<?php echo e(route('ho.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('ho.product-requests.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Site</label>
                    <select name="site_id" required class="form-select">
                        <option value="">Select site</option>
                        <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php if(old('site_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <!-- spacing or other fields if any -->
                </div>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Remarks','name' => 'remarks','col' => 'col-md-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Remarks','name' => 'remarks','col' => 'col-md-12']); ?>
                    <textarea name="remarks" class="form-control" rows="2"><?php echo e(old('remarks')); ?></textarea>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
            </div>

            <?php echo $__env->make('partials.request-item-lines', ['products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <button type="submit" class="btn btn-admin-primary mt-3">Submit Request</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/request-po/product-requests/create.blade.php ENDPATH**/ ?>