<?php $__env->startSection('title', 'Edit Product Request #'.$productRequest->id); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Edit Product Request #'.e($productRequest->id).'','subtitle' => 'Rate, quantity, supplier & billing']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Product Request #'.e($productRequest->id).'','subtitle' => 'Rate, quantity, supplier & billing']); ?>
    <a href="<?php echo e(route('ho.product-requests.show', $productRequest)); ?>" class="btn btn-admin-outline btn-sm">Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('ho.product-requests.update', $productRequest)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="admin-card mb-4">
        <div class="admin-card-body">
            <label class="form-label">Remarks</label>
            <textarea name="remarks" class="form-control" rows="2"><?php echo e(old('remarks', $productRequest->remarks)); ?></textarea>
        </div>
    </div>
    <div class="admin-card admin-table-card mb-4">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Supplier</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>GST %</th>
                        <th>Billing Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->name); ?><input type="hidden" name="items[<?php echo e($i); ?>][id]" value="<?php echo e($item->id); ?>"></td>
                        <td>
                            <select name="items[<?php echo e($i); ?>][supplier_id]" class="form-select form-select-sm">
                                <option value="">—</option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>" <?php if(old("items.$i.supplier_id", $item->supplier_id)==$s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td><input type="number" step="0.01" name="items[<?php echo e($i); ?>][quantity]" value="<?php echo e(old("items.$i.quantity", $item->quantity)); ?>" class="form-control form-control-sm" required></td>
                        <td><input type="number" step="0.01" name="items[<?php echo e($i); ?>][unit_price]" value="<?php echo e(old("items.$i.unit_price", $item->unit_price)); ?>" class="form-control form-control-sm"></td>
                        <td><input type="number" step="0.01" name="items[<?php echo e($i); ?>][gst_rate]" value="<?php echo e(old("items.$i.gst_rate", $item->gst_rate)); ?>" class="form-control form-control-sm"></td>
                        <td><input type="text" name="items[<?php echo e($i); ?>][billing_notes]" value="<?php echo e(old("items.$i.billing_notes", $item->billing_notes)); ?>" class="form-control form-control-sm"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <button class="btn btn-primary">Save billing details</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/request-po/product-requests/edit.blade.php ENDPATH**/ ?>