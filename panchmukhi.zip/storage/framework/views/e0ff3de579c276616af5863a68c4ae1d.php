<?php $__env->startSection('title', 'Stock Out'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Stock Out','subtitle' => 'Record site consumption — machine use or other purpose']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock Out','subtitle' => 'Record site consumption — machine use or other purpose']); ?>
    <a href="<?php echo e(route('ho.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('ho.stocks.stock-out.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-card mb-4">
                <div class="admin-card-header"><h2 class="h6 mb-0">Stock details</h2></div>
                <div class="admin-card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label" for="site_id">Site / Plant</label>
                            <select name="site_id" id="site_id" class="form-select form-select-sm" required onchange="location.href='?site_id='+this.value">
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>" <?php if($siteId==$s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="product_id">Product</label>
                            <select name="product_id" id="product_id" class="form-select form-select-sm" required>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>" <?php if(old('product_id')==$p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="quantity">Quantity</label>
                            <input type="number" step="0.01" min="0.01" name="quantity" id="quantity" value="<?php echo e(old('quantity')); ?>" class="form-control form-control-sm" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label d-block">Used for</label>
                            <div class="d-flex flex-wrap gap-3 pt-1">
                                <div class="form-check">
                                    <input type="radio" name="usage_type" value="machine" id="usage_machine" class="form-check-input usage-type-input" <?php if(old('usage_type', 'machine') === 'machine'): echo 'checked'; endif; ?>>
                                    <label class="form-check-label" for="usage_machine">Machine</label>
                                </div>
                                <div class="form-check">
                                    <input type="radio" name="usage_type" value="other" id="usage_other" class="form-check-input usage-type-input" <?php if(old('usage_type') === 'other'): echo 'checked'; endif; ?>>
                                    <label class="form-check-label" for="usage_other">Other / site use</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" id="machine-field">
                            <label class="form-label" for="machine_id">Machine <span class="text-muted fw-normal">(optional)</span></label>
                            <select name="machine_id" id="machine_id" class="form-select form-select-sm">
                                <option value="">— Not linked to a machine —</option>
                                <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->id); ?>" <?php if(old('machine_id')==$m->id): echo 'selected'; endif; ?>><?php echo e($m->name); ?> (<?php echo e($m->code); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($machines->isEmpty() && $siteId): ?>
                                <div class="form-text">No machines for this site. Add them in Admin → Master → Machines.</div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 d-none" id="purpose-field">
                            <label class="form-label" for="reason">Purpose / location <span class="text-danger">*</span></label>
                            <input type="text" name="reason" id="reason" value="<?php echo e(old('reason')); ?>" class="form-control form-control-sm <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Maintenance dept, site office, wastage">
                            <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" id="reason-optional-field">
                            <label class="form-label" for="reason_optional">Notes / reason</label>
                            <input type="text" name="reason" id="reason_optional" value="<?php echo e(old('reason')); ?>" class="form-control form-control-sm" placeholder="Optional">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="admin-card mb-4">
                <div class="admin-card-header"><h2 class="h6 mb-0">Confirmation</h2></div>
                <div class="admin-card-body">
                    <div class="mb-3">
                        <label class="form-label small" for="photo_confirmed">Photo confirmation</label>
                        <select name="photo_confirmed" id="photo_confirmed" class="form-select form-select-sm" required>
                            <option value="1" <?php if(old('photo_confirmed', '1') == '1'): echo 'selected'; endif; ?>>Yes — photo verified</option>
                            <option value="0" <?php if(old('photo_confirmed') === '0'): echo 'selected'; endif; ?>>No</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small" for="photo">Photo upload</label>
                        <input type="file" name="photo" id="photo" accept="image/*" class="form-control form-control-sm">
                    </div>
                    <div>
                        <label class="form-label small" for="notes">Notes</label>
                        <textarea name="notes" id="notes" class="form-control form-control-sm" rows="2" placeholder="Optional"><?php echo e(old('notes')); ?></textarea>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-warning w-100">
                <i class="bi bi-box-arrow-up me-1"></i>Record stock out
            </button>
        </div>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const machineField = document.getElementById('machine-field');
    const purposeField = document.getElementById('purpose-field');
    const reasonOptionalField = document.getElementById('reason-optional-field');
    const reasonRequired = document.getElementById('reason');
    const reasonOptional = document.getElementById('reason_optional');
    const machineSelect = document.getElementById('machine_id');

    function syncUsageFields() {
        const isMachine = document.getElementById('usage_machine').checked;
        machineField.classList.toggle('d-none', !isMachine);
        purposeField.classList.toggle('d-none', isMachine);
        reasonOptionalField.classList.toggle('d-none', !isMachine);

        if (isMachine) {
            reasonRequired.removeAttribute('name');
            reasonRequired.removeAttribute('required');
            reasonOptional.setAttribute('name', 'reason');
            machineSelect.disabled = false;
        } else {
            reasonOptional.removeAttribute('name');
            reasonRequired.setAttribute('name', 'reason');
            reasonRequired.setAttribute('required', 'required');
            machineSelect.disabled = true;
            machineSelect.value = '';
        }
    }

    document.querySelectorAll('.usage-type-input').forEach(function(el) {
        el.addEventListener('change', syncUsageFields);
    });
    syncUsageFields();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/inventory/stocks/stock-out.blade.php ENDPATH**/ ?>