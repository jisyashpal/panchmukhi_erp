<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['products', 'containerId' => 'item-lines']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['products', 'containerId' => 'item-lines']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<h2 class="h6 mt-4 mb-3">Items</h2>
<div id="<?php echo e($containerId); ?>">
    <div class="dynamic-row row g-3 mb-2 align-items-end">
        <?php echo $__env->make('partials.request-item-line-row', ['products' => $products, 'index' => 0], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<button type="button" class="btn btn-sm btn-admin-outline mb-3"
        onclick="addDynamicRow('<?php echo e($containerId); ?>', document.getElementById('item-line-template').innerHTML)">
    + Add line
</button>
<template id="item-line-template">
    <?php echo $__env->make('partials.request-item-line-row', ['products' => $products, 'index' => '__INDEX__'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</template>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/partials/request-item-lines.blade.php ENDPATH**/ ?>