<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['sites' => null, 'products' => null, 'showStatus' => false, 'showDates' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['sites' => null, 'products' => null, 'showStatus' => false, 'showDates' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="admin-filters">
    <form method="GET" class="row g-3 align-items-end">
        <?php if($sites): ?>
            <div class="col-6 col-md-3">
                <label class="form-label">Site</label>
                <select name="site_id" class="form-select form-select-sm">
                    <option value="">All sites</option>
                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($site->id); ?>" <?php if(request('site_id') == $site->id): echo 'selected'; endif; ?>><?php echo e($site->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($products): ?>
            <div class="col-6 col-md-3">
                <label class="form-label">Product</label>
                <select name="product_id" class="form-select form-select-sm">
                    <option value="">All products</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" <?php if(request('product_id') == $product->id): echo 'selected'; endif; ?>><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($showStatus): ?>
            <div class="col-6 col-md-2">
                <label class="form-label">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All</option>
                    <option value="pending" <?php if(request('status') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                    <option value="approved" <?php if(request('status') === 'approved'): echo 'selected'; endif; ?>>Approved</option>
                    <option value="declined" <?php if(request('status') === 'declined'): echo 'selected'; endif; ?>>Declined</option>
                </select>
            </div>
        <?php endif; ?>
        <?php if($showDates): ?>
            <div class="col-6 col-md-2">
                <label class="form-label">From</label>
                <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label">To</label>
                <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="form-control form-control-sm">
            </div>
        <?php endif; ?>
        <div class="col-auto"><?php echo e($slot); ?></div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm">
                <i class="bi bi-funnel me-1"></i>Filter
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/components/list-filters.blade.php ENDPATH**/ ?>