<?php $__env->startSection('title', 'Purchases'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Purchases','subtitle' => 'Track purchase orders — status, supplier and amounts']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Purchases','subtitle' => 'Track purchase orders — status, supplier and amounts']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<div class="admin-filters mb-0">
    <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-md-3">
            <label class="form-label small">Search PO / Supplier</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm"
                placeholder="Reference no. or supplier...">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">Site</label>
            <select name="site_id" class="form-select form-select-sm">
                <option value="">All sites</option>
                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(request('site_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">Status</label>
            <select name="status" class="form-select form-select-sm">
                <option value="">All statuses</option>
                <?php $__currentLoopData = \App\Enums\PurchaseStatus::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->value); ?>" <?php if(request('status') === $status->value): echo 'selected'; endif; ?>><?php echo e($status->label()); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">From date</label>
            <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">To date</label>
            <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->anyFilled(['search', 'site_id', 'status', 'from_date', 'to_date', 'purchase_request_id'])): ?>
                <a href="<?php echo e(route('ho.purchases.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>PO Ref</th>
                    <th>PR #</th>
                    <th>Site</th>
                    <th>Supplier</th>
                    <th class="text-end">Grand total</th>
                    <th>GST</th>
                    <th>Status</th>
                    <th>Ordered</th>
                    <th>HO Comment</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><code class="small"><?php echo e($p->reference_no); ?></code></td>
                    <td>
                        <?php if($p->purchase_request_id): ?>
                            <span class="small text-muted">#<?php echo e($p->purchase_request_id); ?></span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($p->site->name); ?></td>
                    <td>
                        <span class="d-block"><?php echo e($p->supplier->name); ?></span>
                        <?php if($p->supplier->gstin): ?>
                            <small class="text-muted"><?php echo e($p->supplier->gstin); ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="text-end fw-semibold">₹<?php echo e(number_format($p->grand_total, 2)); ?></td>
                    <td class="small">
                        <?php if($p->is_interstate): ?>
                            <span class="badge bg-info-subtle text-info">IGST ₹<?php echo e(number_format($p->total_igst, 2)); ?></span>
                        <?php else: ?>
                            <span class="badge bg-secondary-subtle text-secondary">CGST+SGST</span>
                        <?php endif; ?>
                    </td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $p->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td class="small text-muted"><?php echo e($p->ordered_at?->format('d M Y') ?? '—'); ?></td>
                    <td class="small" style="max-width: 180px;">
                        <?php if($p->latestHoComment): ?>
                            <span class="text-muted d-block text-truncate" title="<?php echo e($p->latestHoComment->body); ?>">
                                <?php echo e(Str::limit($p->latestHoComment->body, 50)); ?>

                            </span>
                            <span class="text-muted" style="font-size: .7rem;"><?php echo e($p->latestHoComment->user?->name); ?> · <?php echo e($p->latestHoComment->created_at->format('d M')); ?></span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end text-nowrap">
                        <button type="button"
                            class="btn btn-sm btn-outline-secondary me-1 btn-ho-comment"
                            data-comment-url="<?php echo e(route('ho.purchases.comments.store', $p)); ?>"
                            data-reference="<?php echo e($p->reference_no); ?>">
                            <i class="bi bi-chat-left-text me-1"></i>Comment
                        </button>
                        <a href="<?php echo e(route('ho.purchases.show', $p)); ?>" class="btn btn-sm btn-admin-outline">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php echo $__env->make('partials.table-empty', ['colspan' => 10, 'icon' => 'bi-receipt', 'message' => 'No purchases found for the selected filters.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($purchases->links()); ?></div>

<div class="modal fade" id="hoPurchaseCommentModal" tabindex="-1" aria-labelledby="hoPurchaseCommentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" id="ho_purchase_comment_form">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="hoPurchaseCommentModalLabel">HO comment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-2">Add internal comment for <strong id="ho_comment_reference">—</strong></p>
                    <label class="form-label small mb-1" for="ho_comment_body_modal">Comment</label>
                    <textarea name="body" id="ho_comment_body_modal" rows="4" class="form-control form-control-sm"
                        placeholder="Write HO note for this PO..." maxlength="2000" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-admin-outline btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-admin-primary btn-sm">
                        <i class="bi bi-send me-1"></i>Save comment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const modalEl = document.getElementById('hoPurchaseCommentModal');
    const form = document.getElementById('ho_purchase_comment_form');
    if (!modalEl || !form) return;

    const modal = new bootstrap.Modal(modalEl);

    document.querySelectorAll('.btn-ho-comment').forEach(function (btn) {
        btn.addEventListener('click', function () {
            form.action = btn.dataset.commentUrl || '';
            document.getElementById('ho_comment_reference').textContent = btn.dataset.reference || '—';
            document.getElementById('ho_comment_body_modal').value = '';
            modal.show();
        });
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/request-po/purchases/index.blade.php ENDPATH**/ ?>