<?php $__env->startSection('title', 'Stocks'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Stocks','subtitle' => 'Current stock balances by site and product']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stocks','subtitle' => 'Current stock balances by site and product']); ?>
    <a href="<?php echo e(route('ho.stocks.stock-in')); ?>" class="btn btn-success btn-sm me-1">
        <i class="bi bi-box-arrow-in-down me-1"></i>Stock In
    </a>
    <a href="<?php echo e(route('ho.stocks.stock-out')); ?>" class="btn btn-warning btn-sm">
        <i class="bi bi-box-arrow-up me-1"></i>Stock Out
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-md-3">
            <label class="form-label small">Site</label>
            <select name="site_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All sites</option>
                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(request('site_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-12 col-md-3 position-relative">
            <label class="form-label small">Search Product / SKU</label>
            <input type="text" name="search" id="product-search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm" placeholder="Enter product name or SKU..." autocomplete="off">
            <div id="autocomplete-suggestions" class="autocomplete-suggestions d-none shadow border rounded-bottom bg-white"></div>
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label small">Filter by Product</label>
            <select name="product_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All products</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(request('product_id') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->anyFilled(['site_id', 'product_id', 'search'])): ?>
                <a href="<?php echo e(route('ho.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Site</th>
                    <th>Product</th>
                    <th class="text-end">Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($b->site->name); ?></td>
                    <td class="fw-semibold"><?php echo e($b->product->name); ?></td>
                    <td class="text-end"><?php echo e($b->quantity); ?> <?php echo e($b->product->unit->abbreviation ?? ''); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">
                        <div class="admin-empty"><i class="bi bi-boxes d-block"></i>No stock records found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($balances->links()); ?></div>

<?php $__env->startPush('scripts'); ?>
<style>
.autocomplete-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    max-height: 250px;
    overflow-y: auto;
    z-index: 1050;
    margin-top: 2px;
}
.suggestion-item {
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}
.suggestion-item:hover {
    background-color: #f8f9fa;
}
.suggestion-item:last-child {
    border-bottom: none !important;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('product-search');
    const suggestionsBox = document.getElementById('autocomplete-suggestions');
    const products = <?php echo json_encode($products->map(fn($p) => ['id' => $p->id, 'name' => $p->name, 'sku' => $p->sku])) ?>;

    searchInput.addEventListener('input', function() {
        const val = this.value.trim().toLowerCase();
        suggestionsBox.innerHTML = '';
        
        if (!val) {
            suggestionsBox.classList.add('d-none');
            return;
        }
        
        const filtered = products.filter(p => 
            p.name.toLowerCase().includes(val) || 
            (p.sku && p.sku.toLowerCase().includes(val))
        ).slice(0, 10);
        
        if (filtered.length === 0) {
            suggestionsBox.classList.add('d-none');
            return;
        }
        
        filtered.forEach(p => {
            const div = document.createElement('div');
            div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
            div.innerHTML = `<span class="fw-semibold text-dark d-block text-truncate" style="max-width:100%">${p.name}</span> <span class="text-muted small">${p.sku}</span>`;
            div.addEventListener('click', function() {
                searchInput.value = p.name;
                suggestionsBox.classList.add('d-none');
                searchInput.form.submit();
            });
            suggestionsBox.appendChild(div);
        });
        
        suggestionsBox.classList.remove('d-none');
    });

    // Hide dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
            suggestionsBox.classList.add('d-none');
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/inventory/stocks/index.blade.php ENDPATH**/ ?>