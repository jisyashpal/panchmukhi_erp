<?php
    $index = $index ?? 0;
    $isTemplate = ($index === '__INDEX__');
?>
<div class="col-md-5">
    <label class="form-label">Product</label>
    <select name="items[<?php echo e($index); ?>][product_id]" required class="form-select form-select-sm">
        <option value="">Select product</option>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> (<?php echo e($p->sku); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-md-4">
    <label class="form-label">Quantity</label>
    <input type="number" step="0.01" name="items[<?php echo e($index); ?>][quantity]" value="1" required class="form-control form-control-sm">
</div>
<div class="col-md-3">
    <label class="form-label d-md-none">&nbsp;</label>
    <button type="button" class="btn btn-sm btn-outline-danger w-100" onclick="removeDynamicRow(this)">Remove</button>
</div>
<?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/partials/request-item-line-row.blade.php ENDPATH**/ ?>