<?php $__env->startSection('title', 'Product Requests'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Requests','subtitle' => 'Edit rate, quantity, supplier and billing details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Requests','subtitle' => 'Edit rate, quantity, supplier and billing details']); ?>
    <a href="<?php echo e(route('ho.product-requests.create')); ?>" class="btn btn-admin-primary btn-sm">
        <i class="bi bi-plus-lg me-1"></i>New Request
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal4f8629a31fde0b992fa0b2c50ac64330 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f8629a31fde0b992fa0b2c50ac64330 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.list-filters','data' => ['sites' => $sites,'products' => $products,'showStatus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('list-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sites' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sites),'products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'showStatus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f8629a31fde0b992fa0b2c50ac64330)): ?>
<?php $attributes = $__attributesOriginal4f8629a31fde0b992fa0b2c50ac64330; ?>
<?php unset($__attributesOriginal4f8629a31fde0b992fa0b2c50ac64330); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f8629a31fde0b992fa0b2c50ac64330)): ?>
<?php $component = $__componentOriginal4f8629a31fde0b992fa0b2c50ac64330; ?>
<?php unset($__componentOriginal4f8629a31fde0b992fa0b2c50ac64330); ?>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Site</th>
                    <th>Requested By</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $productRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>#<?php echo e($pr->id); ?></td>
                    <td class="fw-semibold"><?php echo e($pr->site->name); ?></td>
                    <td><?php echo e($pr->requester?->name ?? 'N/A'); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $pr->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pr->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td><?php echo e($pr->created_at->format('d M Y')); ?></td>
                    <td class="text-end">
                        <div class="d-inline-flex gap-2 align-items-center justify-content-end flex-wrap">
                            <?php if($pr->status === \App\Enums\RequestStatus::Submitted): ?>
                                <span class="badge bg-danger" style="font-size: 0.65rem;">New</span>
                            <?php endif; ?>
                            <?php if($pr->purchaseRequest?->purchases->isNotEmpty()): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">
                                    <i class="bi bi-receipt me-1"></i>PO created
                                </span>
                            <?php endif; ?>
                            <a href="<?php echo e(route('ho.product-requests.show', $pr)); ?>" class="btn btn-sm btn-admin-outline" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="<?php echo e(route('ho.product-requests.edit', $pr)); ?>" class="btn btn-sm btn-primary">Edit</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="admin-empty">No product requests</div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($productRequests->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\panchmukhi\resources\views/ho/request-po/product-requests/index.blade.php ENDPATH**/ ?>