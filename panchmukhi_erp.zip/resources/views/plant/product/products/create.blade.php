@extends('layouts.plant')
@section('title', 'Add Products')
@php
    $catalogReturn = array_filter([
        'redirect' => 'products.create',
        'product_request_id' => request('product_request_id'),
        'product_request_item_id' => request('product_request_item_id'),
        'pc_name' => request('name'),
        'pc_size' => request('size'),
        'pc_sku_code' => request('sku_code'),
        'pc_category_id' => request('category_id'),
        'pc_sub_category_id' => request('sub_category_id'),
        'pc_brand_id' => request('brand_id'),
        'pc_unit_id' => request('unit_id'),
        'pc_reorder_level' => request('reorder_level'),
        'category_id' => request('category_id'),
    ], fn ($value) => $value !== null && $value !== '');
@endphp
@section('content')
    <x-admin-page-header title="Add Products" subtitle="Add new products to the catalog">
        @if(request('product_request_id'))
            <a href="{{ route('plant.product-requests.show', request('product_request_id')) }}" class="btn btn-admin-outline btn-sm"><i
                    class="bi bi-arrow-left me-1"></i>Back to Request</a>
        @else
            <a href="{{ route('plant.products.index') }}" class="btn btn-admin-outline btn-sm"><i
                    class="bi bi-arrow-left me-1"></i>Back</a>
        @endif
    </x-admin-page-header>

    <div class="admin-card">
        <div class="admin-card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if(request('product_request_item_id'))
                <div class="alert alert-info py-2 small mb-3">
                    Creating a catalog product for an unlisted request item. After save it will be linked automatically.
                </div>
            @endif

            <form method="POST" action="{{ route('plant.products.store') }}">
                @csrf
                @if(request('product_request_id'))
                    <input type="hidden" name="product_request_id" value="{{ request('product_request_id') }}">
                @endif
                @if(request('product_request_item_id'))
                    <input type="hidden" name="product_request_item_id" value="{{ request('product_request_item_id') }}">
                @endif
                <div id="products-container" class="mb-3">
                    <!-- Rows injected via javascript -->
                </div>

                <div class="d-flex justify-content-between align-items-center mt-3">
                    <button type="button" class="btn btn-primary btn-sm" id="add-row-btn">
                        <i class="bi bi-plus-lg me-1"></i>Add Product
                    </button>
                    <button type="submit" class="btn btn-admin-primary">Save Products</button>
                </div>
            </form>
        </div>
    </div>

    <template id="product-row-template">
        <div class="product-row-group border rounded p-3 mb-3 bg-light position-relative">
            <button type="button" class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 remove-row-btn"
                title="Remove Product">
                <i class="bi bi-trash"></i>
            </button>

            <!-- Row 1: SKU Code, Name, Size, SKU, Active -->
            <div class="row g-3 mb-3 align-items-end pe-5">
                <div class="col-md-2">
                    <label class="form-label small fw-semibold text-secondary">SKU Code</label>
                    <input type="text" name="products[__INDEX__][sku_code]" class="form-control form-control-sm product-sku-code"
                        maxlength="20" placeholder="SKU only">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-secondary">Item Name <span
                            class="text-danger">*</span></label>
                    <input type="text" name="products[__INDEX__][name]" class="form-control form-control-sm product-name"
                        required placeholder="Item Name">
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-semibold text-secondary">Size/Part</label>
                    <input type="text" name="products[__INDEX__][size]" class="form-control form-control-sm product-size"
                        placeholder="Size/Part">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-secondary">SKU Preview</label>
                    <input type="text" class="form-control form-control-sm product-sku" readonly placeholder="Auto SKU"
                        disabled>
                </div>
                <div class="col-md-2 d-flex align-items-center" style="height: 38px;">
                    <div class="form-check">
                        <input type="hidden" name="products[__INDEX__][is_active]" value="0">
                        <input type="checkbox" name="products[__INDEX__][is_active]" value="1" checked
                            class="form-check-input" id="active___INDEX__">
                        <label class="form-check-label small fw-semibold text-secondary"
                            for="active___INDEX__">Active</label>
                    </div>
                </div>
            </div>

            <!-- Row 2: Category, Item Type, Brand, Unit, Reorder Level -->
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label class="form-label small fw-semibold text-secondary mb-0">Category <span
                                class="text-danger">*</span></label>
                        <a href="{{ route('plant.categories.create', $catalogReturn) }}"
                            class="text-primary small js-create-catalog" data-catalog="category" style="text-decoration: none;">
                            <i class="bi bi-plus-circle me-1"></i>Create
                        </a>
                    </div>
                    <select name="products[__INDEX__][category_id]" class="form-select form-select-sm product-category"
                        required>
                        <option value="">Select category</option>
                        @foreach ($categories as $c)
                            <option value="{{ $c->id }}">{{ $c->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label class="form-label small fw-semibold text-secondary mb-0">Item Type</label>
                        <a href="{{ route('plant.sub-categories.create', $catalogReturn) }}"
                            class="text-primary small js-create-catalog" data-catalog="sub-category" style="text-decoration: none;">
                            <i class="bi bi-plus-circle me-1"></i>Create
                        </a>
                    </div>
                    <select name="products[__INDEX__][sub_category_id]"
                        class="form-select form-select-sm product-subcategory">
                        <option value="">Select Item Type</option>
                        @foreach ($subCategories as $sc)
                            <option value="{{ $sc->id }}" data-category-id="{{ $sc->category_id }}">{{ $sc->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label class="form-label small fw-semibold text-secondary mb-0">Brand</label>
                        <a href="{{ route('plant.brands.create', $catalogReturn) }}"
                            class="text-primary small js-create-catalog" data-catalog="brand" style="text-decoration: none;">
                            <i class="bi bi-plus-circle me-1"></i>Create
                        </a>
                    </div>
                    <select name="products[__INDEX__][brand_id]" class="form-select form-select-sm product-brand">
                        <option value="">—</option>
                        @foreach ($brands as $b)
                            <option value="{{ $b->id }}">{{ $b->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label class="form-label small fw-semibold text-secondary mb-0">Unit <span
                                class="text-danger">*</span></label>
                        <a href="{{ route('plant.units.create', $catalogReturn) }}"
                            class="text-primary small js-create-catalog" data-catalog="unit" style="text-decoration: none;">
                            <i class="bi bi-plus-circle me-1"></i>Create
                        </a>
                    </div>
                    <select name="products[__INDEX__][unit_id]" class="form-select form-select-sm product-unit" required>
                        @foreach ($units as $u)
                            <option value="{{ $u->id }}" @selected(strtolower((string) $u->abbreviation) === 'nos')>{{ $u->name }} ({{ $u->abbreviation }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-semibold text-secondary">Reorder Level <span
                            class="text-danger">*</span></label>
                    <input type="number" name="products[__INDEX__][reorder_level]"
                        class="form-control form-control-sm product-reorder" value="10" min="0" required>
                </div>
            </div>
        </div>
    </template>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const container = document.getElementById('products-container');
                const addRowBtn = document.getElementById('add-row-btn');
                const template = document.getElementById('product-row-template').innerHTML;
                let rowIndex = 0;

                function getOrStoreOriginalOptions(select) {
                    if (!select.originalOptions) {
                        select.originalOptions = Array.from(select.options);
                    }
                    return select.originalOptions;
                }

                function filterSubCategories(row) {
                    const categorySelect = row.querySelector('.product-category');
                    const subCategorySelect = row.querySelector('.product-subcategory');
                    if (!categorySelect || !subCategorySelect) return;

                    const selectedCategoryId = categorySelect.value;
                    const originalOptions = getOrStoreOriginalOptions(subCategorySelect);

                    subCategorySelect.innerHTML = '';
                    
                    if (!selectedCategoryId) {
                        subCategorySelect.disabled = true;
                        const defaultOpt = originalOptions[0].cloneNode(true);
                        defaultOpt.text = 'Select Category First';
                        subCategorySelect.appendChild(defaultOpt);
                        subCategorySelect.value = '';
                        generateRowSku(row);
                        return;
                    }

                    subCategorySelect.disabled = false;
                    subCategorySelect.appendChild(originalOptions[0]); // placeholder

                    originalOptions.slice(1).forEach(option => {
                        if (option.getAttribute('data-category-id') === selectedCategoryId) {
                            subCategorySelect.appendChild(option);
                        }
                    });
                    subCategorySelect.value = '';
                    generateRowSku(row);
                }

                function generateRowSku(row) {
                    const nameInput = row.querySelector('.product-name');
                    const skuCodeInput = row.querySelector('.product-sku-code');
                    const sizeInput = row.querySelector('.product-size');
                    const categorySelect = row.querySelector('.product-category');
                    const subCategorySelect = row.querySelector('.product-subcategory');
                    const brandSelect = row.querySelector('.product-brand');
                    const skuInput = row.querySelector('.product-sku');

                    if (!nameInput || !sizeInput || !categorySelect || !subCategorySelect || !skuInput) return;

                    const categoryOption = categorySelect.options[categorySelect.selectedIndex];
                    const categoryName = (categoryOption && categoryOption.value) ? categoryOption.text : '';
                    const subCategoryOption = subCategorySelect.options[subCategorySelect.selectedIndex];
                    const subCategoryName = (subCategoryOption && subCategoryOption.value) ? subCategoryOption.text : '';
                    const brandOption = brandSelect ? brandSelect.options[brandSelect.selectedIndex] : null;
                    const brandName = (brandOption && brandOption.value) ? brandOption.text : '';

                    const cleanCategory = categoryName.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const cleanSubCategory = subCategoryName.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const cleanSize = sizeInput.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const cleanBrand = brandName.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const cleanSkuCode = skuCodeInput ? skuCodeInput.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase() : '';
                    const cleanName = nameInput.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();

                    const catPart = cleanCategory ? cleanCategory.substring(0, 3) : '';
                    const subPart = cleanSubCategory ? cleanSubCategory.substring(0, 3) : '';
                    const sizePart = cleanSize || '';
                    const brandPart = cleanBrand ? cleanBrand.substring(0, 3) : '';
                    const skuCodePart = cleanSkuCode || '';
                    const namePart = cleanName ? cleanName.substring(0, 3) : '';

                    let sku = catPart;
                    if (subPart) {
                        sku += '_' + subPart;
                    }
                    if (brandPart) {
                        sku += '_' + brandPart;
                    }
                    if (skuCodePart) {
                        sku += '_' + skuCodePart;
                    }
                    if (namePart) {
                        sku += '_' + namePart;
                    }
                    if (sizePart) {
                        sku += '_' + sizePart;
                    }

                    skuInput.value = sku;
                }

                function initializeRow(row) {
                    const categorySelect = row.querySelector('.product-category');
                    const subCategorySelect = row.querySelector('.product-subcategory');
                    const brandSelect = row.querySelector('.product-brand');
                    const nameInput = row.querySelector('.product-name');
                    const skuCodeInput = row.querySelector('.product-sku-code');
                    const sizeInput = row.querySelector('.product-size');

                    if (categorySelect) {
                        categorySelect.addEventListener('change', function () {
                            filterSubCategories(row);
                            generateRowSku(row);
                        });
                        filterSubCategories(row);
                    }

                    if (subCategorySelect) {
                        subCategorySelect.addEventListener('change', function () {
                            generateRowSku(row);
                        });
                    }

                    if (brandSelect) {
                        brandSelect.addEventListener('change', function () {
                            generateRowSku(row);
                        });
                    }

                    if (skuCodeInput) {
                        skuCodeInput.addEventListener('input', function () {
                            generateRowSku(row);
                        });
                    }

                    if (nameInput) {
                        nameInput.addEventListener('input', function () {
                            generateRowSku(row);
                        });
                    }

                    if (sizeInput) {
                        sizeInput.addEventListener('input', function () {
                            generateRowSku(row);
                        });
                    }

                    const removeBtn = row.querySelector('.remove-row-btn');
                    if (removeBtn) {
                        removeBtn.addEventListener('click', function () {
                            const rows = container.querySelectorAll('.product-row-group');
                            if (rows.length > 1) {
                                row.remove();
                            } else {
                                alert('At least one product entry is required.');
                            }
                        });
                    }

                    bindCatalogCreateLinks(row);
                }

                function catalogReturnParams(row) {
                    const params = new URLSearchParams();
                    params.set('redirect', 'products.create');

                    const productRequestId = document.querySelector('input[name="product_request_id"]')?.value;
                    const productRequestItemId = document.querySelector('input[name="product_request_item_id"]')?.value;
                    if (productRequestId) params.set('product_request_id', productRequestId);
                    if (productRequestItemId) params.set('product_request_item_id', productRequestItemId);

                    const values = {
                        pc_name: row.querySelector('.product-name')?.value,
                        pc_size: row.querySelector('.product-size')?.value,
                        pc_sku_code: row.querySelector('.product-sku-code')?.value,
                        pc_category_id: row.querySelector('.product-category')?.value,
                        pc_sub_category_id: row.querySelector('.product-subcategory')?.value,
                        pc_brand_id: row.querySelector('.product-brand')?.value,
                        pc_unit_id: row.querySelector('.product-unit')?.value,
                        pc_reorder_level: row.querySelector('.product-reorder')?.value,
                    };

                    Object.entries(values).forEach(([key, value]) => {
                        if (value) params.set(key, value);
                    });

                    if (values.pc_category_id) {
                        params.set('category_id', values.pc_category_id);
                    }

                    return params;
                }

                function bindCatalogCreateLinks(row) {
                    row.querySelectorAll('.js-create-catalog').forEach((link) => {
                        link.addEventListener('click', function () {
                            const url = new URL(link.getAttribute('href'), window.location.origin);
                            const params = catalogReturnParams(row);
                            params.forEach((value, key) => url.searchParams.set(key, value));
                            link.href = url.pathname + '?' + params.toString();
                        });
                    });
                }

                function addRow() {
                    const html = template.replace(/__INDEX__/g, rowIndex);
                    const div = document.createElement('div');
                    div.className = 'product-row-group border rounded p-3 mb-3 bg-light position-relative';
                    div.setAttribute('data-index', rowIndex);
                    div.innerHTML = html;
                    container.appendChild(div);
                    initializeRow(div);
                    rowIndex++;
                }

                if (addRowBtn) {
                    addRowBtn.addEventListener('click', addRow);
                }

                // Add first row on load
                addRow();

                // Prefill from product-request "Add Product" link
                const prefill = {
                    name: @json(request('name')),
                    size: @json(request('size')),
                    sku_code: @json(request('sku_code')),
                    category_id: @json(request('category_id')),
                    sub_category_id: @json(request('sub_category_id')),
                    brand_id: @json(request('brand_id')),
                    unit_id: @json(request('unit_id')),
                    reorder_level: @json(request('reorder_level')),
                };
                const firstRow = container.querySelector('.product-row-group');
                if (firstRow) {
                    const nameInput = firstRow.querySelector('.product-name');
                    const sizeInput = firstRow.querySelector('.product-size');
                    const skuCodeInput = firstRow.querySelector('.product-sku-code');
                    const categorySelect = firstRow.querySelector('.product-category');
                    const subCategorySelect = firstRow.querySelector('.product-subcategory');
                    const brandSelect = firstRow.querySelector('.product-brand');
                    const unitSelect = firstRow.querySelector('.product-unit');
                    const reorderInput = firstRow.querySelector('.product-reorder');

                    if (prefill.name && nameInput) {
                        nameInput.value = prefill.name;
                    }
                    if (prefill.size && sizeInput) {
                        sizeInput.value = prefill.size;
                    }
                    if (prefill.sku_code && skuCodeInput) {
                        skuCodeInput.value = prefill.sku_code;
                    }
                    if (prefill.category_id && categorySelect) {
                        categorySelect.value = String(prefill.category_id);
                        filterSubCategories(firstRow);
                    }
                    if (prefill.sub_category_id && subCategorySelect) {
                        subCategorySelect.value = String(prefill.sub_category_id);
                    }
                    if (prefill.brand_id && brandSelect) {
                        brandSelect.value = String(prefill.brand_id);
                    }
                    if (prefill.unit_id && unitSelect) {
                        unitSelect.value = String(prefill.unit_id);
                    }
                    if (prefill.reorder_level && reorderInput) {
                        reorderInput.value = prefill.reorder_level;
                    }
                    generateRowSku(firstRow);
                }
            });
        </script>
    @endpush
@endsection