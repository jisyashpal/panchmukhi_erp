<?php

namespace App\Models;

use App\Enums\StockMovementType;
use App\Enums\StockReferenceType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockMovement extends Model
{
    protected $fillable = [
        'plant_id',
        'product_id',
        'supplier_id',
        'sub_category_id',
        'vehicle_id',
        'type',
        'quantity',
        'reference_type',
        'reference_id',
        'performed_by',
        'photo_path',
        'photo_confirmed',
        'reason',
        'notes',
        'moved_at',
    ];

    protected function casts(): array
    {
        return [
            'type' => StockMovementType::class,
            'reference_type' => StockReferenceType::class,
            'quantity' => 'decimal:2',
            'photo_confirmed' => 'boolean',
            'moved_at' => 'datetime',
        ];
    }

    public function plant(): BelongsTo
    {
        return $this->belongsTo(Plant::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function subCategory(): BelongsTo
    {
        return $this->belongsTo(SubCategory::class);
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function performer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'performed_by');
    }
}
