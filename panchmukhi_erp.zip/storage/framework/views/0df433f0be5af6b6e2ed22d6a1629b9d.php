<?php $__env->startSection('title', 'Order Dispatch'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Order Dispatch','subtitle' => 'Set product-wise dispatch date, mark not-provided items, or choose alternatives']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order Dispatch','subtitle' => 'Set product-wise dispatch date, mark not-provided items, or choose alternatives']); ?>
    <div class="btn-group btn-group-sm">
        <a href="<?php echo e(route('plant.dispatch.index')); ?>" class="btn btn-admin-outline <?php if(!request('filter')): ?> active <?php endif; ?>">All</a>
        <a href="<?php echo e(route('plant.dispatch.index', ['filter' => 'pending'])); ?>" class="btn btn-admin-outline <?php if(request('filter')==='pending'): ?> active <?php endif; ?>">Pending</a>
        <a href="<?php echo e(route('plant.dispatch.index', ['filter' => 'dispatched'])); ?>" class="btn btn-admin-outline <?php if(request('filter')==='dispatched'): ?> active <?php endif; ?>">Dispatched</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>PO Ref</th>
                    <?php if($isPurchaser): ?>
                        <th>Plant</th>
                    <?php endif; ?>
                    <th>Supplier</th>
                    <th>Items</th>
                    <th>Status</th>
                    <th>Dispatched</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($p->reference_no); ?></td>
                    <?php if($isPurchaser): ?>
                        <td><?php echo e($p->plant->name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($p->supplier->name); ?></td>
                    <td><?php echo e($p->items->count()); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $p->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td>
                        <?php if($p->dispatched_at): ?>
                            <span class="text-success"><?php echo e($p->dispatched_at->format('d M Y')); ?></span>
                        <?php else: ?>
                            <span class="text-muted">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('plant.dispatch.show', $p)); ?>" class="btn btn-sm <?php echo e($p->dispatched_at ? 'btn-admin-outline' : 'btn-success'); ?>">
                            <i class="bi bi-<?php echo e($p->dispatched_at ? 'eye' : 'truck'); ?> me-1"></i>
                            <?php echo e($p->dispatched_at ? 'View' : 'Dispatch'); ?>

                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="<?php echo e($isPurchaser ? 7 : 6); ?>"><div class="admin-empty">No orders</div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($purchases->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\plant\request-po\dispatch\index.blade.php ENDPATH**/ ?>