<?php $__env->startSection('title', 'Confirm password'); ?>
<?php $__env->startSection('content'); ?>
    <div class="text-center mb-4">
        <h1 class="h4 fw-bold mb-1">Confirm password</h1>
        <p class="text-muted small mb-0">This is a secure area. Please confirm your password to continue.</p>
    </div>

    <form method="POST" action="<?php echo e(route('password.confirm')); ?>">
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Password','name' => 'password','type' => 'password','icon' => 'bi-lock','required' => true,'autofocus' => true,'toggle' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password','name' => 'password','type' => 'password','icon' => 'bi-lock','required' => true,'autofocus' => true,'toggle' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

        <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-shield-check me-1"></i> Confirm
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\auth\confirm-password.blade.php ENDPATH**/ ?>