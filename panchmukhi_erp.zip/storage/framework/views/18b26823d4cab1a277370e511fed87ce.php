<?php $__env->startSection('title', 'Sign in'); ?>
<?php $__env->startSection('content'); ?>
<div class="auth-form-header text-center mb-4">
    <div class="auth-form-logo d-none d-md-flex justify-content-center ">
        <img src="<?php echo e(asset('img/PMCMPL.png')); ?>" alt="Panchmukhi" class="auth-logo-img rounded flex-shrink-0">
    </div>
    <!-- <h1 class="auth-form-title h4 fw-bold mb-2">Welcome back</h1> -->
    <p class="auth-form-subtitle fw-bold  mb-0">Sign in to your account</p>
</div>

<?php if(session('status')): ?>
<div class="alert alert-success auth-form-alert d-flex align-items-start gap-2 mb-4" role="alert">
    <i class="bi bi-check-circle-fill flex-shrink-0 mt-1" aria-hidden="true"></i>
    <span><?php echo e(session('status')); ?></span>
</div>
<?php endif; ?>

<?php echo $__env->make('partials.auth-form-errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<form method="POST" action="<?php echo e(route('login', absolute: false)); ?>" novalidate class="auth-form">
    <?php echo csrf_field(); ?>

    <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Email address','name' => 'email','type' => 'email','icon' => 'bi-envelope','placeholder' => 'you@company.com','required' => true,'autofocus' => true,'autocomplete' => 'username']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email address','name' => 'email','type' => 'email','icon' => 'bi-envelope','placeholder' => 'you@company.com','required' => true,'autofocus' => true,'autocomplete' => 'username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Password','name' => 'password','type' => 'password','icon' => 'bi-lock','placeholder' => 'Enter your password','required' => true,'toggle' => true,'autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password','name' => 'password','type' => 'password','icon' => 'bi-lock','placeholder' => 'Enter your password','required' => true,'toggle' => true,'autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

    <div class="auth-form-actions mb-4">
        <div class="form-check mb-0">
            <input type="checkbox" name="remember" id="remember" class="form-check-input" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="remember">Keep me signed in</label>
        </div>
        <?php if(Route::has('password.request')): ?>
        <a href="<?php echo e(route('password.request')); ?>" class="auth-link small text-nowrap">Forgot password?</a>
        <?php endif; ?>
    </div>

    <div class="d-grid">
        <button type="submit" class="btn btn-primary btn-lg auth-btn-submit">
            <i class="bi bi-box-arrow-in-right me-2" aria-hidden="true"></i>Sign in
        </button>
    </div>
</form>

<!-- <?php if(config('app.debug')): ?>
<div class="auth-demo-hint mt-4">
    <div class="auth-demo-hint-inner small text-center">
        <span class="text-muted">Local demo</span>
        <code>admin@gmail.com</code>
        <span class="text-muted">/</span>
        <code>12345678</code>
    </div>
</div>
<?php endif; ?> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\auth\login.blade.php ENDPATH**/ ?>