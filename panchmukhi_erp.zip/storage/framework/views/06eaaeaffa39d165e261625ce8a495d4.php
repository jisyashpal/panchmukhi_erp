<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['products', 'subCategories', 'categories', 'containerId' => 'item-lines']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['products', 'subCategories', 'categories', 'containerId' => 'item-lines']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<h2 class="h6 mt-4 mb-3">Items</h2>
<div id="<?php echo e($containerId); ?>">
    <div class="dynamic-row row g-3 mb-2 align-items-end">
        <?php echo $__env->make('partials.request-item-line-row', [
            'products' => $products,
            'subCategories' => $subCategories,
            'categories' => $categories,
            'index' => 0
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<button type="button" class="btn btn-sm btn-admin-outline mb-3"
        onclick="addDynamicRow('<?php echo e($containerId); ?>', document.getElementById('item-line-template').innerHTML)">
    + Add line
</button>
<template id="item-line-template">
    <?php echo $__env->make('partials.request-item-line-row', [
        'products' => $products,
        'subCategories' => $subCategories,
        'categories' => $categories,
        'index' => '__INDEX__'
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</template>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    function getOrStoreOriginalOptions(select) {
        if (!select.originalOptions) {
            select.originalOptions = Array.from(select.options);
        }
        return select.originalOptions;
    }

    function filterDropdown(select, attribute, matchValue) {
        const original = getOrStoreOriginalOptions(select);
        select.innerHTML = '';
        
        if (original.length > 0) {
            select.appendChild(original[0]);
        }
        
        original.slice(1).forEach(option => {
            if (!matchValue || option.getAttribute(attribute) === matchValue) {
                select.appendChild(option);
            }
        });
        select.value = '';
    }

    function resetDropdown(select) {
        const original = getOrStoreOriginalOptions(select);
        select.innerHTML = '';
        if (original.length > 0) {
            select.appendChild(original[0]);
        }
        select.value = '';
    }

    function initializeRowFilters(row) {
        const catSelect = row.querySelector('.item-category-select');
        const subCatSelect = row.querySelector('.item-subcategory-select');
        const prodSelect = row.querySelector('.item-product-select');
        
        if (catSelect && subCatSelect && prodSelect) {
            const currentSubCatValue = subCatSelect.value;
            const currentProdValue = prodSelect.value;

            if (!catSelect.value) {
                subCatSelect.disabled = true;
                prodSelect.disabled = true;
            } else {
                subCatSelect.disabled = false;
                filterDropdown(subCatSelect, 'data-category-id', catSelect.value);
                subCatSelect.value = currentSubCatValue;
                
                if (!subCatSelect.value) {
                    prodSelect.disabled = true;
                } else {
                    prodSelect.disabled = false;
                    filterDropdown(prodSelect, 'data-subcategory-id', subCatSelect.value);
                    prodSelect.value = currentProdValue;
                }
            }
        }
    }

    document.addEventListener('change', function (event) {
        const target = event.target;
        if (target.matches('.item-category-select')) {
            const row = target.closest('.dynamic-row');
            const subCatSelect = row.querySelector('.item-subcategory-select');
            const prodSelect = row.querySelector('.item-product-select');
            
            const catId = target.value;
            if (catId) {
                filterDropdown(subCatSelect, 'data-category-id', catId);
                subCatSelect.disabled = false;
            } else {
                resetDropdown(subCatSelect);
                subCatSelect.disabled = true;
            }
            
            resetDropdown(prodSelect);
            prodSelect.disabled = true;
            
        } else if (target.matches('.item-subcategory-select')) {
            const row = target.closest('.dynamic-row');
            const prodSelect = row.querySelector('.item-product-select');
            
            const subCatId = target.value;
            if (subCatId) {
                filterDropdown(prodSelect, 'data-subcategory-id', subCatId);
                prodSelect.disabled = false;
            } else {
                resetDropdown(prodSelect);
                prodSelect.disabled = true;
            }
            
        }
    });

    // Run filters on page load for any pre-populated items
    document.querySelectorAll('.dynamic-row').forEach(row => {
        initializeRowFilters(row);
    });

    // Mutation observer to initialize newly added dynamic rows
    const observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            mutation.addedNodes.forEach(function (node) {
                if (node.nodeType === 1) {
                    if (node.matches('.dynamic-row')) {
                        initializeRowFilters(node);
                    }
                    node.querySelectorAll('.dynamic-row').forEach(row => {
                        initializeRowFilters(row);
                    });
                }
            });
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi\resources\views/partials/request-item-lines.blade.php ENDPATH**/ ?>