<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $profileUpdateRoute = route('admin.profile.update');
    $passwordUpdateRoute = route('admin.password.update');
    $destroyRoute = route('admin.profile.destroy');
?>

<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'My Profile','subtitle' => 'Manage your account settings and security']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Profile','subtitle' => 'Manage your account settings and security']); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-admin-outline btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Dashboard
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-profile-summary admin-card mb-4">
    <div class="admin-card-body d-flex flex-wrap align-items-center gap-3">
        <span class="admin-profile-avatar">
            <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

        </span>
        <div class="flex-grow-1 min-w-0">
            <h2 class="h5 mb-1 text-truncate"><?php echo e($user->name); ?></h2>
            <p class="text-muted small mb-1 text-truncate"><?php echo e($user->email); ?></p>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">Super Admin</span>
        </div>
        <div class="text-muted small">
            <div><i class="bi bi-shield-check me-1"></i>Head Office</div>
            <?php if($user->email_verified_at): ?>
                <div class="text-success mt-1"><i class="bi bi-patch-check me-1"></i>Email verified</div>
            <?php else: ?>
                <div class="text-warning mt-1"><i class="bi bi-exclamation-circle me-1"></i>Email not verified</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <h2><i class="bi bi-person-vcard me-2 text-primary"></i>Profile Information</h2>
    </div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.update-profile-information-form', compact('profileUpdateRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <h2><i class="bi bi-key me-2 text-primary"></i>Update Password</h2>
    </div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.update-password-form', compact('passwordUpdateRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<div class="admin-card border-danger-subtle">
    <div class="admin-card-header">
        <h2 class="text-danger mb-0"><i class="bi bi-trash me-2"></i>Delete Account</h2>
    </div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.delete-user-form', compact('destroyRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\admin\profile\edit.blade.php ENDPATH**/ ?>