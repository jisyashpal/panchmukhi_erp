<?php $__env->startSection('title', 'Multiple Usage Report'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Multiple Usage Highlights','subtitle' => 'Products used more than once — sorted by highest usage count']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Multiple Usage Highlights','subtitle' => 'Products used more than once — sorted by highest usage count']); ?>
    <?php if (isset($component)) { $__componentOriginal936094a68edd25a90036587134359cc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal936094a68edd25a90036587134359cc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-export-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-export-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $attributes = $__attributesOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__attributesOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $component = $__componentOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__componentOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginald01db17e57e28d17475e8f3829de3bd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01db17e57e28d17475e8f3829de3bd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-filters','data' => ['plants' => $plants,'categories' => $categories,'products' => $products,'vehicles' => $vehicles,'showDates' => true,'searchPlaceholder' => 'Product name...','clearRoute' => route('ho.reports.multiple-usage')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['plants' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($plants),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'vehicles' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicles),'show-dates' => true,'search-placeholder' => 'Product name...','clear-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.reports.multiple-usage'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $attributes = $__attributesOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $component = $__componentOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__componentOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>


<?php if($rows->isNotEmpty()): ?>
<div class="admin-stat-grid mb-3">
    <div class="admin-stat-card stat-accent-amber">
        <div class="stat-icon stat-icon-amber"><i class="bi bi-exclamation-diamond"></i></div>
        <div class="stat-label">Flagged Products</div>
        <div class="stat-value"><?php echo e($rows->count()); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-arrow-repeat"></i></div>
        <div class="stat-label">Total Use Entries</div>
        <div class="stat-value"><?php echo e(number_format($rows->sum('use_count'), 0)); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-violet">
        <div class="stat-icon stat-icon-violet"><i class="bi bi-boxes"></i></div>
        <div class="stat-label">Total Qty Consumed</div>
        <div class="stat-value"><?php echo e(number_format($rows->sum('total_qty'), 0)); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-clock-history"></i></div>
        <div class="stat-label">Total Life Used</div>
        <div class="stat-value"><?php echo e(number_format($rows->sum('total_life_hours'), 0)); ?></div>
    </div>
</div>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Category</th>
                    <th class="text-end">Use Count</th>
                    <th class="text-end">Total Qty</th>
                    <th class="text-end">Avg Qty/Use</th>
                    <th class="text-end">Total Life Used</th>
                    <th class="text-end">Avg Life Used</th>
                    <th class="text-end">Plants</th>
                    <th class="text-end">Vehicles</th>
                    <th>Last Used</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-muted"><?php echo e($i + 1); ?></td>
                        <td class="fw-semibold"><?php echo e($r->product_name); ?></td>
                        <td>
                            <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary-subtle">
                                <?php echo e($r->category_name); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <span class="badge <?php echo e($r->use_count >= 5 ? 'bg-danger' : ($r->use_count >= 3 ? 'bg-warning text-dark' : 'bg-info text-dark')); ?>">
                                <?php echo e(number_format($r->use_count, 0)); ?>×
                            </span>
                        </td>
                        <td class="text-end fw-semibold"><?php echo e(number_format($r->total_qty, 0)); ?></td>
                        <td class="text-end text-muted"><?php echo e(number_format($r->avg_qty_per_use, 1)); ?></td>
                        <td class="text-end"><?php echo e(number_format($r->total_life_hours, 0)); ?></td>
                        <td class="text-end text-muted"><?php echo e(number_format($r->avg_life_hours, 1)); ?></td>
                        <td class="text-end"><?php echo e(number_format($r->plant_count, 0)); ?></td>
                        <td class="text-end"><?php echo e(number_format($r->vehicle_count ?? 0, 0)); ?></td>
                        <td class="text-muted text-nowrap">
                            <?php echo e($r->last_used_at ? \Carbon\Carbon::parse($r->last_used_at)->format('d M Y') : '—'); ?>

                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('ho.reports.product-life', array_merge($filters->toQueryArray(), ['product_id' => $r->product_id]))); ?>"
                               class="btn btn-sm btn-outline-primary"
                               title="View full ledger for <?php echo e($r->product_name); ?>">
                                <i class="bi bi-journal-text me-1"></i>Ledger
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo $__env->make('partials.table-empty', [
                        'colspan' => 12,
                        'icon'    => 'bi-exclamation-diamond',
                        'message' => 'No products with multiple usage found for the selected filters.',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </tbody>
            <?php if($rows->isNotEmpty()): ?>
            <tfoot class="table-light fw-bold">
                <tr>
                    <td colspan="3">Total</td>
                    <td class="text-end"><?php echo e(number_format($rows->sum('use_count'), 0)); ?></td>
                    <td class="text-end"><?php echo e(number_format($rows->sum('total_qty'), 0)); ?></td>
                    <td class="text-end text-muted">—</td>
                    <td class="text-end"><?php echo e(number_format($rows->sum('total_life_hours'), 0)); ?></td>
                    <td class="text-end text-muted">—</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\ho\reports\multiple-usage.blade.php ENDPATH**/ ?>