<?php $__env->startSection('title', 'Product Requests'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Requests','subtitle' => $isPurchaser ? 'Product-wise list — select same plant to create PO' : 'Request products for your plant']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Requests','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isPurchaser ? 'Product-wise list — select same plant to create PO' : 'Request products for your plant')]); ?>
    <?php if(auth()->user()->canCreateProductRequests()): ?>
        <a href="<?php echo e(route('plant.product-requests.create')); ?>" class="btn btn-admin-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>New Request
        </a>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <?php echo $__env->make('partials.status-tabs', [
        'route' => 'plant.product-requests.index',
        'param' => 'status',
        'tabs' => [
            ['label' => 'All', 'key' => null],
            ['label' => 'Submitted', 'key' => 'submitted'],
            ['label' => 'In Progress', 'key' => 'in_progress'],
            ['label' => 'Completed', 'key' => 'completed'],
            ['label' => 'Cancelled', 'key' => 'cancelled'],
        ],
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <form method="GET" class="row g-3 mb-3 align-items-end">
        <?php if(request('status')): ?>
            <input type="hidden" name="status" value="<?php echo e(request('status')); ?>">
        <?php endif; ?>
        <?php if($isPurchaser): ?>
        <div class="col-md-3">
            <label class="form-label small">Plant / Site</label>
            <select name="plant_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All plants</option>
                <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plant->id); ?>" <?php if(request('plant_id') == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="col-md-4">
            <label class="form-label small">Product</label>
            <select name="product_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All products</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(request('product_id') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if(request()->anyFilled(['plant_id', 'product_id', 'status'])): ?>
        <div class="col-auto">
            <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
        </div>
        <?php endif; ?>
    </form>
</div>

<?php if($isPurchaser): ?>

<form method="POST" action="<?php echo e(route('plant.product-requests.bulk-convert')); ?>" id="bulk-quotation-form" class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <?php echo csrf_field(); ?>
    <button type="submit"
            class="btn btn-danger btn-sm"
            id="bulk-export-btn"
            formaction="<?php echo e(route('plant.product-requests.bulk-export-supplier')); ?>"
            disabled>
        <i class="bi bi-file-earmark-excel me-1"></i>Export for Supplier
    </button>
    <button type="submit" class="btn btn-warning btn-sm" id="bulk-generate-btn" disabled>
        <i class="bi bi-cart-plus me-1"></i>Create PO (selected)
    </button>
    <span class="small text-muted" id="bulk-selection-hint">Select until PO is created. Export for supplier first, then create PO. Same plant only.</span>
</form>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <?php if($isPurchaser): ?>
                        <th style="width: 2.5rem">
                            <input type="checkbox" class="form-check-input" id="select-all-requests" title="Select all eligible">
                        </th>
                    <?php endif; ?>
                    <th>#</th>
                    <?php if($isPurchaser): ?>
                        <th>Plant</th>
                    <?php endif; ?>
                    <th>Product</th>
                    <th>Size</th>
                    <th class="text-end">Qty</th>
                    <th>Unit</th>
                    <th>Requested By</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $seenRequestIds = []; ?>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $pr = $item->productRequest;
                    $hasPurchases = $pr->purchaseRequest?->purchases->isNotEmpty();
                    $canSelect = $isPurchaser
                        && ! $hasPurchases
                        && $pr->status !== \App\Enums\RequestStatus::Cancelled;
                    $isFirstForRequest = ! in_array($pr->id, $seenRequestIds, true);
                    if ($isFirstForRequest) {
                        $seenRequestIds[] = $pr->id;
                    }
                ?>
                <tr>
                    <?php if($isPurchaser): ?>
                        <td>
                            <?php if($canSelect && $isFirstForRequest): ?>
                                <input
                                    type="checkbox"
                                    class="form-check-input request-select"
                                    form="bulk-quotation-form"
                                    name="product_request_ids[]"
                                    value="<?php echo e($pr->id); ?>"
                                    data-plant-id="<?php echo e($pr->plant_id); ?>"
                                    data-plant-name="<?php echo e($pr->plant->name); ?>"
                                >
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <td>#<?php echo e($pr->id); ?></td>
                    <?php if($isPurchaser): ?>
                        <td class="fw-semibold"><?php echo e($pr->plant->name); ?></td>
                    <?php endif; ?>
                    <td>
                        <span class="fw-semibold"><?php echo e($item->displayName()); ?></span>
                        <?php if($item->subCategory?->name || $item->product?->subCategory?->name): ?>
                            <span class="d-block small text-muted"><?php echo e($item->subCategory?->name ?? $item->product?->subCategory?->name); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->size ?? $item->product?->size ?? '—'); ?></td>
                    <td class="text-end"><?php echo e(number_format((float) $item->quantity, 2)); ?></td>
                            <td><?php echo e($item->unit ?: ($item->product?->unit?->name ?? '—')); ?></td>
                    <td><?php echo e($pr->displayRequesterName()); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $pr->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pr->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td><?php echo e($pr->created_at->format('d M Y')); ?></td>
                    <td class="text-end">
                        <div class="d-inline-flex gap-2 align-items-center justify-content-end flex-wrap">
                            <?php if($isFirstForRequest): ?>
                                <?php if($pr->status === \App\Enums\RequestStatus::Submitted): ?>
                                    <span class="badge bg-danger" style="font-size: 0.65rem;">New</span>
                                <?php endif; ?>

                                <?php if($isPurchaser): ?>
                                    <?php if($hasPurchases): ?>
                                        <?php if($pr->purchaseRequest->purchases->count() === 1): ?>
                                            <a href="<?php echo e(route('plant.purchases.show', $pr->purchaseRequest->purchases->first())); ?>" class="btn btn-sm btn-admin-outline" title="View PO">
                                                <i class="bi bi-receipt me-1"></i>PO
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('plant.purchases.index', ['purchase_request_id' => $pr->purchaseRequest->id])); ?>" class="btn btn-sm btn-admin-outline" title="View purchase orders">
                                                <i class="bi bi-receipt me-1"></i><?php echo e($pr->purchaseRequest->purchases->count()); ?> POs
                                            </a>
                                        <?php endif; ?>
                                    <?php elseif($pr->purchaseRequest): ?>
                                        <a href="<?php echo e(route('plant.product-requests.export-supplier', $pr)); ?>" class="btn btn-sm btn-admin-outline" title="Export for supplier">
                                            <i class="bi bi-file-earmark-excel me-1"></i>Export
                                        </a>
                                        <a href="<?php echo e(route('plant.purchases.create', ['purchase_request_id' => $pr->purchaseRequest->id])); ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-cart-plus me-1"></i>Create PO
                                        </a>
                                    <?php elseif($pr->status === \App\Enums\RequestStatus::Completed): ?>
                                        <span class="badge bg-secondary-subtle text-secondary border">In site PO</span>
                                    <?php elseif($pr->status !== \App\Enums\RequestStatus::Cancelled): ?>
                                        <a href="<?php echo e(route('plant.product-requests.export-supplier', $pr)); ?>" class="btn btn-sm btn-admin-outline" title="Export for supplier before Create PO">
                                            <i class="bi bi-file-earmark-excel me-1"></i>Export
                                        </a>
                                        <form method="POST" action="<?php echo e(route('plant.product-requests.convert', $pr)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-warning">
                                                <i class="bi bi-cart-plus me-1"></i>Create PO
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if(in_array($pr->status->value, ['submitted', 'in_progress'])): ?>
                                        <a href="<?php echo e(route('plant.product-requests.edit', $pr)); ?>" class="btn btn-sm btn-primary">
                                            Edit
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <a href="<?php echo e(route('plant.product-requests.show', $pr)); ?>" class="btn btn-sm btn-admin-outline" title="View">
                                    <i class="bi bi-eye"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo $__env->make('partials.table-empty', ['colspan' => $isPurchaser ? 11 : 9, 'icon' => 'bi-clipboard-check', 'message' => 'No product requests'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($items->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php if($isPurchaser): ?>
<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const form = document.getElementById('bulk-quotation-form');
    if (!form) return;

    const selectAll = document.getElementById('select-all-requests');
    const boxes = () => Array.from(document.querySelectorAll('.request-select'));
    const btn = document.getElementById('bulk-generate-btn');
    const exportBtn = document.getElementById('bulk-export-btn');
    const hint = document.getElementById('bulk-selection-hint');

    function sync() {
        const checked = boxes().filter((el) => el.checked);
        const plantIds = [...new Set(checked.map((el) => el.dataset.plantId))];
        const samePlant = plantIds.length <= 1;
        const disabled = checked.length === 0 || !samePlant;
        btn.disabled = disabled;
        if (exportBtn) exportBtn.disabled = disabled;

        if (checked.length === 0) {
            hint.textContent = 'Select until PO is created. Export for supplier first, then create PO. Same plant only.';
            hint.classList.remove('text-danger');
        } else if (!samePlant) {
            hint.textContent = 'Selected requests must be from the same plant/site.';
            hint.classList.add('text-danger');
        } else {
            hint.classList.remove('text-danger');
            const name = checked[0].dataset.plantName || 'site';
            hint.textContent = `${checked.length} selected from ${name} — export for supplier, then Create PO`;
        }

        if (selectAll) {
            const enabled = boxes();
            selectAll.checked = enabled.length > 0 && enabled.every((el) => el.checked);
            selectAll.indeterminate = checked.length > 0 && checked.length < enabled.length;
        }
    }

    selectAll?.addEventListener('change', () => {
        const enabled = boxes();
        if (selectAll.checked && enabled.length) {
            const firstPlant = enabled[0].dataset.plantId;
            enabled.forEach((el) => {
                el.checked = el.dataset.plantId === firstPlant;
            });
        } else {
            enabled.forEach((el) => { el.checked = false; });
        }
        sync();
    });

    document.addEventListener('change', (e) => {
        if (e.target.classList.contains('request-select')) sync();
    });

    form.addEventListener('submit', (e) => {
        const checked = boxes().filter((el) => el.checked);
        const plantIds = [...new Set(checked.map((el) => el.dataset.plantId))];
        if (checked.length === 0) {
            e.preventDefault();
            return;
        }
        if (plantIds.length > 1) {
            e.preventDefault();
            alert('Select product requests from one plant/site only.');
            return;
        }

        const action = (e.submitter && e.submitter.getAttribute('formaction')) || form.action;
        const isExport = action.includes('export-supplier');
        if (isExport) {
            return;
        }

        const label = checked.length === 1 ? '1 request' : `${checked.length} requests`;
        if (!confirm(`Create PO for ${label}?`)) {
            e.preventDefault();
        }
    });

    sync();
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\plant\request-po\product-requests\index.blade.php ENDPATH**/ ?>