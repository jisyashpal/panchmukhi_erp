<?php $__env->startSection('title', 'Edit Unit'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Edit Unit','subtitle' => 'Update measurement unit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Unit','subtitle' => 'Update measurement unit']); ?>
    <a href="<?php echo e(route('admin.units.index')); ?>" class="btn btn-admin-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('admin.units.update', $unit)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Name','name' => 'name','value' => old('name', $unit->name),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $unit->name)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Abbreviation','name' => 'abbreviation','value' => old('abbreviation', $unit->abbreviation),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Abbreviation','name' => 'abbreviation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('abbreviation', $unit->abbreviation)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <div class="col-12">
                    <button type="submit" class="btn btn-admin-primary">Update Unit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\admin\product\units\edit.blade.php ENDPATH**/ ?>