<?php $__env->startSection('title', 'Party Ledger - ' . $supplier->name); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Party Ledger: '.e($supplier->name).'','subtitle' => 'Purchases and payments for the supplier']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Party Ledger: '.e($supplier->name).'','subtitle' => 'Purchases and payments for the supplier']); ?>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('ho.reports.party-purchase')); ?>" class="btn btn-sm btn-admin-outline">
            <i class="bi bi-arrow-left me-1"></i>Back to Summary
        </a>
        <?php if (isset($component)) { $__componentOriginal936094a68edd25a90036587134359cc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal936094a68edd25a90036587134359cc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-export-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-export-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $attributes = $__attributesOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__attributesOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $component = $__componentOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__componentOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginald01db17e57e28d17475e8f3829de3bd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01db17e57e28d17475e8f3829de3bd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-filters','data' => ['plants' => $plants,'showDates' => true,'searchPlaceholder' => 'PO reference, item, or payment note...','clearRoute' => route('ho.reports.party-ledger', $supplier->id)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['plants' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($plants),'show-dates' => true,'search-placeholder' => 'PO reference, item, or payment note...','clear-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.reports.party-ledger', $supplier->id))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $attributes = $__attributesOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $component = $__componentOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__componentOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>

<!-- Supplier Details Card -->
<div class="card mb-3 border-0 shadow-sm">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <span class="text-muted small d-block">Contact Person</span>
                <strong><?php echo e($supplier->contact_person ?? '—'); ?></strong>
            </div>
            <div class="col-md-3">
                <span class="text-muted small d-block">Phone / Email</span>
                <strong><?php echo e($supplier->phone ?? '—'); ?></strong>
                <?php if($supplier->email): ?>
                    <span class="d-block small text-muted"><?php echo e($supplier->email); ?></span>
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <span class="text-muted small d-block">GSTIN</span>
                <strong><?php echo e($supplier->gstin ?? '—'); ?></strong>
            </div>
            <div class="col-md-3">
                <span class="text-muted small d-block">Address</span>
                <span class="small"><?php echo e($supplier->address ?? '—'); ?></span>
            </div>
        </div>
    </div>
</div>

<?php
    $totalDebit = $rows->sum('debit');
    $totalCredit = $rows->sum('credit');
    $closingBalance = $rows->last()->balance ?? 0;
?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Reference</th>
                    <th>Particulars</th>
                    <th class="text-end">Debit</th>
                    <th class="text-end">Credit</th>
                    <th class="text-end">Balance</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="small text-muted"><?php echo e($row->date?->format('d M Y') ?? '—'); ?></td>
                        <td>
                            <?php if($row->type === 'payment'): ?>
                                <span class="badge text-bg-success">Payment</span>
                            <?php else: ?>
                                <span class="badge text-bg-primary">Purchase</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($row->type === 'purchase'): ?>
                                <code class="small"><?php echo e($row->reference); ?></code>
                                <?php if($row->plant): ?>
                                    <span class="d-block small text-muted"><?php echo e($row->plant); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="small"><?php echo e($row->reference); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="small" style="max-width: 280px;">
                            <?php if($row->type === 'purchase'): ?>
                                <?php $__currentLoopData = $row->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="text-truncate" title="<?php echo e($item->product->name); ?> (Qty: <?php echo e($item->quantity); ?>)">
                                        • <?php echo e($item->product->name); ?> <span class="text-muted">x <?php echo e($item->quantity); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($row->status): ?>
                                    <div class="mt-1"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $row->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($row->particulars); ?>

                            <?php endif; ?>
                        </td>
                        <td class="text-end"><?php echo e($row->debit > 0 ? '₹'.number_format($row->debit, 2) : '—'); ?></td>
                        <td class="text-end"><?php echo e($row->credit > 0 ? '₹'.number_format($row->credit, 2) : '—'); ?></td>
                        <td class="text-end fw-semibold">₹<?php echo e(number_format($row->balance, 2)); ?></td>
                        <td class="text-end">
                            <?php if($row->type === 'purchase' && $row->purchase): ?>
                                <a href="<?php echo e(route('ho.purchases.show', $row->purchase)); ?>" class="btn btn-sm btn-admin-outline">
                                    <i class="bi bi-eye me-1"></i>View PO
                                </a>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo $__env->make('partials.table-empty', ['colspan' => 8, 'icon' => 'bi-receipt', 'message' => 'No ledger entries found for the selected filters.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </tbody>
            <?php if($rows->isNotEmpty()): ?>
                <tfoot>
                    <tr class="table-light fw-semibold">
                        <td colspan="4">Total</td>
                        <td class="text-end">₹<?php echo e(number_format($totalDebit, 2)); ?></td>
                        <td class="text-end">₹<?php echo e(number_format($totalCredit, 2)); ?></td>
                        <td class="text-end">₹<?php echo e(number_format($closingBalance, 2)); ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\ho\reports\party-ledger.blade.php ENDPATH**/ ?>