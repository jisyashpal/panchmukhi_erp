<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Users','subtitle' => 'Add and manage users — assign roles and plants']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Users','subtitle' => 'Add and manage users — assign roles and plants']); ?>
    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-admin-primary btn-sm">
        <i class="bi bi-plus-lg me-1"></i>Add User
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <!-- <div class="d-flex flex-wrap gap-2 mb-2">
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-sm btn-admin-primary">All users</a>
    </div> -->
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label" for="filter_plant_id">Plant</label>
            <select name="plant_id" id="filter_plant_id" class="form-select form-select-sm">
                <option value="">All plants &amp; mines</option>
                <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plant->id); ?>" <?php if(request('plant_id') == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?> (<?php echo e($plant->code); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label" for="filter_role_id">Role</label>
            <select name="role_id" id="filter_role_id" class="form-select form-select-sm">
                <option value="">All roles</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php if(request('role_id') == $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label" for="filter_search">Search</label>
            <input type="search" name="search" id="filter_search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm" placeholder="Name or email...">
        </div>
        <div class="col-md-3">
            <label class="form-label" for="filter_is_active">Status</label>
            <select name="is_active" id="filter_is_active" class="form-select form-select-sm">
                <option value="">All</option>
                <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>Active</option>
                <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>Inactive</option>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-admin-outline btn-sm w-100">
                <i class="bi bi-funnel me-1"></i>Filter
            </button>
        </div>
        <?php if(request()->hasAny(['plant_id', 'role_id', 'search', 'is_active'])): ?>
            <div class="col-md-3">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-link btn-sm text-danger w-100">Clear filters</a>
            </div>
        <?php endif; ?>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Plant</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($u->name); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td>
                        <span class="badge bg-light text-dark border"><?php echo e($u->role?->name ?? '—'); ?></span>
                    </td>
                    <td>
                        <?php if($u->plant): ?>
                            <span><?php echo e($u->plant->name); ?></span>
                            <code class="small text-muted ms-1"><?php echo e($u->plant->code); ?></code>
                        <?php else: ?>
                            <span class="text-muted">Head Office</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($u->is_active): ?>
                            <span class="badge bg-success-subtle text-success border border-success-subtle">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary-subtle text-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end text-nowrap">
                        <?php if (isset($component)) { $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-edit','data' => ['href' => route('admin.users.edit', $u)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.users.edit', $u))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $attributes = $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $component = $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
                        <?php if($u->id !== auth()->id()): ?>
                            <?php if (isset($component)) { $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-delete','data' => ['action' => route('admin.users.destroy', $u),'confirm' => 'Delete this user?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.users.destroy', $u)),'confirm' => 'Delete this user?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $attributes = $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $component = $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">
                        <div class="admin-empty">
                            <i class="bi bi-people d-block"></i>
                            No users found
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($users->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/admin/master/users/index.blade.php ENDPATH**/ ?>