<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['colspan' => 1, 'icon' => 'bi-inbox', 'message' => 'No records found']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['colspan' => 1, 'icon' => 'bi-inbox', 'message' => 'No records found']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<tr>
    <td colspan="<?php echo e($colspan); ?>">
        <div class="admin-empty text-center py-4 text-muted">
            <i class="bi <?php echo e($icon); ?> d-block fs-3 mb-2"></i>
            <?php echo e($message); ?>

        </div>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/partials/table-empty.blade.php ENDPATH**/ ?>