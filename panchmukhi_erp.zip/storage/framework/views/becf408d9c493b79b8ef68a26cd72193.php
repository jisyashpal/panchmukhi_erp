<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => ''.e($isPurchaser ? 'Purchaser Dashboard' : 'Plant Dashboard').'','subtitle' => ''.e($isPurchaser ? 'All plants — requests, purchases & stock overview' : ($plant->name.' — plant-specific summary')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($isPurchaser ? 'Purchaser Dashboard' : 'Plant Dashboard').'','subtitle' => ''.e($isPurchaser ? 'All plants — requests, purchases & stock overview' : ($plant->name.' — plant-specific summary')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-stat-grid mb-3">
    <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="admin-stat-card stat-accent-amber">
        <div class="stat-icon stat-icon-amber"><i class="bi bi-clipboard-check"></i></div>
        <div class="stat-label">Submitted Product Requests</div>
        <div class="stat-value"><?php echo e($submittedProductRequests); ?></div>
    </a>
    <a href="<?php echo e(route('plant.purchases.index')); ?>" class="admin-stat-card stat-accent-violet">
        <div class="stat-icon stat-icon-violet"><i class="bi bi-cart-check"></i></div>
        <div class="stat-label">Total Purchases</div>
        <div class="stat-value"><?php echo e($totalPurchases); ?></div>
    </a>
    <a href="<?php echo e(route('plant.stocks.index')); ?>" class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-boxes"></i></div>
        <div class="stat-label">Total Stocks</div>
        <div class="stat-value"><?php echo e(number_format($totalStockLines)); ?></div>
        <div class="stat-sub text-muted" style="font-size:.78rem;">
            Qty sum: <?php echo e(number_format($totalStockQty, 0)); ?>

        </div>
    </a>
    <?php if(auth()->user()->isPurchaser()): ?>
    <a href="<?php echo e(route('plant.dispatch.index')); ?>" class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-send"></i></div>
        <div class="stat-label">Awaiting Dispatch</div>
        <div class="stat-value"><?php echo e($awaitingDispatch); ?></div>
    </a>
    <a href="<?php echo e(route('plant.purchases.index')); ?>" class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-truck"></i></div>
        <div class="stat-label">Dispatched / Awaiting Receipt</div>
        <div class="stat-value"><?php echo e($awaitingDelivery); ?></div>
    </a>
    <?php endif; ?>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Low Stock</h2>
                <a href="<?php echo e(route('plant.stocks.index')); ?>" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Product</th><th class="text-end">Qty</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($row->product->name); ?>

                                <?php if($isPurchaser && $row->plant): ?>
                                    <span class="text-muted small d-block"><?php echo e($row->plant->name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end text-danger fw-semibold"><?php echo e($row->quantity); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="2"><div class="admin-empty">No low stock</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Top Stock Levels</h2>
                <a href="<?php echo e(route('plant.stocks.index')); ?>" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Product</th><th class="text-end">Qty</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $stockLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($row->product->name); ?>

                                <?php if($isPurchaser && $row->plant): ?>
                                    <span class="text-muted small d-block"><?php echo e($row->plant->name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end"><?php echo e($row->quantity); ?> <?php echo e($row->product->unit?->abbreviation); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="2"><div class="admin-empty">No stock</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/operation/dashboard.blade.php ENDPATH**/ ?>