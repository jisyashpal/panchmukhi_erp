<?php
    $passwordUpdateRoute = $passwordUpdateRoute ?? route('password.update');
?>

<section>
    <p class="text-muted small mb-3"><?php echo e(__('Ensure your account is using a long, random password to stay secure.')); ?></p>

    <form method="post" action="<?php echo e($passwordUpdateRoute); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="row g-3">
            <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Current Password','name' => 'current_password','type' => 'password','autocomplete' => 'current-password','errorBag' => 'updatePassword','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Current Password','name' => 'current_password','type' => 'password','autocomplete' => 'current-password','error-bag' => 'updatePassword','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'New Password','name' => 'password','type' => 'password','autocomplete' => 'new-password','errorBag' => 'updatePassword','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'New Password','name' => 'password','type' => 'password','autocomplete' => 'new-password','error-bag' => 'updatePassword','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Confirm Password','name' => 'password_confirmation','type' => 'password','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Confirm Password','name' => 'password_confirmation','type' => 'password','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
            <div class="col-12 d-flex align-items-center gap-2">
                <button type="submit" class="btn btn-admin-primary"><?php echo e(__('Update Password')); ?></button>
                <?php if(session('status') === 'password-updated'): ?>
                    <span class="text-success small"><i class="bi bi-check-circle me-1"></i><?php echo e(__('Saved.')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </form>
</section>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\profile\partials\update-password-form.blade.php ENDPATH**/ ?>