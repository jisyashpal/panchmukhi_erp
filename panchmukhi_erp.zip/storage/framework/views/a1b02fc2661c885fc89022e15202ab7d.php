<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Categories','subtitle' => 'Product categories for catalog organization']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Categories','subtitle' => 'Product categories for catalog organization']); ?>
    <a href="<?php echo e(route('ho.categories.create')); ?>" class="btn btn-admin-primary btn-sm">
        <i class="bi bi-plus-lg me-1"></i>Add Category
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Sub-categories</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($c->name); ?></td>
                    <td><?php echo e($c->sub_categories_count); ?></td>
                    <td class="text-end text-nowrap">
                        <?php if (isset($component)) { $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-edit','data' => ['href' => route('ho.categories.edit', $c)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.categories.edit', $c))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $attributes = $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $component = $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
                        <?php if($c->products_count === 0): ?>
                            <?php if (isset($component)) { $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-delete','data' => ['action' => route('ho.categories.destroy', $c),'confirm' => 'Delete this category?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.categories.destroy', $c)),'confirm' => 'Delete this category?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $attributes = $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $component = $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">
                        <div class="admin-empty"><i class="bi bi-folder d-block"></i>No categories found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/ho/product/categories/index.blade.php ENDPATH**/ ?>