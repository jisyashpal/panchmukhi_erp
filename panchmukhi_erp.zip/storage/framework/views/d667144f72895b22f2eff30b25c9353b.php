<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'name' => null, 'col' => 'col-md-4', 'required' => false, 'errorBag' => null, 'createHref' => null, 'createLabel' => 'Create', 'labelColor' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'name' => null, 'col' => 'col-md-4', 'required' => false, 'errorBag' => null, 'createHref' => null, 'createLabel' => 'Create', 'labelColor' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => trim($col.' admin-form-group')])); ?>>
    <?php if($label): ?>
        <div class="d-flex justify-content-between align-items-baseline gap-2 flex-wrap">
            <label class="form-label mb-0 <?php echo e($labelColor); ?>" <?php if($name): ?> for="<?php echo e($name); ?>" <?php endif; ?>>
                <?php echo e($label); ?>

                <?php if($required): ?><span class="text-danger">*</span><?php endif; ?>
            </label>
            <?php if($createHref): ?>
                <a href="<?php echo e($createHref); ?>" class="admin-form-create-link small text-decoration-none">
                    <i class="bi bi-plus-lg" aria-hidden="true"></i><?php echo e($createLabel); ?>

                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php echo e($slot); ?>

    <?php if($name): ?>
        <?php $__errorArgs = [$name, $errorBag];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/components/admin-form-group.blade.php ENDPATH**/ ?>