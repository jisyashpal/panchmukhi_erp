<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <meta name="theme-color" content="#0f172a">
    <title><?php echo $__env->yieldContent('title', 'Sign in'); ?> — <?php echo e(config('app.name', 'Panchmukhi ERP')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/p.png')); ?>" type="image/x-icon">
    <?php echo $__env->make('partials.bootstrap-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>?v=<?php echo e(filemtime(public_path('css/auth.css'))); ?>">
</head>

<body class="auth-page">
    <div class="container-fluid g-0">
        <div class="row g-0 min-vh-100">
            <?php echo $__env->make('partials.auth-brand-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="col-12 col-md-6 auth-form-column d-flex flex-column">
                <header class="auth-mobile-header d-md-none text-center px-3 border-bottom bg-white shadow-sm">
                    <?php echo $__env->make('partials.auth-logo', ['compact' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </header>

                <div class="flex-grow-1 d-flex align-items-center justify-content-center py-3 py-sm-4">
                    <div class="auth-form-inner">
                        <div class="card auth-card border-0">
                            <div class="card-body">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                        <p class="auth-footer-note text-center fw-bold small mt-3 mb-0">
                            Secure access for authorized personnel only
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.bootstrap-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.auth-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi\resources\views/layouts/guest.blade.php ENDPATH**/ ?>