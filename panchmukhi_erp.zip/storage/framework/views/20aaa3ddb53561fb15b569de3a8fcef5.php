<?php
    $pageTitle = $pageTitle ?? 'Plant';
    $user = auth()->user();
    $user->loadMissing(['role', 'plant']);
?>
<header class="admin-topbar">
    <div class="admin-topbar-start">
        <button class="admin-menu-btn d-lg-none flex-shrink-0" type="button"
                data-bs-toggle="offcanvas" data-bs-target="#plantSidebarOffcanvas" aria-label="Open menu">
            <i class="bi bi-list fs-5"></i>
        </button>

        <div class="admin-topbar-heading min-w-0">
            <nav class="admin-topbar-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('plant.dashboard')); ?>">Plant</a>
                <i class="bi bi-chevron-right"></i>
                <span><?php echo e($pageTitle); ?></span>
            </nav>
            <h1 class="admin-topbar-title text-truncate"><?php echo e($pageTitle); ?></h1>
            <?php if($user->role?->slug === 'purchaser'): ?>
                <small class="text-muted d-block text-truncate" style="font-size: .75rem;">
                    All Plants
                </small>
            <?php elseif($user->plant): ?>
                <small class="text-muted d-block text-truncate" style="font-size: .75rem;">
                    <?php echo e($user->plant->name); ?> · <?php echo e($user->plant->code); ?>

                </small>
            <?php endif; ?>
        </div>
    </div>

    <div class="admin-topbar-end">
        <?php echo $__env->make('partials.notification-bell', [
            'indexRoute' => 'plant.notifications.index',
            'readRoute' => 'plant.notifications.read',
            'readAllRoute' => 'plant.notifications.read-all',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="dropdown">
            <a href="#" class="admin-user-chip dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" role="button">
                <span class="admin-user-chip-avatar">
                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                </span>
                <span class="d-none d-sm-block text-start">
                    <span class="d-block small fw-semibold lh-1 text-truncate" style="max-width: 120px;"><?php echo e($user->name); ?></span>
                    <span class="text-muted" style="font-size: .7rem;"><?php echo e($user->role?->name ?? 'Plant User'); ?></span>
                </span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end admin-topbar-dropdown shadow border-0">
                <li class="px-3 py-2 border-bottom">
                    <div class="small fw-semibold"><?php echo e($user->name); ?></div>
                    <div class="text-muted text-truncate" style="font-size: .75rem;"><?php echo e($user->email); ?></div>
                    <?php if($user->role?->slug === 'purchaser'): ?>
                        <div class="text-muted mt-1" style="font-size: .7rem;">
                            <i class="bi bi-buildings me-1"></i>All Plants
                        </div>
                    <?php elseif($user->plant): ?>
                        <div class="text-muted mt-1" style="font-size: .7rem;">
                            <i class="bi bi-geo-alt me-1"></i><?php echo e($user->plant->name); ?>

                        </div>
                    <?php endif; ?>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('plant.dashboard')); ?>">
                        <i class="bi bi-speedometer2 me-2"></i>Dashboard
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('plant.profile.edit')); ?>">
                        <i class="bi bi-person me-2"></i>Profile
                    </a>
                </li>
                <li>
                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="<?php echo e(route('plant.notifications.index')); ?>">
                        <span><i class="bi bi-bell me-2"></i>Notifications</span>
                        <?php $unreadCount = $user->unreadNotifications()->count(); ?>
                        <?php if($unreadCount > 0): ?>
                            <span class="badge bg-danger rounded-pill"><?php echo e($unreadCount > 9 ? '9+' : $unreadCount); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\partials\plant-topbar.blade.php ENDPATH**/ ?>