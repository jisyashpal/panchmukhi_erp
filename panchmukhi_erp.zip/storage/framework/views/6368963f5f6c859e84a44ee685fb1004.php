<?php $__env->startSection('title', 'Edit Plant'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Edit Plant','subtitle' => 'Update plant or mine details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Plant','subtitle' => 'Update plant or mine details']); ?>
    <a href="<?php echo e(route('admin.plants.index')); ?>" class="btn btn-admin-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('admin.plants.update', $plant)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Name','name' => 'name','value' => old('name', $plant->name),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $plant->name)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Code','name' => 'code','value' => old('code', $plant->code),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Code','name' => 'code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('code', $plant->code)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Type','name' => 'type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Type','name' => 'type']); ?>
                    <select name="type" id="type" class="form-select">
                        <option value="plant" <?php if(old('type', $plant->type) === 'plant'): echo 'selected'; endif; ?>>Plant</option>
                        <option value="mine" <?php if(old('type', $plant->type) === 'mine'): echo 'selected'; endif; ?>>Mine</option>
                    </select>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Address','name' => 'address','col' => 'col-md-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Address','name' => 'address','col' => 'col-md-12']); ?>
                    <textarea name="address" id="address" class="form-control" rows="3"><?php echo e(old('address', $plant->address)); ?></textarea>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <div class="col-12">
                    <div class="form-check">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" id="active" <?php if(old('is_active', $plant->is_active)): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-admin-primary">Update Plant</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\admin\master\plants\edit.blade.php ENDPATH**/ ?>