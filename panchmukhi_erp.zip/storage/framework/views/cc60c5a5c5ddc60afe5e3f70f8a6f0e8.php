<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Products','subtitle' => 'Product catalog — full details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Products','subtitle' => 'Product catalog — full details']); ?>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-admin-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Add Product
        </a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <div class="admin-filters mb-3">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-12 col-md-2">
                <label class="form-label small" for="filter_category_id">Category</label>
                <select name="category_id" id="filter_category_id" class="form-select form-select-sm"
                    onchange="this.form.submit()">
                    <option value="">All categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php if(request('category_id') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label small" for="filter_brand_id">Brand</label>
                <select name="brand_id" id="filter_brand_id" class="form-select form-select-sm"
                    onchange="this.form.submit()">
                    <option value="">All brands</option>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>" <?php if(request('brand_id') == $b->id): echo 'selected'; endif; ?>><?php echo e($b->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label small" for="filter_is_active">Status</label>
                <select name="is_active" id="filter_is_active" class="form-select form-select-sm"
                    onchange="this.form.submit()">
                    <option value="">All</option>
                    <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>Active</option>
                    <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-12 col-md-3 position-relative">
                <label class="form-label small" for="product-search">Search Item Name / SKU</label>
                <input type="text" name="search" id="product-search" value="<?php echo e(request('search')); ?>"
                    class="form-control form-control-sm" placeholder="Enter item name or SKU..." autocomplete="off">
                <div id="autocomplete-suggestions"
                    class="autocomplete-suggestions d-none shadow border rounded-bottom bg-white"></div>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
                <?php if(request()->anyFilled(['category_id', 'brand_id', 'is_active', 'search'])): ?>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="admin-card admin-table-card">
        <div class="table-responsive">
            <table class="table mb-0 align-middle">
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Item Name</th>
                        <th>Size/Part</th>
                        <th>Category</th>
                        <th>Item Type</th>
                        <th>Brand</th>
                        <th>Unit</th>
                        <th class="text-end">Reorder Level</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><code class="small"><?php echo e($p->sku); ?></code></td>
                            <td class="fw-semibold"><?php echo e($p->name); ?></td>
                            <td><?php echo e($p->size ?? '—'); ?></td>
                            <td><?php echo e($p->category->name); ?></td>
                            <td><?php echo e($p->subCategory?->name ?? '—'); ?></td>
                            <td><?php echo e($p->brand?->name ?? '—'); ?></td>
                            <td><?php echo e($p->unit->name); ?> <span class="text-muted small">(<?php echo e($p->unit->abbreviation); ?>)</span></td>
                            <td class="text-end"><?php echo e(number_format($p->reorder_level)); ?></td>
                            <td>
                                <?php if($p->is_active): ?>
                                    <span class="badge bg-success-subtle text-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary-subtle text-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if (isset($component)) { $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-edit','data' => ['href' => route('admin.products.edit', $p)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.edit', $p))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $attributes = $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $component = $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10">
                                <div class="admin-empty"><i class="bi bi-box-seam d-block"></i>No products found</div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginale43a0c64c2ca4729d3c5b59fae0856df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale43a0c64c2ca4729d3c5b59fae0856df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-pagination','data' => ['paginator' => $products,'label' => 'products']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'label' => 'products']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale43a0c64c2ca4729d3c5b59fae0856df)): ?>
<?php $attributes = $__attributesOriginale43a0c64c2ca4729d3c5b59fae0856df; ?>
<?php unset($__attributesOriginale43a0c64c2ca4729d3c5b59fae0856df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale43a0c64c2ca4729d3c5b59fae0856df)): ?>
<?php $component = $__componentOriginale43a0c64c2ca4729d3c5b59fae0856df; ?>
<?php unset($__componentOriginale43a0c64c2ca4729d3c5b59fae0856df); ?>
<?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <style>
            .autocomplete-suggestions {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                max-height: 250px;
                overflow-y: auto;
                z-index: 1050;
                margin-top: 2px;
            }

            .suggestion-item {
                cursor: pointer;
                transition: background 0.15s ease-in-out;
            }

            .suggestion-item:hover {
                background-color: #f8f9fa;
            }

            .suggestion-item:last-child {
                border-bottom: none !important;
            }
        </style>
        <?php echo $__env->make('partials.infinite-suggestions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const searchInput = document.getElementById('product-search');
                const suggestionsBox = document.getElementById('autocomplete-suggestions');
                const products = <?php echo json_encode($allProducts->map(fn($p) => ['id' => $p->id, 'name' => $p->name, 'sku' => $p->sku])) ?>;

                if (!searchInput || !suggestionsBox) return;

                const infinite = window.PanchmukhiInfiniteSuggestions.create(suggestionsBox, {
                    pageSize: 25,
                    renderItem: function (p) {
                        const div = document.createElement('div');
                        div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
                        div.innerHTML = `<span class="fw-semibold text-dark d-block text-truncate" style="max-width:100%">${p.name}</span> <span class="text-muted small">${p.sku}</span>`;
                        div.addEventListener('click', function () {
                            searchInput.value = p.name;
                            infinite.reset();
                            suggestionsBox.classList.add('d-none');
                            searchInput.form.submit();
                        });
                        return div;
                    },
                });

                searchInput.addEventListener('input', function () {
                    const val = this.value.trim().toLowerCase();

                    if (!val) {
                        infinite.reset();
                        suggestionsBox.classList.add('d-none');
                        return;
                    }

                    const filtered = products.filter(p =>
                        p.name.toLowerCase().includes(val) ||
                        (p.sku && p.sku.toLowerCase().includes(val))
                    );

                    if (!infinite.setResults(filtered)) {
                        suggestionsBox.classList.add('d-none');
                        return;
                    }

                    suggestionsBox.classList.remove('d-none');
                });

                document.addEventListener('click', function (e) {
                    if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
                        infinite.reset();
                        suggestionsBox.classList.add('d-none');
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/admin/product/products/index.blade.php ENDPATH**/ ?>