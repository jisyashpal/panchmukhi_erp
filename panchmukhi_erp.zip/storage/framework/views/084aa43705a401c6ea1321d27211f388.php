<?php
    $product = $product ?? null;
    $portal = $portal ?? 'plant';
    $selectedCategoryId = old('category_id', $product?->category_id ?? request('category_id'));
    $selectedSubCategoryId = old('sub_category_id', $product?->sub_category_id ?? request('sub_category_id'));
    $selectedBrandId = old('brand_id', $product?->brand_id ?? request('brand_id'));
    $selectedUnitId = old('unit_id', $product?->unit_id ?? request('unit_id'));
    $returnParams = ['redirect' => 'products.create'];
    $subCategoryCreateParams = array_filter(array_merge($returnParams, [
        'category_id' => $selectedCategoryId,
    ]));
?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Category','name' => 'category_id','required' => true,'createHref' => route($portal.'.categories.create', $returnParams),'createLabel' => 'Create category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Category','name' => 'category_id','required' => true,'create-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($portal.'.categories.create', $returnParams)),'create-label' => 'Create category']); ?>
    <select name="category_id" id="category_id" class="form-select" required>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if($selectedCategoryId == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Item Type','name' => 'sub_category_id','createHref' => route($portal.'.sub-categories.create', $subCategoryCreateParams),'createLabel' => 'Create Item Type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Item Type','name' => 'sub_category_id','create-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($portal.'.sub-categories.create', $subCategoryCreateParams)),'create-label' => 'Create Item Type']); ?>
    <select name="sub_category_id" id="sub_category_id" class="form-select">
        <option value="">—</option>
        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($sc->id); ?>" data-category-id="<?php echo e($sc->category_id); ?>"
                <?php if($selectedSubCategoryId == $sc->id): echo 'selected'; endif; ?>><?php echo e($sc->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Brand','name' => 'brand_id','createHref' => route($portal.'.brands.create', $returnParams),'createLabel' => 'Create brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Brand','name' => 'brand_id','create-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($portal.'.brands.create', $returnParams)),'create-label' => 'Create brand']); ?>
    <select name="brand_id" id="brand_id" class="form-select">
        <option value="">—</option>
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($b->id); ?>" <?php if($selectedBrandId == $b->id): echo 'selected'; endif; ?>><?php echo e($b->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Unit','name' => 'unit_id','required' => true,'createHref' => route($portal.'.units.create', $returnParams),'createLabel' => 'Create unit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Unit','name' => 'unit_id','required' => true,'create-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($portal.'.units.create', $returnParams)),'create-label' => 'Create unit']); ?>
    <select name="unit_id" id="unit_id" class="form-select" required>
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php if($selectedUnitId == $u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?> (<?php echo e($u->abbreviation); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\plant\product\products\partials\catalog-selects.blade.php ENDPATH**/ ?>