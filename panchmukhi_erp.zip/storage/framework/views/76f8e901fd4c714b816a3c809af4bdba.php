<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $plantQuery = array_filter(['plant_id' => $plantId ?: null, 'fy' => request('fy') ?: null]);
?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Dashboard','subtitle' => 'Operations for '.e($financialYearRange->displayLabel()).' across all plants']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','subtitle' => 'Operations for '.e($financialYearRange->displayLabel()).' across all plants']); ?>
    <form method="GET" class="d-flex align-items-center gap-2 flex-wrap">
        <?php if (isset($component)) { $__componentOriginal4be369a9030485a61f998f024d2f0b89 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4be369a9030485a61f998f024d2f0b89 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.financial-year-select','data' => ['compact' => true,'selected' => request('fy', $financialYearRange->label)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('financial-year-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['compact' => true,'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('fy', $financialYearRange->label))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $attributes = $__attributesOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__attributesOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $component = $__componentOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__componentOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
        <select name="plant_id" onchange="this.form.submit()" class="form-select form-select-sm" style="min-width: 180px;">
            <option value="">All plants</option>
            <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($plant->id); ?>" <?php if($plantId == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>


<div class="admin-stat-grid">
    <a href="<?php echo e(route('ho.stocks.index', $plantQuery)); ?>" class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-boxes"></i></div>
        <div class="stat-label">Stock Lines (qty sum)</div>
        <div class="stat-value"><?php echo e(number_format($totalStockValue, 0)); ?></div>
    </a>
    <a href="<?php echo e(route('ho.purchases.index', array_merge($plantQuery, ['status' => 'ordered']))); ?>" class="admin-stat-card stat-accent-amber">
        <div class="stat-icon stat-icon-amber"><i class="bi bi-cart"></i></div>
        <div class="stat-label">Pending POs</div>
        <div class="stat-value"><?php echo e($pendingOrders); ?></div>
    </a>
    <a href="<?php echo e(route('ho.purchases.index', array_merge($plantQuery, ['status' => 'delivered']))); ?>" class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-check2-circle"></i></div>
        <div class="stat-label">Confirmed / Delivered</div>
        <div class="stat-value"><?php echo e($confirmedOrders); ?></div>
    </a>
    <a href="<?php echo e(route('ho.purchases.index', $plantQuery)); ?>" class="admin-stat-card stat-accent-violet">
        <div class="stat-icon stat-icon-violet"><i class="bi bi-currency-rupee"></i></div>
        <div class="stat-label">Total Purchase Amount</div>
        <div class="stat-value">₹<?php echo e(number_format($totalPurchaseAmount, 0)); ?></div>
    </a>
</div>


<div class="row g-4 mt-1">
    <div class="col-lg-7">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Category-wise Stock In / Out</h2>
                <a href="<?php echo e(route('ho.reports.category-stock-in-out', array_filter(['plant_id' => $plantId]))); ?>"
                   class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-right-circle me-1"></i>View All
                </a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th class="text-end">In Qty</th>
                            <th class="text-end">In Amount (₹)</th>
                            <th class="text-end">Out Qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categoryBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($row->category); ?></td>
                            <td class="text-end text-success"><?php echo e(number_format($row->in_qty, 0)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($row->in_amount, 0)); ?></td>
                            <td class="text-end text-danger"><?php echo e(number_format($row->out_qty, 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4"><div class="admin-empty">No stock movements yet</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if($categoryBreakdown->isNotEmpty()): ?>
                    <tfoot class="table-light fw-semibold">
                        <tr>
                            <td>Total</td>
                            <td class="text-end text-success"><?php echo e(number_format($categoryBreakdown->sum('in_qty'), 0)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($categoryBreakdown->sum('in_amount'), 0)); ?></td>
                            <td class="text-end text-danger"><?php echo e(number_format($categoryBreakdown->sum('out_qty'), 0)); ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Low Stock</h2>
                <a href="<?php echo e(route('ho.stocks.index', $plantQuery)); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-right-circle me-1"></i>View All
                </a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Plant</th><th>Product</th><th class="text-end">Qty</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row->plant->name ?? ''); ?></td>
                            <td>
                                <?php if($row->product && $row->plant_id): ?>
                                    <a href="<?php echo e(route('ho.stocks.show', ['plant_id' => $row->plant_id, 'product_id' => $row->product_id])); ?>">
                                        <?php echo e($row->product->name); ?>

                                    </a>
                                <?php else: ?>
                                    <?php echo e($row->product->name ?? ''); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-end text-danger fw-semibold"><?php echo e($row->quantity); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3"><div class="admin-empty">No low stock items</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="row g-4 mt-1">
    <div class="col-12">
        <div class="admin-card admin-table-card">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Recent Purchases</h2>
                <a href="<?php echo e(route('ho.purchases.index', $plantQuery)); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-right-circle me-1"></i>View All
                </a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Ref</th><th>Plant</th><th>Supplier</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('ho.purchases.show', $purchase)); ?>"><?php echo e($purchase->reference_no); ?></a></td>
                            <td><?php echo e($purchase->plant->name); ?></td>
                            <td><?php echo e($purchase->supplier->name ?? '—'); ?></td>
                            <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchase->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchase->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4"><div class="admin-empty">No purchases yet</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/ho/operation/dashboard.blade.php ENDPATH**/ ?>