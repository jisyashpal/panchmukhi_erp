<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $profileUpdateRoute = route('plant.profile.update');
    $passwordUpdateRoute = route('plant.password.update');
    $destroyRoute = route('plant.profile.destroy');
?>

<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'My Profile','subtitle' => 'Manage your account']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Profile','subtitle' => 'Manage your account']); ?>
    <a href="<?php echo e(route('plant.dashboard')); ?>" class="btn btn-admin-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Dashboard</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card mb-4">
    <div class="admin-card-body d-flex flex-wrap align-items-center gap-3">
        <span class="admin-profile-avatar rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width:48px;height:48px;font-size:1.25rem">
            <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

        </span>
        <div>
            <h2 class="h5 mb-1"><?php echo e($user->name); ?></h2>
            <p class="text-muted small mb-1"><?php echo e($user->email); ?></p>
            <span class="badge bg-success-subtle text-success"><?php echo e($user->role?->name); ?></span>
            <?php if($user->plant): ?>
                <span class="badge bg-light text-dark border ms-1"><?php echo e($user->plant->name); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header"><h2 class="h6 mb-0">Profile Information</h2></div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.update-profile-information-form', compact('profileUpdateRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header"><h2 class="h6 mb-0">Update Password</h2></div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.update-password-form', compact('passwordUpdateRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<div class="admin-card border-danger-subtle">
    <div class="admin-card-header"><h2 class="h6 mb-0 text-danger">Delete Account</h2></div>
    <div class="admin-card-body">
        <?php echo $__env->make('profile.partials.delete-user-form', compact('destroyRoute'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\plant\profile\edit.blade.php ENDPATH**/ ?>