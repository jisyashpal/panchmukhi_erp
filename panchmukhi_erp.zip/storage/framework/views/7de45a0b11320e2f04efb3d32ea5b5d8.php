<?php $__env->startSection('title', 'Verify email'); ?>
<?php $__env->startSection('content'); ?>
    <div class="text-center mb-4">
        <h1 class="h4 fw-bold mb-1">Verify email</h1>
        <p class="text-muted small mb-0">Thanks for signing up! Click the link we sent to your email, or request a new one below.</p>
    </div>

    <?php if(session('status') == 'verification-link-sent'): ?>
    <div class="alert alert-success" role="alert"><?php echo e(__('A new verification link has been sent.')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="mb-3">
        <?php echo csrf_field(); ?>
        <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-envelope-check me-1"></i> Resend verification email
            </button>
        </div>
    </form>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <div class="d-grid">
            <button type="submit" class="btn btn-outline-secondary">Log out</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>