<?php $__env->startSection('title', 'Purchase Request #'.$purchaseRequest->id); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Purchase Request #'.e($purchaseRequest->id).'','subtitle' => 'Track request status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Purchase Request #'.e($purchaseRequest->id).'','subtitle' => 'Track request status']); ?>
    <div class="d-flex gap-2">
        <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchaseRequest->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchaseRequest->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
        <?php if($canEdit): ?>
        <a href="<?php echo e(route('plant.purchase-requests.edit', $purchaseRequest)); ?>" class="btn btn-primary btn-sm">Edit / Modify</a>
        <?php endif; ?>
        <a href="<?php echo e(route('plant.purchase-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card admin-table-card mb-4">
    <div class="admin-card-header"><h2>Items</h2></div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead><tr><th>Product</th><th>Supplier</th><th class="text-end">Qty</th><th class="text-end">Rate</th><th class="text-end">Stock</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $purchaseRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->displayName()); ?></td>
                    <td><?php echo e($item->supplier?->name ?? '—'); ?></td>
                    <td class="text-end"><?php echo e($item->quantity); ?></td>
                    <td class="text-end"><?php echo e($item->unit_price); ?></td>
                    <td class="text-end">
                        <?php if($item->product_id): ?>
                            <span class="stock-check" data-url="<?php echo e(route('plant.api.stock.check', ['plant' => $purchaseRequest->plant_id, 'product' => $item->product_id])); ?>">…</span>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php if($canEdit && !in_array($purchaseRequest->status->value, ['completed', 'cancelled'])): ?>
<div class="admin-card">
    <div class="admin-card-body d-flex flex-wrap gap-2">
        <form method="POST" action="<?php echo e(route('plant.purchase-requests.status', $purchaseRequest)); ?>"><?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="in_progress"><button class="btn btn-warning btn-sm">Confirm In Progress</button>
        </form>
        <form method="POST" action="<?php echo e(route('plant.purchase-requests.status', $purchaseRequest)); ?>"><?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="completed"><button class="btn btn-success btn-sm">Mark Completed</button>
        </form>
        <form method="POST" action="<?php echo e(route('plant.purchase-requests.status', $purchaseRequest)); ?>" class="d-flex gap-2"><?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="cancelled">
            <input type="text" name="reason" class="form-control form-control-sm" placeholder="Cancel reason">
            <button class="btn btn-outline-danger btn-sm">Cancel</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if($purchaseRequest->purchases->isNotEmpty()): ?>
    <div class="mt-3 p-3 bg-light border rounded">
        <span class="text-muted d-block mb-2">Associated Purchase Order(s):</span>
        <div class="d-flex flex-wrap gap-2 align-items-center">
            <?php $__currentLoopData = $purchaseRequest->purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex align-items-center gap-2 border rounded px-2 py-1 bg-white">
                    <strong class="text-dark"><?php echo e($po->reference_no); ?></strong>
                    <span class="badge bg-secondary"><?php echo e($po->status->label()); ?></span>
                    <small class="text-muted"><?php echo e($po->supplier->name); ?></small>
                    <?php if(auth()->user()->isPurchaser() && in_array($po->status->value, ['ordered', 'partial'])): ?>
                        <a href="<?php echo e(route('plant.purchases.edit', $po)); ?>" class="btn btn-sm btn-success text-white">
                            <i class="bi bi-pencil-square me-1"></i>Edit PO
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('.stock-check').forEach(el => {
    fetch(el.dataset.url, {headers: {'Accept': 'application/json'}})
        .then(r => r.json()).then(d => el.textContent = d.quantity ?? '0').catch(() => el.textContent = '—');
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\plant\request-po\purchase-requests\show.blade.php ENDPATH**/ ?>