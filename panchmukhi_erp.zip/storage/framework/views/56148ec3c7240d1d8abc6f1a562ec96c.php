<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'compact' => false,
    'name' => 'fy',
    'selected' => null,
    'formMethod' => null,
    'formAction' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'compact' => false,
    'name' => 'fy',
    'selected' => null,
    'formMethod' => null,
    'formAction' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $selected = $selected ?? ($financialYear->label ?? null);
    $options = $financialYearOptions ?? [];
?>

<?php if($formAction): ?>
    <form method="<?php echo e($formMethod ?? 'POST'); ?>" action="<?php echo e($formAction); ?>" class="d-inline">
        <?php echo csrf_field(); ?>
<?php endif; ?>

<select
    name="<?php echo e($name); ?>"
    class="form-select <?php echo e($compact ? 'form-select-sm' : ''); ?> financial-year-select"
    <?php if($formAction): ?> onchange="this.form.submit()" <?php endif; ?>
    <?php echo e($attributes); ?>

>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php if($selected === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php if($formAction): ?>
    </form>
<?php endif; ?>

<?php if(!$formAction): ?>
    <?php if (! $__env->hasRenderedOnce('5835107d-70f7-4ad9-a242-24564bf6eb2d')): $__env->markAsRenderedOnce('5835107d-70f7-4ad9-a242-24564bf6eb2d'); ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    document.querySelectorAll('.financial-year-select').forEach(function (select) {
                        if (select.closest('form')?.action && select.closest('form').querySelector('input[name="_token"]')) {
                            return;
                        }
                        select.addEventListener('change', function () {
                            const form = this.closest('form');
                            if (!form) return;
                            
                            const dateFromInput = form.querySelector('input[name="date_from"]');
                            const dateToInput = form.querySelector('input[name="date_to"]');
                            
                            if (dateFromInput) dateFromInput.value = '';
                            if (dateToInput) dateToInput.value = '';
                            
                            form.submit();
                        });
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/components/financial-year-select.blade.php ENDPATH**/ ?>