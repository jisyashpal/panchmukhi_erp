<?php $__env->startSection('title', 'Purchase List'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Purchase List','subtitle' => 'Supplier-wise totals for '.e($filters->financialYear ? 'FY '.$filters->financialYear : 'selected period').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Purchase List','subtitle' => 'Supplier-wise totals for '.e($filters->financialYear ? 'FY '.$filters->financialYear : 'selected period').'']); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <?php if(isset($financialYear)): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Financial Year</label>
                <?php if (isset($component)) { $__componentOriginal4be369a9030485a61f998f024d2f0b89 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4be369a9030485a61f998f024d2f0b89 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.financial-year-select','data' => ['compact' => true,'selected' => request('fy', $financialYear->label)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('financial-year-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['compact' => true,'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('fy', $financialYear->label))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $attributes = $__attributesOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__attributesOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $component = $__componentOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__componentOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="col-6 col-md-2">
            <label class="form-label small">Plant</label>
            <select name="plant_id" class="form-select form-select-sm">
                <option value="">All plants</option>
                <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(request('plant_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">From date</label>
            <input type="date" name="date_from" value="<?php echo e(request('date_from', $financialYear->dateFrom ?? '')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label small">To date</label>
            <input type="date" name="date_to" value="<?php echo e(request('date_to', $financialYear->dateTo ?? '')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->anyFilled(['fy', 'plant_id', 'date_from', 'date_to'])): ?>
                <a href="<?php echo e(route('ho.purchase-list.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Supplier</th>
                    <th class="text-end">Orders</th>
                    <th class="text-end">Total Amount</th>
                    <th class="text-end">Paid</th>
                    <th class="text-end">Balance</th>
                    <th class="text-end" style="width: 140px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $supplierTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($row->supplier?->name ?? 'Unknown'); ?></td>
                    <td class="text-end"><?php echo e($row->order_count); ?></td>
                    <td class="text-end fw-semibold">₹<?php echo e(number_format($row->total_amount, 2)); ?></td>
                    <td class="text-end">₹<?php echo e(number_format($row->paid_amount, 2)); ?></td>
                    <td class="text-end fw-semibold">₹<?php echo e(number_format($row->balance, 2)); ?></td>
                    <td class="text-end">
                        <?php if($row->supplier): ?>
                            <button type="button"
                                class="btn btn-sm btn-admin-outline btn-add-payment"
                                data-supplier-name="<?php echo e($row->supplier->name); ?>"
                                data-payment-url="<?php echo e(route('ho.purchase-list.payments.store', $row->supplier)); ?>">
                                <i class="bi bi-cash-coin me-1"></i>Add Payment
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="admin-empty">No purchases for the selected financial year.</div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="supplierPaymentModal" tabindex="-1" aria-labelledby="supplierPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" id="supplier_payment_form">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="supplierPaymentModalLabel">Add Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-3">Record payment for <strong id="payment_supplier_name">—</strong></p>
                    <div class="mb-3">
                        <label class="form-label small mb-1" for="payment_amount">Amount (₹)</label>
                        <input type="number" name="amount" id="payment_amount" class="form-control form-control-sm"
                            step="0.01" min="0.01" required placeholder="0.00">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small mb-1" for="payment_date">Payment date</label>
                        <input type="date" name="payment_date" id="payment_date" class="form-control form-control-sm"
                            value="<?php echo e(now()->toDateString()); ?>" required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label small mb-1" for="payment_notes">Notes <span class="text-muted">(optional)</span></label>
                        <textarea name="notes" id="payment_notes" rows="2" class="form-control form-control-sm"
                            maxlength="2000" placeholder="Cheque no / UTR / remark..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-admin-outline btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-admin-primary btn-sm">
                        <i class="bi bi-check-lg me-1"></i>Save payment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const modalEl = document.getElementById('supplierPaymentModal');
    const form = document.getElementById('supplier_payment_form');
    if (!modalEl || !form) return;

    const modal = new bootstrap.Modal(modalEl);

    document.querySelectorAll('.btn-add-payment').forEach(function (btn) {
        btn.addEventListener('click', function () {
            form.action = btn.dataset.paymentUrl || '';
            document.getElementById('payment_supplier_name').textContent = btn.dataset.supplierName || '—';
            document.getElementById('payment_amount').value = '';
            document.getElementById('payment_date').value = '<?php echo e(now()->toDateString()); ?>';
            document.getElementById('payment_notes').value = '';
            modal.show();
        });
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\ho\request-po\purchase-list\index.blade.php ENDPATH**/ ?>