<?php $__env->startSection('title', 'Stocks'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Stock Balances','subtitle' => ''.e(($isPurchaser ?? false) ? 'Inventory across all plants' : 'Current inventory in this plant').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock Balances','subtitle' => ''.e(($isPurchaser ?? false) ? 'Inventory across all plants' : 'Current inventory in this plant').'']); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <?php if($isPurchaser ?? false): ?>
        <div class="col-12 col-md-3">
            <label class="form-label small">Plant</label>
            <select name="plant_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All plants</option>
                <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plant->id); ?>" <?php if(request('plant_id') == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="col-12 col-md-4 position-relative">
            <label class="form-label small">Search Item Name / SKU</label>
            <input type="text" name="search" id="product-search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm" placeholder="Enter item name or SKU..." autocomplete="off">
            <div id="autocomplete-suggestions" class="autocomplete-suggestions d-none shadow border rounded-bottom bg-white"></div>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label small">Filter by Product</label>
            <select name="product_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All products</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(request('product_id') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->anyFilled(['product_id', 'search', 'plant_id'])): ?>
                <a href="<?php echo e(route('plant.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <?php if($isPurchaser ?? false): ?>
                    <th>Plant</th>
                    <?php endif; ?>
                    <th>Product</th>
                    <th>SKU</th>
                    <th class="text-end">Reorder Level</th>
                    <th class="text-end">Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php if($balances->count() > 0): ?>
                <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isLow = $b->quantity <= ($b->product->reorder_level ?? 0);
                ?>
                <tr <?php if($isLow): ?> class="table-warning" <?php endif; ?>>
                    <?php if($isPurchaser ?? false): ?>
                    <td class="small"><?php echo e($b->plant?->name ?? '—'); ?></td>
                    <?php endif; ?>
                    <td class="fw-semibold">
                        <?php echo e($b->product->name); ?>

                        <?php if($isLow): ?>
                            <span class="badge bg-danger ms-2" style="font-size: 0.65rem;">Low Stock</span>
                        <?php endif; ?>
                    </td>
                    <td><code class="small text-muted"><?php echo e($b->product->sku); ?></code></td>
                    <td class="text-end text-muted"><?php echo e($b->product->reorder_level); ?> <?php echo e($b->product->unit->abbreviation ?? ''); ?></td>
                    <td class="text-end fw-bold <?php echo e($isLow ? 'text-danger' : 'text-success'); ?>">
                        <?php echo e($b->quantity); ?> <?php echo e($b->product->unit->abbreviation ?? ''); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($selectedProduct): ?>
                <tr>
                    <?php if($isPurchaser ?? false): ?>
                    <td class="small text-muted">—</td>
                    <?php endif; ?>
                    <td class="fw-semibold"><?php echo e($selectedProduct->name); ?></td>
                    <td><code class="small text-muted"><?php echo e($selectedProduct->sku); ?></code></td>
                    <td class="text-end text-muted"><?php echo e($selectedProduct->reorder_level); ?> <?php echo e($selectedProduct->unit->abbreviation ?? ''); ?></td>
                    <td class="text-end fw-bold text-muted">0 <?php echo e($selectedProduct->unit->abbreviation ?? ''); ?></td>
                </tr>
                <?php else: ?>
                <tr>
                    <td colspan="<?php echo e(($isPurchaser ?? false) ? 5 : 4); ?>">
                        <div class="admin-empty"><i class="bi bi-boxes d-block"></i>No stock records found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($balances->links()); ?></div>

<?php $__env->startPush('scripts'); ?>
<style>
.autocomplete-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    max-height: 250px;
    overflow-y: auto;
    z-index: 1050;
    margin-top: 2px;
}
.suggestion-item {
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}
.suggestion-item:hover {
    background-color: #f8f9fa;
}
.suggestion-item:last-child {
    border-bottom: none !important;
}
</style>
<?php echo $__env->make('partials.infinite-suggestions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php
    $stockProductSearch = $products->map(fn ($p) => [
        'id' => $p->id,
        'name' => $p->name,
        'sku' => $p->sku ?? '',
    ])->values();
?>
<script type="application/json" id="stock-products-data"><?php echo json_encode($stockProductSearch, 15, 512) ?></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('product-search');
    const suggestionsBox = document.getElementById('autocomplete-suggestions');
    const productsDataEl = document.getElementById('stock-products-data');
    if (!searchInput || !suggestionsBox || !productsDataEl) {
        return;
    }

    const products = JSON.parse(productsDataEl.textContent);

    const infinite = window.PanchmukhiInfiniteSuggestions.create(suggestionsBox, {
        pageSize: 25,
        renderItem: function (p) {
            const div = document.createElement('div');
            div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
            div.innerHTML = `<span class="fw-semibold text-dark d-block text-truncate" style="max-width:100%">${p.name}</span> <span class="text-muted small">${p.sku}</span>`;
            div.addEventListener('click', function() {
                searchInput.value = p.name;
                infinite.reset();
                suggestionsBox.classList.add('d-none');
                searchInput.form.submit();
            });
            return div;
        },
    });

    searchInput.addEventListener('input', function() {
        const val = this.value.trim().toLowerCase();

        if (!val) {
            infinite.reset();
            suggestionsBox.classList.add('d-none');
            return;
        }

        const filtered = products.filter(function(p) {
            return p.name.toLowerCase().includes(val) ||
                (p.sku && p.sku.toLowerCase().includes(val));
        });

        if (!infinite.setResults(filtered)) {
            suggestionsBox.classList.add('d-none');
            return;
        }

        suggestionsBox.classList.remove('d-none');
    });

    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
            infinite.reset();
            suggestionsBox.classList.add('d-none');
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/inventory/stocks/index.blade.php ENDPATH**/ ?>