<?php
    $index = $index ?? 0;
    $oldItem = old("items.{$index}", []);
?>
<div class="col-md-2">
    <label class="form-label">Category</label>
    <select name="items[<?php echo e($index); ?>][category_id]" class="form-select form-select-sm item-category-select" required>
        <option value="">Select category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if(($oldItem['category_id'] ?? '') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-md-2">
    <label class="form-label">Item Type</label>
    <select name="items[<?php echo e($index); ?>][sub_category_id]" class="form-select form-select-sm item-subcategory-select"
        required>
        <option value="">Select Item Type</option>
        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($sc->id); ?>" data-category-id="<?php echo e($sc->category_id); ?>" <?php if(($oldItem['sub_category_id'] ?? '') == $sc->id): echo 'selected'; endif; ?>><?php echo e($sc->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-md-2">
    <label class="form-label">Product</label>
    <select name="items[<?php echo e($index); ?>][product_id]" class="form-select form-select-sm item-product-select" required>
        <option value="">Select product</option>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>" data-subcategory-id="<?php echo e($p->sub_category_id); ?>" <?php if(($oldItem['product_id'] ?? '') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-md-1">
    <label class="form-label">Qty</label>
    <input type="number" step="1" min="1" name="items[<?php echo e($index); ?>][quantity]" value="<?php echo e($oldItem['quantity'] ?? 1); ?>"
        required class="form-control form-control-sm">
</div>
<div class="col-md-1">
    <label class="form-label">Priority</label>
    <select name="items[<?php echo e($index); ?>][priority]" class="form-select form-select-sm" required>
        <?php $__currentLoopData = \App\Enums\PriorityLevel::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($priority->value); ?>" <?php if(($oldItem['priority'] ?? 'medium') === $priority->value): echo 'selected'; endif; ?>>
                <?php echo e($priority->label()); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="col-md-2">
    <label class="form-label">Remark</label>
    <input type="text" name="items[<?php echo e($index); ?>][remarks]" value="<?php echo e($oldItem['remarks'] ?? ''); ?>"
        class="form-control form-control-sm" placeholder="Optional remark">
</div>
<div class="col-md-2">
    <label class="form-label">Image</label>
    <input type="file" name="items[<?php echo e($index); ?>][image]" class="form-control form-control-sm" accept="image/*">
</div>
<div class="col-md-1 text-end">
    <label class="form-label d-md-none">&nbsp;</label>
    <button type="button" class="btn btn-sm btn-outline-danger w-100" onclick="removeDynamicRow(this)">Remove</button>
</div><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/partials/request-item-line-row.blade.php ENDPATH**/ ?>