<?php $__env->startSection('title', 'Product Request #' . $productRequest->id); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Request #'.e($productRequest->id).'','subtitle' => ''.e($productRequest->plant->name).' · '.e($productRequest->displayRequesterName()).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Request #'.e($productRequest->id).'','subtitle' => ''.e($productRequest->plant->name).' · '.e($productRequest->displayRequesterName()).'']); ?>
        <div class="d-flex align-items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $productRequest->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productRequest->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
            <?php if(auth()->user()->isPurchaser() && in_array($productRequest->status->value, ['submitted', 'in_progress'])): ?>
                <a href="<?php echo e(route('plant.product-requests.edit', $productRequest)); ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-pencil me-1"></i>Edit
                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <?php if($productRequest->remarks): ?>
        <div class="admin-card mb-4">
            <div class="admin-card-body">
                <p class="mb-0 small"><strong>Remarks:</strong> <?php echo e($productRequest->remarks); ?></p>
            </div>
        </div>
    <?php endif; ?>

    <div class="admin-card admin-table-card mb-4">
        <div class="admin-card-header">
            <h2>Requested Items</h2>
        </div>
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Item Type</th>
                        <th>Item Name</th>
                        <th>Size</th>
                        <?php if(auth()->user()->isPurchaser()): ?>
                            <th>Supplier</th>
                            <th class="text-end">Rate</th>
                            <th class="text-end">GST %</th>
                        <?php endif; ?>
                        <th class="text-end">Quantity</th>
                        <th>Remark</th>
                        <th>Image</th>
                        <th class="text-end">In Stock</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->subCategory?->name ?? $item->product?->subCategory?->name ?? '—'); ?></td>
                            <td>
                                <?php echo e($item->displayName()); ?>

                                <?php if($item->product?->sku): ?>
                                    <span class="d-block small text-muted text-uppercase">SKU: <?php echo e($item->product->sku); ?></span>
                                <?php elseif(!$item->product_id): ?>
                                    <span class="d-block small text-muted">Not in catalog</span>
                                    <?php if(auth()->user()->canManagePlantProducts()): ?>
                                        <a href="<?php echo e(route('plant.products.create', [
                                            'name' => $item->displayName(),
                                            'size' => $item->size,
                                            'category_id' => $item->subCategory?->category_id ?? $item->product?->category_id,
                                            'sub_category_id' => $item->sub_category_id,
                                            'product_request_id' => $productRequest->id,
                                            'product_request_item_id' => $item->id,
                                        ])); ?>"
                                            class="d-inline-flex align-items-center gap-1 small text-primary mt-1">
                                            <i class="bi bi-plus-circle"></i>Add Product
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->size ?? $item->product?->size ?? '—'); ?></td>
                            <?php if(auth()->user()->isPurchaser()): ?>
                                <td><?php echo e($item->supplier?->name ?? '—'); ?></td>
                                <td class="text-end"><?php echo e($item->unit_price); ?></td>
                                <td class="text-end"><?php echo e($item->gst_rate); ?>%</td>
                            <?php endif; ?>
                            <td class="text-end"><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->remarks ?? '—'); ?></td>
                            <td>
                                <?php if($item->image_path): ?>
                                    <a href="<?php echo e($item->image_url); ?>" target="_blank"
                                        class="btn btn-xs btn-outline-primary py-0 px-1" style="font-size: 0.75rem;">
                                        <i class="bi bi-image me-1"></i>View
                                    </a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($item->product_id): ?>
                                    <span class="stock-check"
                                        data-url="<?php echo e(route('plant.api.stock.check', ['plant' => $productRequest->plant_id, 'product' => $item->product_id])); ?>">…</span>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if(auth()->user()->isPurchaser()): ?>
        <?php if($productRequest->purchaseRequest): ?>
            <div class="admin-card mb-4 bg-light border-success">
                <div class="admin-card-body">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <div>
                            <h5 class="mb-1 text-success"><i class="bi bi-check-circle-fill me-2"></i>Converted to Purchase Request
                            </h5>
                            <p class="mb-0 text-muted small">Purchase Request:
                                <strong>#<?php echo e($productRequest->purchaseRequest->id); ?></strong>
                                (<?php echo e($productRequest->purchaseRequest->status->label()); ?>)
                            </p>
                        </div>
                        <div>
                            <?php if($productRequest->purchaseRequest->purchases->isNotEmpty()): ?>
                                <?php if($productRequest->purchaseRequest->purchases->count() === 1): ?>
                                    <?php $po = $productRequest->purchaseRequest->purchases->first(); ?>
                                    <a href="<?php echo e(route('plant.purchases.show', $po)); ?>" class="btn btn-admin-outline btn-sm">
                                        View PO: <code><?php echo e($po->reference_no); ?></code>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('plant.purchases.index', ['purchase_request_id' => $productRequest->purchaseRequest->id])); ?>"
                                        class="btn btn-admin-outline btn-sm">
                                        View <?php echo e($productRequest->purchaseRequest->purchases->count()); ?> POs
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('plant.product-requests.export-supplier', $productRequest)); ?>" class="btn btn-admin-outline btn-sm">
                                    <i class="bi bi-file-earmark-excel me-1"></i>Export for Supplier
                                </a>
                                <a href="<?php echo e(route('plant.purchases.create', ['purchase_request_id' => $productRequest->purchaseRequest->id])); ?>"
                                    class="btn btn-warning btn-sm">
                                    <i class="bi bi-cart-plus me-1"></i>Create Purchase Order
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif(!in_array($productRequest->status->value, ['cancelled'])): ?>
            <div class="admin-card mb-4 bg-light">
                <div class="admin-card-body">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <div>
                            <h5 class="mb-1">Create Purchase Order</h5>
                            <p class="mb-0 text-muted small">Export the product list for the supplier, then create the PO.</p>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="<?php echo e(route('plant.product-requests.export-supplier', $productRequest)); ?>" class="btn btn-admin-outline btn-sm">
                                <i class="bi bi-file-earmark-excel me-1"></i>Export for Supplier
                            </a>
                            <form method="POST" action="<?php echo e(route('plant.product-requests.convert', $productRequest)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-warning btn-sm">
                                    <i class="bi bi-cart-plus me-1"></i>Create PO
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php elseif($productRequest->purchaseRequest): ?>
        <a href="<?php echo e(route('plant.purchase-requests.show', $productRequest->purchaseRequest)); ?>"
            class="btn btn-admin-outline btn-sm">View Purchase Request</a>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.querySelectorAll('.stock-check').forEach(el => {
                fetch(el.dataset.url, { headers: { 'Accept': 'application/json' } })
                    .then(r => r.json()).then(d => el.textContent = d.quantity ?? '0').catch(() => el.textContent = '—');
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi\resources\views/plant/request-po/product-requests/show.blade.php ENDPATH**/ ?>