Hello <?php echo e($purchase->supplier->name); ?>,

Please find attached our Purchase Order <?php echo e($purchase->reference_no); ?> dated <?php echo e($purchase->ordered_at?->format('d M Y') ?? now()->format('d M Y')); ?>.

Plant: <?php echo e($purchase->plant->name); ?>

Grand Total: Rs.<?php echo e(number_format((float) $purchase->grand_total, 2)); ?>


Regards,
<?php echo e($companyName); ?>

<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\mail\purchase-order.blade.php ENDPATH**/ ?>