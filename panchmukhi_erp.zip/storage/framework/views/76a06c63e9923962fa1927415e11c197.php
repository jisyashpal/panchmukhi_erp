<a href="<?php echo e(request()->fullUrlWithQuery(['export' => 'excel'])); ?>" class="btn btn-success btn-sm">
    <i class="bi bi-file-earmark-excel me-1"></i>Export Excel
</a>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/components/report-export-button.blade.php ENDPATH**/ ?>