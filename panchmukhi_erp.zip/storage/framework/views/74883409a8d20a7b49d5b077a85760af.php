<?php
    $showRemove = $showRemove ?? true;
    $showLineTotal = $showLineTotal ?? false;
    $supplierId = $supplierId ?? null;
?>
<tr class="dynamic-row purchase-line-row">
    <td class="purchase-col-product">
        <input type="text"
               value="<?php echo e(isset($productId) && ($selectedProduct = $products->firstWhere('id', (int) $productId)) ? $selectedProduct->name : ''); ?>"
               class="form-control form-control-sm purchase-line-input purchase-item-name-input"
               placeholder="Search item name or SKU..."
               required
               autocomplete="off">
        <input type="hidden"
               name="items[<?php echo e($i); ?>][product_id]"
               value="<?php echo e($productId ?? ''); ?>"
               class="purchase-item-product-id">
    </td>
    <td class="purchase-col-supplier">
        <select name="items[<?php echo e($i); ?>][supplier_id]" required class="form-select form-select-sm purchase-line-input purchase-supplier-select">
            <option value="">— Select —</option>
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>" <?php if(old("items.$i.supplier_id", $supplierId) == $s->id): echo 'selected'; endif; ?>>
                    <?php echo e($s->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td class="purchase-col-num purchase-col-qty">
        <input type="number" step="0.01" min="0.01" name="items[<?php echo e($i); ?>][quantity]" value="<?php echo e($quantity ?? 1); ?>" required
               class="form-control form-control-sm purchase-line-input purchase-num-input">
    </td>
    <td class="purchase-col-num purchase-col-rate">
        <input type="number" step="0.01" min="0" name="items[<?php echo e($i); ?>][unit_price]" value="<?php echo e($unitPrice ?? 0); ?>" required
               class="form-control form-control-sm purchase-line-input purchase-num-input" placeholder="0.00">
    </td>
    <td class="purchase-col-num">
        <input type="number" step="0.01" min="0" max="100" name="items[<?php echo e($i); ?>][discount_percent]" value="<?php echo e($discountPercent ?? 0); ?>"
               class="form-control form-control-sm purchase-line-input purchase-num-input" placeholder="0">
    </td>
    <td class="purchase-col-num purchase-col-gst">
        <select name="items[<?php echo e($i); ?>][gst_rate]" class="form-select form-select-sm purchase-line-input purchase-num-input">
            <?php $__currentLoopData = [0, 5, 12, 18, 28]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rate); ?>" <?php if(($gstRate ?? 18) == $rate): echo 'selected'; endif; ?>><?php echo e($rate); ?> %</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <?php if($showLineTotal): ?>
    <td class="purchase-col-num purchase-col-total purchase-line-total-cell">
        <span class="purchase-line-total">₹0.00</span>
    </td>
    <?php endif; ?>
    <?php if($showRemove): ?>
    <td class="purchase-col-action">
        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeDynamicRow(this)" title="Remove line" aria-label="Remove line">
            <i class="bi bi-trash" aria-hidden="true"></i>
        </button>
    </td>
    <?php endif; ?>
</tr>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\partials\purchase-line-fields.blade.php ENDPATH**/ ?>