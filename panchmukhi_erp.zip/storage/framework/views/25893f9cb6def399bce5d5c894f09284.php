<?php $__env->startSection('title', 'Product Request #' . $productRequest->id); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Request #'.e($productRequest->id).'','subtitle' => ''.e($productRequest->plant->name).' · '.e($productRequest->displayRequesterName()).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Request #'.e($productRequest->id).'','subtitle' => ''.e($productRequest->plant->name).' · '.e($productRequest->displayRequesterName()).'']); ?>
        <div class="d-flex gap-2">
            <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $productRequest->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productRequest->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
            <a href="<?php echo e(route('ho.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <?php if($productRequest->remarks): ?>
        <div class="admin-card mb-4">
            <div class="admin-card-body">
                <p class="mb-0 small"><strong>Remarks:</strong> <?php echo e($productRequest->remarks); ?></p>
            </div>
        </div>
    <?php endif; ?>

    <div class="admin-card admin-table-card mb-4">
        <div class="admin-card-header">
            <h2>Requested Items</h2>
        </div>
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Item Type</th>
                        <th>Item Name</th>
                        <th>Size</th>
                        <th>Supplier</th>
                        <th class="text-end">Qty</th>
                        <th class="text-end">Rate</th>
                        <th class="text-end">GST %</th>
                        <th>Remark</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->subCategory?->name ?? $item->product?->subCategory?->name ?? '—'); ?></td>
                            <td>
                                <?php echo e($item->displayName()); ?>

                                <?php if($item->product?->sku): ?>
                                    <span class="d-block small text-muted text-uppercase">SKU: <?php echo e($item->product->sku); ?></span>
                                <?php elseif(!$item->product_id): ?>
                                    <span class="d-block small text-muted">Custom item</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->size ?? $item->product?->size ?? '—'); ?></td>
                            <td><?php echo e($item->supplier?->name ?? '—'); ?></td>
                            <td class="text-end"><?php echo e($item->quantity); ?></td>
                            <td class="text-end"><?php echo e($item->unit_price); ?></td>
                            <td class="text-end"><?php echo e($item->gst_rate); ?>%</td>
                            <td><?php echo e($item->remarks ?? '—'); ?></td>
                            <td>
                                <?php if($item->image_path): ?>
                                    <a href="<?php echo e($item->image_url); ?>" target="_blank"
                                        class="btn btn-xs btn-outline-primary py-0 px-1" style="font-size: 0.75rem;">
                                        <i class="bi bi-image me-1"></i>View
                                    </a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if($productRequest->purchaseRequest?->purchases->isNotEmpty()): ?>
        <div class="admin-card mb-4 bg-light border-success">
            <div class="admin-card-body">
                <h5 class="mb-1 text-success"><i class="bi bi-check-circle-fill me-2"></i>Purchase order created by purchaser
                </h5>
                <p class="mb-0 text-muted small">
                    Purchase Request #<?php echo e($productRequest->purchaseRequest->id); ?>

                    · <?php echo e($productRequest->purchaseRequest->purchases->count()); ?> PO(s)
                </p>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!in_array($productRequest->status->value, ['completed', 'cancelled'])): ?>
        <div class="admin-card">
            <div class="admin-card-body d-flex flex-wrap gap-2">
                <form method="POST" action="<?php echo e(route('ho.product-requests.status', $productRequest)); ?>"><?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="in_progress">
                    <button class="btn btn-warning btn-sm">Mark In Progress</button>
                </form>
                <form method="POST" action="<?php echo e(route('ho.product-requests.status', $productRequest)); ?>"><?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="completed">
                    <button class="btn btn-success btn-sm">Mark Completed</button>
                </form>
                <form method="POST" action="<?php echo e(route('ho.product-requests.status', $productRequest)); ?>" class="d-flex gap-2">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="cancelled">
                    <input type="text" name="reason" class="form-control form-control-sm" placeholder="Cancel reason">
                    <button class="btn btn-outline-danger btn-sm">Cancel</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi\resources\views/ho/request-po/product-requests/show.blade.php ENDPATH**/ ?>