<?php $__env->startSection('title', 'Add User'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Add User','subtitle' => 'Create a user and assign role (plant only when required)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add User','subtitle' => 'Create a user and assign role (plant only when required)']); ?>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-admin-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('admin.users.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Name','name' => 'name','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','name' => 'name','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Email','name' => 'email','type' => 'email','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'email','type' => 'email','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Password','name' => 'password','type' => 'password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password','name' => 'password','type' => 'password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Confirm Password','name' => 'password_confirmation','type' => 'password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Confirm Password','name' => 'password_confirmation','type' => 'password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Role','name' => 'role_id','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Role','name' => 'role_id','required' => true]); ?>
                    <select name="role_id" id="role_id" class="form-select" required>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($r->id); ?>"
                                data-requires-plant="<?php echo e($r->requires_plant ? '1' : '0'); ?>"
                                data-role-slug="<?php echo e($r->slug); ?>"
                                <?php if(old('role_id') == $r->id): echo 'selected'; endif; ?>
                            ><?php echo e($r->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Plant','name' => 'plant_id','id' => 'plant-field']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Plant','name' => 'plant_id','id' => 'plant-field']); ?>
                    <select name="plant_id" id="plant_id" class="form-select">
                        <option value="">—</option>
                        <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php if(old('plant_id') == $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <div class="col-12">
                    <div class="form-check">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" class="form-check-input" id="active" <?php if(old('is_active', '1') == '1'): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-admin-primary">Save User</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    function togglePlantField() {
        var select = document.getElementById('role_id');
        var opt = select.options[select.selectedIndex];
        var requiresPlant = opt && opt.dataset.requiresPlant === '1' && opt.dataset.roleSlug !== 'purchaser';
        document.getElementById('plant-field').style.display = requiresPlant ? 'block' : 'none';
        if (!requiresPlant) {
            document.getElementById('plant_id').value = '';
        }
    }
    document.getElementById('role_id').addEventListener('change', togglePlantField);
    togglePlantField();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\admin\master\users\create.blade.php ENDPATH**/ ?>