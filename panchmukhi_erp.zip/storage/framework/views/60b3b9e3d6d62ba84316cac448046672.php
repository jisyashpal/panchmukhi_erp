<?php $__env->startSection('title', $product->name . ' — Stock Movements'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $unit = $product->unit->abbreviation ?? $product->unit->name ?? '';
        $isFilteredPeriod = $dateFrom !== $financialYearRange->dateFrom || $dateTo !== $financialYearRange->dateTo;
        $periodLabel = $isFilteredPeriod
            ? \Carbon\Carbon::parse($dateFrom)->format('d M Y') . ' – ' . \Carbon\Carbon::parse($dateTo)->format('d M Y')
            : $financialYearRange->displayLabel();
    ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => ''.e($product->name).'','subtitle' => ''.e($plant->name).' · '.e($periodLabel).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($product->name).'','subtitle' => ''.e($plant->name).' · '.e($periodLabel).'']); ?>
        <a href="<?php echo e(route('ho.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Back</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <div class="admin-filters mb-3">
        <form method="GET" class="row g-2 align-items-end">
            <input type="hidden" name="plant_id" value="<?php echo e(request('plant_id')); ?>">
            <input type="hidden" name="product_id" value="<?php echo e(request('product_id')); ?>">
            <div class="col-6 col-md-2">
                <label class="form-label small" for="date_from">From</label>
                <input type="date" name="date_from" id="date_from" value="<?php echo e($dateFrom); ?>"
                    min="<?php echo e($financialYearRange->dateFrom); ?>" max="<?php echo e($financialYearRange->dateTo); ?>"
                    class="form-control form-control-sm">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small" for="date_to">To</label>
                <input type="date" name="date_to" id="date_to" value="<?php echo e($dateTo); ?>"
                    min="<?php echo e($financialYearRange->dateFrom); ?>" max="<?php echo e($financialYearRange->dateTo); ?>"
                    class="form-control form-control-sm">
            </div>
            <div class="col-auto d-flex gap-1">
                <button type="submit" class="btn btn-admin-primary btn-sm">
                    <i class="bi bi-funnel me-1"></i>Filter
                </button>
                <?php if($isFilteredPeriod): ?>
                    <a href="<?php echo e(route('ho.stocks.show', ['plant_id' => request('plant_id'), 'product_id' => request('product_id')])); ?>"
                        class="btn btn-admin-outline btn-sm">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-sm-4">
            <div class="admin-card admin-card-body">
                <div class="text-muted small">Current Stock</div>
                <div class="h5 mb-0 fw-bold"><?php echo e(number_format($balance?->quantity ?? 0, 2)); ?> <?php echo e($unit); ?></div>
                <div class="small text-muted mt-1">Est. Value:
                    ₹<?php echo e(number_format(($balance?->quantity ?? 0) * $latestRate, 2)); ?></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="admin-card admin-card-body">
                <div class="text-muted small">Stock In (Receipts)</div>
                <div class="h5 mb-0 text-success fw-bold"><?php echo e(number_format($periodStockIn, 2)); ?> <?php echo e($unit); ?></div>
                <div class="small text-muted mt-1">Total Cost: ₹<?php echo e(number_format($totalValueIn, 2)); ?></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="admin-card admin-card-body">
                <div class="text-muted small">Stock Out (Consumption)</div>
                <div class="h5 mb-0 text-danger fw-bold"><?php echo e(number_format($periodStockOut, 2)); ?> <?php echo e($unit); ?></div>
                <div class="small text-muted mt-1">Total Expense: ₹<?php echo e(number_format($totalValueOut, 2)); ?></div>
            </div>
        </div>
    </div>

    <div class="admin-card admin-table-card">
        <div class="admin-card-header">
            <h2 class="h6 mb-0">Stock Ledger</h2>
        </div>
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Where / Source / Destination</th>
                        <th class="text-end">Rate</th>
                        <th class="text-end">Receipt (In)</th>
                        <th class="text-end">Issue (Out)</th>
                        <th class="text-end">Trans. Value</th>
                        <th class="text-end">Running Bal.</th>
                        <th>Notes</th>
                        <th>By</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Opening Balance Row -->
                    <tr class="table-light">
                        <td class="small text-muted">—</td>
                        <td><span class="badge bg-secondary-subtle text-secondary">Opening</span></td>
                        <td class="fw-semibold">Opening Balance as of
                            <?php echo e(\Carbon\Carbon::parse($dateFrom)->format('d M Y')); ?></td>
                        <td class="text-end">₹<?php echo e(number_format($openingRate, 2)); ?></td>
                        <td class="text-end text-muted">—</td>
                        <td class="text-end text-muted">—</td>
                        <td class="text-end fw-semibold">₹<?php echo e(number_format($openingValue, 2)); ?></td>
                        <td class="text-end fw-bold text-dark"><?php echo e(number_format($openingBalance, 2)); ?> <?php echo e($unit); ?></td>
                        <td class="text-muted small">—</td>
                        <td class="text-muted small">—</td>
                    </tr>

                    <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="small text-muted"><?php echo e($m->moved_at->format('d M Y H:i')); ?></td>
                            <td>
                                <?php if($m->type === \App\Enums\StockMovementType::In): ?>
                                    <span class="badge bg-success-subtle text-success">Receipt</span>
                                <?php else: ?>
                                    <span class="badge bg-danger-subtle text-danger">Issue</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($m->type === \App\Enums\StockMovementType::In): ?>
                                    <?php if($m->reference_type === \App\Enums\StockReferenceType::Purchase && $m->reference_id): ?>
                                        PO: <?php echo e($purchaseReferences[$m->reference_id] ?? '#' . $m->reference_id); ?>

                                    <?php else: ?>
                                        Stock In
                                    <?php endif; ?>
                                    <?php if($m->supplier): ?>
                                        <br><span class="text-muted small">Supplier: <?php echo e($m->supplier->name); ?></span>
                                    <?php endif; ?>
                                <?php elseif($m->vehicle): ?>
                                    Vehicle: <?php echo e($m->vehicle->displayLabel()); ?>

                                <?php elseif($m->subCategory): ?>
                                    Item Type: <?php echo e($m->subCategory->name); ?>

                                <?php elseif(filled($m->reason)): ?>
                                    Reason: <?php echo e($m->reason); ?>

                                <?php else: ?>
                                    Other / plant use
                                <?php endif; ?>
                            </td>
                            <td class="text-end">₹<?php echo e(number_format($m->rate, 2)); ?></td>
                            <td class="text-end text-success">
                                <?php if($m->type === \App\Enums\StockMovementType::In): ?>
                                    +<?php echo e(number_format($m->quantity, 2)); ?> <?php echo e($unit); ?>

                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="text-end text-danger">
                                <?php if($m->type === \App\Enums\StockMovementType::Out): ?>
                                    -<?php echo e(number_format($m->quantity, 2)); ?> <?php echo e($unit); ?>

                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td
                                class="text-end fw-semibold <?php echo e($m->type === \App\Enums\StockMovementType::In ? 'text-success' : 'text-danger'); ?>">
                                ₹<?php echo e(number_format($m->value, 2)); ?>

                            </td>
                            <td class="text-end fw-bold">
                                <?php echo e(number_format($m->running_balance, 2)); ?> <?php echo e($unit); ?>

                            </td>
                            <td class="text-muted small"><?php echo e($m->notes ?? '—'); ?></td>
                            <td class="text-muted small"><?php echo e($m->performer?->name ?? '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10">
                                <div class="admin-empty">No movements for <?php echo e($periodLabel); ?></div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <?php if($movements->isNotEmpty() || $openingBalance > 0): ?>
                    <tfoot>
                        <tr class="table-light fw-bold">
                            <td colspan="3">Closing Balance as of <?php echo e(\Carbon\Carbon::parse($dateTo)->format('d M Y')); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($latestRate, 2)); ?></td>
                            <td class="text-end text-success">+<?php echo e(number_format($periodStockIn, 2)); ?> <?php echo e($unit); ?></td>
                            <td class="text-end text-danger">-<?php echo e(number_format($periodStockOut, 2)); ?> <?php echo e($unit); ?></td>
                            <td class="text-end text-primary">
                                Net: ₹<?php echo e(number_format($totalValueIn - $totalValueOut, 2)); ?>

                            </td>
                            <td class="text-end text-primary fw-bold fs-6">
                                <?php echo e(number_format($movements->isEmpty() ? $openingBalance : $movements->last()->running_balance, 2)); ?>

                                <?php echo e($unit); ?>

                                <div class="small fw-normal text-muted mt-1" style="font-size: 0.75rem;">
                                    Value:
                                    ₹<?php echo e(number_format(($movements->isEmpty() ? $openingBalance : $movements->last()->running_balance) * $latestRate, 2)); ?>

                                </div>
                            </td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <!-- Usage Summary Card -->
    <?php if($usageSummary->isNotEmpty()): ?>
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-white border-0 py-3">
                <h3 class="h6 mb-0 text-dark fw-bold">
                    <i class="bi bi-pie-chart-fill text-primary me-2"></i>Item Usage Summary (Consumption)
                </h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Used For / Destination</th>
                                <th class="text-end pe-4" style="width: 200px;">Quantity Consumed</th>
                                <th class="text-end pe-4" style="width: 250px;">Consumption Value / Expense</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $usageSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="ps-4 fw-semibold text-secondary"><?php echo e($destination); ?></td>
                                    <td class="text-end pe-4 fw-bold text-dark"><?php echo e(number_format($data['quantity'], 2)); ?>

                                        <?php echo e($unit); ?></td>
                                    <td class="text-end pe-4 fw-bold text-danger">₹<?php echo e(number_format($data['value'], 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-light fw-bold">
                                <td class="ps-4">Total Consumed (Stock Out)</td>
                                <td class="text-end pe-4 text-dark fs-6"><?php echo e(number_format($periodStockOut, 2)); ?> <?php echo e($unit); ?>

                                </td>
                                <td class="text-end pe-4 text-danger fw-bold fs-6">
                                    ₹<?php echo e(number_format($totalValueOut, 2)); ?>

                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\ho\inventory\stocks\show.blade.php ENDPATH**/ ?>