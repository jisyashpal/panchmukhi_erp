<?php $__env->startSection('title', 'Edit Product Request'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => $productRequest->items->count() === 1 ? 'Edit Product Request Item' : 'Edit Product Request','subtitle' => 'Request #'.e($productRequest->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productRequest->items->count() === 1 ? 'Edit Product Request Item' : 'Edit Product Request'),'subtitle' => 'Request #'.e($productRequest->id).'']); ?>
    <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Back
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?php echo e(route('plant.product-requests.update', $productRequest)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="row g-3">
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Requested By','name' => 'requested_by_display','col' => 'col-md-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Requested By','name' => 'requested_by_display','col' => 'col-md-4']); ?>
                    <input type="text"
                           value="<?php echo e($productRequest->displayRequesterName()); ?>"
                           class="form-control bg-light"
                           readonly>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Updated By','name' => 'updated_by_display','col' => 'col-md-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Updated By','name' => 'updated_by_display','col' => 'col-md-4']); ?>
                    <input type="text"
                           value="<?php echo e(auth()->user()->name); ?>"
                           class="form-control bg-light"
                           readonly>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Remarks','name' => 'remarks','col' => 'col-md-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Remarks','name' => 'remarks','col' => 'col-md-4']); ?>
                    <textarea name="remarks" class="form-control <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="1" placeholder="Enter remarks (optional)"><?php echo e(old('remarks', $productRequest->remarks)); ?></textarea>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
            </div>

            <h2 class="h6 mt-4 mb-3">Items</h2>
            <div class="table-responsive mb-3">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th style="min-width: 250px;">Product</th>
                            <?php if(isset($suppliers)): ?>
                                <th style="min-width: 200px;">Supplier</th>
                            <?php endif; ?>
                            <th class="text-end" style="width: 150px;">Quantity</th>
                            <th style="width: 140px;">Priority</th>
                            <th>Vehicle No / Machine No</th>
                            <th>Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productRequest->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="product-request-edit-row">
                                <td class="position-relative">
                                    <input type="text"
                                           name="items[<?php echo e($i); ?>][item_name]"
                                           value="<?php echo e(old('items.'.$i.'.item_name', $item->displayName())); ?>"
                                           class="form-control form-control-sm item-name-input <?php $__errorArgs = ['items.'.$i.'.item_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="Search item name or SKU..."
                                           required
                                           autocomplete="off">
                                    <input type="hidden"
                                           name="items[<?php echo e($i); ?>][product_id]"
                                           value="<?php echo e(old('items.'.$i.'.product_id', $item->product_id)); ?>"
                                           class="item-product-id">
                                    <input type="hidden" name="items[<?php echo e($i); ?>][id]" value="<?php echo e($item->id); ?>">
                                </td>
                                <?php if(isset($suppliers)): ?>
                                    <td>
                                        <select name="items[<?php echo e($i); ?>][supplier_id]" class="form-select form-select-sm">
                                            <option value="">-- Select Supplier --</option>
                                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($supplier->id); ?>" <?php if(old('items.'.$i.'.supplier_id', $item->supplier_id) == $supplier->id): echo 'selected'; endif; ?>>
                                                    <?php echo e($supplier->name); ?> <?php echo e($supplier->city ? '('.$supplier->city.')' : ''); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                <?php endif; ?>
                                <td class="text-end">
                                    <input type="number" step="1" min="1" name="items[<?php echo e($i); ?>][quantity]" 
                                           value="<?php echo e(old('items.'.$i.'.quantity', $item->quantity)); ?>" 
                                           required class="form-control text-end <?php $__errorArgs = ['items.'.$i.'.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="max-width: 150px; display: inline-block;">
                                </td>
                                <td>
                                    <select name="items[<?php echo e($i); ?>][priority]" class="form-select form-select-sm" required>
                                        <?php $__currentLoopData = \App\Enums\PriorityLevel::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($priority->value); ?>" <?php if(old('items.'.$i.'.priority', $item->priority?->value ?? 'medium') === $priority->value): echo 'selected'; endif; ?>>
                                                <?php echo e($priority->label()); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" name="items[<?php echo e($i); ?>][remarks]" 
                                           value="<?php echo e(old('items.'.$i.'.remarks', $item->remarks)); ?>" 
                                           class="form-control <?php $__errorArgs = ['items.'.$i.'.remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Vehicle / machine no">
                                </td>
                                <td>
                                    <?php if($item->image_path): ?>
                                        <div class="mb-1">
                                            <a href="<?php echo e($item->image_url); ?>" target="_blank" class="d-inline-block">
                                                <img src="<?php echo e($item->image_url); ?>" alt="Preview" class="img-thumbnail" style="max-height: 40px;">
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" name="items[<?php echo e($i); ?>][image]" class="form-control form-control-sm" accept="image/*">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <button type="submit" class="btn btn-admin-primary">
                <i class="bi bi-check2-circle me-1"></i>Save Changes
            </button>
            <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="btn btn-admin-outline">Cancel</a>
        </form>
    </div>
</div>

<?php
    $productCatalog = isset($products) ? $products->map(function ($p) {
        return [
            'id' => $p->id,
            'name' => $p->name,
            'sku' => $p->sku ?? '',
        ];
    })->values() : collect();
?>

<?php $__env->startPush('scripts'); ?>
<style>
#product-request-edit-autocomplete-portal {
    position: fixed;
    max-height: 250px;
    overflow-y: auto;
    z-index: 2000;
    display: none;
}
#product-request-edit-autocomplete-portal.is-open {
    display: block;
}
#product-request-edit-autocomplete-portal .suggestion-item {
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}
#product-request-edit-autocomplete-portal .suggestion-item:hover {
    background-color: #f8f9fa;
}
</style>
<?php echo $__env->make('partials.infinite-suggestions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script type="application/json" id="product-request-edit-catalog-data"><?php echo json_encode($productCatalog, 15, 512) ?></script>
<script>
(function() {
    const catalogEl = document.getElementById('product-request-edit-catalog-data');
    if (!catalogEl) return;
    const products = JSON.parse(catalogEl.textContent);
    let activeInput = null;
    let activeRow = null;

    const portal = document.createElement('div');
    portal.id = 'product-request-edit-autocomplete-portal';
    portal.className = 'autocomplete-suggestions shadow border rounded-bottom bg-white';
    document.body.appendChild(portal);

    const infinite = window.PanchmukhiInfiniteSuggestions.create(portal, {
        pageSize: 25,
        renderItem: function (product) {
            const div = document.createElement('div');
            div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
            div.innerHTML = '<span class="fw-semibold text-dark d-block text-truncate">'
                + product.name
                + '</span> <span class="text-muted small">'
                + (product.sku || 'No SKU')
                + '</span>';
            div.addEventListener('mousedown', function (event) {
                event.preventDefault();
                if (activeRow) {
                    applyProductSelection(activeRow, product);
                }
            });
            return div;
        },
    });

    function hideSuggestions() {
        infinite.reset();
        portal.classList.remove('is-open');
        activeInput = null;
        activeRow = null;
    }

    function positionPortal(input) {
        const rect = input.getBoundingClientRect();
        portal.style.top = (rect.bottom + 2) + 'px';
        portal.style.left = rect.left + 'px';
        portal.style.width = rect.width + 'px';
    }

    function applyProductSelection(row, product) {
        const input = row.querySelector('.item-name-input');
        const productIdInput = row.querySelector('.item-product-id');
        input.value = product.name;
        productIdInput.value = product.id;
        hideSuggestions();
    }

    function showSuggestions(input) {
        const row = input.closest('tr');
        if (!row) return;
        const val = input.value.trim().toLowerCase();
        activeInput = input;
        activeRow = row;

        const filtered = products.filter(function (product) {
            if (!val) return true;
            return product.name.toLowerCase().includes(val)
                || (product.sku && product.sku.toLowerCase().includes(val));
        });

        if (filtered.length === 0) {
            hideSuggestions();
            return;
        }

        infinite.setResults(filtered);
        positionPortal(input);
        portal.classList.add('is-open');
    }

    document.addEventListener('input', function (event) {
        if (event.target.matches('.item-name-input')) {
            const row = event.target.closest('tr');
            const productIdInput = row?.querySelector('.item-product-id');
            if (productIdInput) {
                productIdInput.value = '';
            }
            showSuggestions(event.target);
        }
    });

    document.addEventListener('focusin', function (event) {
        if (event.target.matches('.item-name-input')) {
            showSuggestions(event.target);
        }
    });

    document.addEventListener('click', function (event) {
        if (event.target.matches('.item-name-input')) {
            showSuggestions(event.target);
            return;
        }
        if (activeInput && (activeInput.contains(event.target) || portal.contains(event.target))) {
            return;
        }
        hideSuggestions();
    });

    window.addEventListener('scroll', function (event) {
        if (!activeInput || !portal.classList.contains('is-open')) return;
        if (portal.contains(event.target)) return;
        positionPortal(activeInput);
    }, true);

    window.addEventListener('resize', function () {
        if (activeInput && portal.classList.contains('is-open')) {
            positionPortal(activeInput);
        }
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/request-po/product-requests/edit.blade.php ENDPATH**/ ?>