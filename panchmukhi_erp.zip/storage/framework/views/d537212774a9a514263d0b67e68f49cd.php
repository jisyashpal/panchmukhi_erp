<aside class="sidebar-admin bg-dark text-white d-none d-lg-flex flex-column flex-shrink-0">
    <div class="sidebar-brand px-3 py-3 border-bottom border-secondary">
        <a href="<?php echo e(route('ho.dashboard')); ?>" class="text-white text-decoration-none d-flex align-items-center gap-2">
            <span class="sidebar-brand-icon rounded  d-flex align-items-center justify-content-center">
                <img src="<?php echo e(asset('img/PMCMPL.png')); ?>" alt="Panchmukhi" class="img-fluid rounded flex-shrink-0">
            </span>
            <!-- <span>
                <strong class="d-block lh-sm">Panchmukhi</strong>
                <small class="text-white-50">HO Data Operator</small>
            </span> -->
        </a>
    </div>

    <nav class="sidebar-nav flex-grow-1 overflow-auto py-2 px-2">
        <?php if (isset($component)) { $__componentOriginal4cb4f2672758c9af85d391d44bae6987 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cb4f2672758c9af85d391d44bae6987 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal-sidebar-menu','data' => ['portal' => 'ho']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal-sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['portal' => 'ho']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cb4f2672758c9af85d391d44bae6987)): ?>
<?php $attributes = $__attributesOriginal4cb4f2672758c9af85d391d44bae6987; ?>
<?php unset($__attributesOriginal4cb4f2672758c9af85d391d44bae6987); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cb4f2672758c9af85d391d44bae6987)): ?>
<?php $component = $__componentOriginal4cb4f2672758c9af85d391d44bae6987; ?>
<?php unset($__componentOriginal4cb4f2672758c9af85d391d44bae6987); ?>
<?php endif; ?>
    </nav>

    <div class="sidebar-footer border-top border-secondary p-3 mt-auto">
        <div class="d-flex align-items-center gap-2 mb-2">
            <span class="sidebar-user-avatar rounded-circle bg-secondary d-flex align-items-center justify-content-center">
                <i class="bi bi-person-fill"></i>
            </span>
            <div class="overflow-hidden">
                <div class="small fw-semibold text-truncate"><?php echo e(auth()->user()->name); ?></div>
                <div class="text-white-50 text-truncate" style="font-size: .7rem;">HO Data Operator</div>
            </div>
        </div>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger btn-sm w-100">
                <i class="bi bi-box-arrow-right me-1"></i> Logout
            </button>
        </form>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/partials/ho-sidebar.blade.php ENDPATH**/ ?>