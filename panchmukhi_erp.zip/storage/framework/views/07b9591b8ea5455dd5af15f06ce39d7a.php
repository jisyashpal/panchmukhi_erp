<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Reports','subtitle' => 'Analytics and summaries']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Reports','subtitle' => 'Analytics and summaries']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<div class="row g-3">
    <div class="col-md-6"><a href="<?php echo e(route('ho.reports.product-life')); ?>" class="admin-card admin-card-body text-decoration-none d-block"><h3 class="h6">Product Life Usage</h3><p class="small text-muted mb-0">Vehicle-wise changes with meter readings and life used</p></a></div>
    <div class="col-md-6"><a href="<?php echo e(route('ho.reports.category-purchase')); ?>" class="admin-card admin-card-body text-decoration-none d-block"><h3 class="h6">Category Purchase Summary</h3><p class="small text-muted mb-0">Purchase amount by category</p></a></div>
    <div class="col-md-6"><a href="<?php echo e(route('ho.reports.multiple-usage')); ?>" class="admin-card admin-card-body text-decoration-none d-block"><h3 class="h6">Multiple Usage Highlights</h3><p class="small text-muted mb-0">Products used more than once</p></a></div>
    <div class="col-md-6"><a href="<?php echo e(route('ho.reports.usage-by-category')); ?>" class="admin-card admin-card-body text-decoration-none d-block"><h3 class="h6">Usage by Category</h3><p class="small text-muted mb-0">Consumption grouped by category</p></a></div>
    <div class="col-md-6"><a href="<?php echo e(route('ho.reports.party-purchase')); ?>" class="admin-card admin-card-body text-decoration-none d-block"><h3 class="h6">Party-wise Purchase Summary</h3><p class="small text-muted mb-0">Purchase amount and order count by supplier</p></a></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views/ho/reports/index.blade.php ENDPATH**/ ?>