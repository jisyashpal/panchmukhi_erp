<script>
document.querySelectorAll('.auth-toggle-password').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var input = document.getElementById(btn.getAttribute('data-target'));
        if (!input) return;
        var isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';
        var icon = btn.querySelector('i');
        icon.classList.toggle('bi-eye', !isPassword);
        icon.classList.toggle('bi-eye-slash', isPassword);
        btn.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
    });
});
</script>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/partials/auth-scripts.blade.php ENDPATH**/ ?>