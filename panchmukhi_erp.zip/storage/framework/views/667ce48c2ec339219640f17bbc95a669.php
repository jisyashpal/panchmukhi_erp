<?php $__env->startSection('title', ($purchase->isQuotation() ? 'Quotation ' : 'Purchase ') . $purchase->reference_no); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => ($purchase->isQuotation() ? 'Quotation ' : 'Purchase ').$purchase->reference_no,'subtitle' => ''.e($purchase->plant->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($purchase->isQuotation() ? 'Quotation ' : 'Purchase ').$purchase->reference_no),'subtitle' => ''.e($purchase->plant->name).'']); ?>
    <div class="d-flex align-items-center gap-2 flex-wrap">
        <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchase->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchase->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
        <span class="badge bg-dark"><?php echo e($purchase->documentLabel()); ?></span>
        <?php if($purchase->is_interstate): ?>
            <span class="badge bg-info">Inter-state · IGST</span>
        <?php else: ?>
            <span class="badge bg-secondary">Intra-state · CGST+SGST</span>
        <?php endif; ?>
        <a href="<?php echo e(route('plant.purchases.index')); ?>" class="btn btn-admin-outline btn-sm">
            <i class="bi bi-arrow-left me-1"></i>All purchases
        </a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="admin-card mb-4">
            <div class="admin-card-header"><h2>Order details</h2></div>
            <div class="admin-card-body">
                <div class="row g-3 small">
                    <div class="col-sm-6">
                        <span class="text-muted d-block">Supplier</span>
                        <strong><?php echo e($purchase->supplier->name); ?></strong>
                        <?php if($purchase->supplier->gstin): ?>
                            <div class="text-muted">GSTIN: <?php echo e($purchase->supplier->gstin); ?></div>
                        <?php endif; ?>
                        <?php if($purchase->supplier->phone): ?>
                            <div class="text-muted"><?php echo e($purchase->supplier->phone); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6">
                        <span class="text-muted d-block">Plant</span>
                        <strong><?php echo e($purchase->plant->name); ?></strong>
                    </div>
                    <?php if($purchase->purchaseRequest?->product_request_id): ?>
                    <div class="col-sm-6">
                        <span class="text-muted d-block">Product request</span>
                        <strong>
                            <a href="<?php echo e(route('plant.product-requests.show', $purchase->purchaseRequest->product_request_id)); ?>">
                                #<?php echo e($purchase->purchaseRequest->product_request_id); ?>

                            </a>
                        </strong>
                    </div>
                    <?php endif; ?>
                    <div class="col-sm-6">
                        <span class="text-muted d-block">Ordered on</span>
                        <strong><?php echo e($purchase->ordered_at?->format('d M Y H:i') ?? '—'); ?></strong>
                    </div>
                    <?php if($purchase->supplier_invoice_no): ?>
                    <div class="col-sm-6">
                        <span class="text-muted d-block">Supplier invoice</span>
                        <strong><?php echo e($purchase->supplier_invoice_no); ?></strong>
                        <?php if($purchase->supplier_invoice_date): ?>
                            <span class="text-muted"> · <?php echo e($purchase->supplier_invoice_date->format('d M Y')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php if($purchase->notes): ?>
                    <div class="col-12">
                        <span class="text-muted d-block">Notes</span>
                        <?php echo e($purchase->notes); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="admin-card admin-table-card">
            <div class="admin-card-header"><h2>Line items (price &amp; GST)</h2></div>
            <div class="table-responsive">
                <table class="table mb-0 table-sm">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th class="text-end">Qty</th>
                            <th class="text-end">Rate</th>
                            <th class="text-end">Disc%</th>
                            <th class="text-end">GST%</th>
                            <th class="text-end">Taxable</th>
                            <th class="text-end">CGST</th>
                            <th class="text-end">SGST</th>
                            <th class="text-end">IGST</th>
                            <th class="text-end">Total</th>
                            <th class="text-end">Rcvd</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product?->name ?? '—'); ?></td>
                            <td class="text-end"><?php echo e(number_format($item->quantity, 2)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) ($item->discount_percent ?? 0), 2)); ?>%</td>
                            <td class="text-end"><?php echo e(number_format($item->gst_rate, 2)); ?>%</td>
                            <td class="text-end">₹<?php echo e(number_format($item->taxable_amount, 2)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($item->cgst_amount, 2)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($item->sgst_amount, 2)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($item->igst_amount, 2)); ?></td>
                            <td class="text-end fw-semibold">₹<?php echo e(number_format($item->line_total, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format($item->received_quantity, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <?php if(auth()->user()?->isPurchaser()): ?>
            <?php echo $__env->make('partials.purchase-pdf-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
        <div class="admin-card mb-4 border-primary">
            <div class="admin-card-header bg-primary-subtle"><h2 class="mb-0">Amount summary</h2></div>
            <div class="admin-card-body">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td>Taxable subtotal</td><td class="text-end">₹<?php echo e(number_format($purchase->subtotal, 2)); ?></td></tr>
                    <tr><td>CGST</td><td class="text-end">₹<?php echo e(number_format($purchase->total_cgst, 2)); ?></td></tr>
                    <tr><td>SGST</td><td class="text-end">₹<?php echo e(number_format($purchase->total_sgst, 2)); ?></td></tr>
                    <tr><td>IGST</td><td class="text-end">₹<?php echo e(number_format($purchase->total_igst, 2)); ?></td></tr>
                    <tr><td>Total GST</td><td class="text-end">₹<?php echo e(number_format($purchase->total_gst, 2)); ?></td></tr>
                    <tr class="fw-bold fs-5 border-top"><td>Grand total</td><td class="text-end text-primary">₹<?php echo e(number_format($purchase->grand_total, 2)); ?></td></tr>
                </table>
            </div>
        </div>
        <?php if($purchase->received_at): ?>
        <div class="admin-card">
            <div class="admin-card-header"><h2>Plant receipt</h2></div>
            <div class="admin-card-body small">
                <p class="mb-1"><strong>Received by:</strong> <?php echo e($purchase->receiver?->name ?? '—'); ?></p>
                <p class="mb-0"><strong>Received at:</strong> <?php echo e($purchase->received_at->format('d M Y H:i')); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/request-po/purchases/show.blade.php ENDPATH**/ ?>