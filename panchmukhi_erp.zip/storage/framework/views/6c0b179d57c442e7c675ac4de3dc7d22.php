<?php
    $isExisting = isset($item) && $item;
    $minQty = $isExisting ? max(0.01, (float) $item->received_quantity) : 0.01;
    $canRemove = $isExisting ? (float) $item->received_quantity <= 0 : true;
?>
<tr class="dynamic-row stock-in-po-line" data-received="<?php echo e($isExisting ? (float) $item->received_quantity : 0); ?>">
    <td class="purchase-col-product">
        <?php if($isExisting): ?>
            <span class="fw-semibold d-block text-truncate" title="<?php echo e($item->product->name); ?>"><?php echo e($item->product->name); ?></span>
            <?php if($item->product->sku): ?>
                <code class="small text-muted"><?php echo e($item->product->sku); ?></code>
            <?php endif; ?>
            <input type="hidden" name="items[<?php echo e($i); ?>][id]" value="<?php echo e($item->id); ?>">
        <?php else: ?>
            <select name="items[<?php echo e($i); ?>][product_id]" required class="form-select form-select-sm stock-in-po-input">
                <option value="">— Select product —</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(old("items.$i.product_id") == $p->id): echo 'selected'; endif; ?>>
                        <?php echo e($p->name); ?><?php if($p->sku): ?> (<?php echo e($p->sku); ?>)<?php endif; ?>
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php endif; ?>
    </td>
    <td class="purchase-col-num purchase-col-qty">
        <input type="number" step="0.01" min="<?php echo e($minQty); ?>" name="items[<?php echo e($i); ?>][quantity]"
            value="<?php echo e(old("items.$i.quantity", $isExisting ? $item->quantity : 1)); ?>"
            class="form-control form-control-sm stock-in-po-input purchase-num-input" required>
    </td>
    <td class="purchase-col-num purchase-col-rate">
        <input type="number" step="0.01" min="0" name="items[<?php echo e($i); ?>][unit_price]"
            value="<?php echo e(old("items.$i.unit_price", $isExisting ? $item->unit_price : 0)); ?>"
            class="form-control form-control-sm stock-in-po-input purchase-num-input" required>
    </td>
    <td class="purchase-col-num purchase-col-gst">
        <select name="items[<?php echo e($i); ?>][gst_rate]" class="form-select form-select-sm stock-in-po-input purchase-num-input">
            <?php $__currentLoopData = [0, 5, 12, 18, 28]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rate); ?>" <?php if(old("items.$i.gst_rate", $isExisting ? $item->gst_rate : 18) == $rate): echo 'selected'; endif; ?>><?php echo e($rate); ?> %</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td class="purchase-col-num purchase-col-qty text-muted">
        <?php if($isExisting): ?>
            <?php echo e(number_format($item->received_quantity, 2)); ?>

        <?php else: ?>
            —
        <?php endif; ?>
    </td>
    <td class="purchase-col-num purchase-col-total">
        <span class="stock-in-line-total small fw-semibold">₹0.00</span>
    </td>
    <td class="purchase-col-action">
        <?php if($canRemove): ?>
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeStockInPoLine(this)" title="Remove line" aria-label="Remove line">
                <i class="bi bi-trash" aria-hidden="true"></i>
            </button>
        <?php endif; ?>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\partials\stock-in-po-line-fields.blade.php ENDPATH**/ ?>