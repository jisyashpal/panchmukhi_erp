<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'plants',
    'categories' => null,
    'products' => null,
    'vehicles' => null,
    'showDates' => false,
    'searchPlaceholder' => 'Search...',
    'clearRoute',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'plants',
    'categories' => null,
    'products' => null,
    'vehicles' => null,
    'showDates' => false,
    'searchPlaceholder' => 'Search...',
    'clearRoute',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $dateFrom = request('date_from', $financialYear->dateFrom ?? null);
    $dateTo = request('date_to', $financialYear->dateTo ?? null);
    $filterKeys = array_filter([
        'search',
        'fy',
        $plants ? 'plant_id' : null,
        $categories ? 'category_id' : null,
        $products ? 'product_id' : null,
        $vehicles ? 'vehicle_id' : null,
        $showDates ? 'date_from' : null,
        $showDates ? 'date_to' : null,
    ]);
?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <?php if(isset($financialYear)): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Financial Year</label>
                <?php if (isset($component)) { $__componentOriginal4be369a9030485a61f998f024d2f0b89 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4be369a9030485a61f998f024d2f0b89 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.financial-year-select','data' => ['compact' => true,'selected' => request('fy', $financialYear->label)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('financial-year-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['compact' => true,'selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('fy', $financialYear->label))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $attributes = $__attributesOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__attributesOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $component = $__componentOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__componentOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="col-12 col-md-3">
            <label class="form-label small">Search</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm"
                placeholder="<?php echo e($searchPlaceholder); ?>">
        </div>
        <?php if($plants): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Plant</label>
                <select name="plant_id" class="form-select form-select-sm searchable-select" data-placeholder="All plants">
                    <option value="">All plants</option>
                    <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($plant->id); ?>" <?php if(request('plant_id') == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($vehicles): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Vehicle</label>
                <select name="vehicle_id" class="form-select form-select-sm searchable-select" data-placeholder="All vehicles">
                    <option value="">All vehicles</option>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicle->id); ?>" <?php if(request('vehicle_id') == $vehicle->id): echo 'selected'; endif; ?>>
                            <?php echo e(method_exists($vehicle, 'displayLabel') ? $vehicle->displayLabel() : $vehicle->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($categories): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Category</label>
                <select name="category_id" class="form-select form-select-sm searchable-select" data-placeholder="All categories">
                    <option value="">All categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if(request('category_id') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($products): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">Product</label>
                <select name="product_id" class="form-select form-select-sm searchable-select" data-placeholder="All products">
                    <option value="">All products</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" <?php if(request('product_id') == $product->id): echo 'selected'; endif; ?>><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($showDates): ?>
            <div class="col-6 col-md-2">
                <label class="form-label small">From date</label>
                <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small">To date</label>
                <input type="date" name="date_to" value="<?php echo e($dateTo); ?>" class="form-control form-control-sm">
            </div>
        <?php endif; ?>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm">
                <i class="bi bi-search me-1"></i>Search
            </button>
            <?php if(request()->anyFilled($filterKeys)): ?>
                <a href="<?php echo e($clearRoute); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/components/report-filters.blade.php ENDPATH**/ ?>