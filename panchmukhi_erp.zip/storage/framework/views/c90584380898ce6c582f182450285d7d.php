<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'name',
    'type' => 'text',
    'icon' => 'bi-envelope',
    'placeholder' => '',
    'required' => false,
    'autofocus' => false,
    'autocomplete' => null,
    'value' => null,
    'toggle' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'name',
    'type' => 'text',
    'icon' => 'bi-envelope',
    'placeholder' => '',
    'required' => false,
    'autofocus' => false,
    'autocomplete' => null,
    'value' => null,
    'toggle' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $hasError = $errors->has($name);
?>

<div class="auth-field mb-3 <?php echo e($hasError ? 'auth-field--invalid' : ''); ?>">
    <label for="<?php echo e($name); ?>" class="form-label fw-semibold"><?php echo e($label); ?></label>
    <div class="input-group auth-input-group">
        <span class="input-group-text"><i class="bi <?php echo e($icon); ?>" aria-hidden="true"></i></span>
        <input
            id="<?php echo e($name); ?>"
            type="<?php echo e($type); ?>"
            name="<?php echo e($name); ?>"
            value="<?php echo e(old($name, $value)); ?>"
            <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
            <?php if($required): ?> required <?php endif; ?>
            <?php if($autofocus): ?> autofocus <?php endif; ?>
            <?php if($autocomplete): ?> autocomplete="<?php echo e($autocomplete); ?>" <?php endif; ?>
            <?php if($hasError): ?> aria-invalid="true" aria-describedby="<?php echo e($name); ?>-error" <?php endif; ?>
            <?php echo e($attributes->class(['form-control', 'is-invalid' => $hasError])); ?>

        >
        <?php if($toggle): ?>
        <button type="button" class="btn btn-outline-secondary auth-toggle-password" data-target="<?php echo e($name); ?>" aria-label="Show password">
            <i class="bi bi-eye" aria-hidden="true"></i>
        </button>
        <?php endif; ?>
    </div>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div id="<?php echo e($name); ?>-error" class="auth-field-error" role="alert">
        <i class="bi bi-exclamation-circle-fill" aria-hidden="true"></i>
        <span><?php echo e($message); ?></span>
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/components/auth/field.blade.php ENDPATH**/ ?>