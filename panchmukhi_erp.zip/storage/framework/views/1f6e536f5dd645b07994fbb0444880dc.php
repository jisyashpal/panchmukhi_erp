<?php $__env->startSection('title', 'Permissions'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Permissions','subtitle' => 'Define capabilities that can be assigned to roles']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Permissions','subtitle' => 'Define capabilities that can be assigned to roles']); ?>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-admin-outline btn-sm">
            <i class="bi bi-shield-lock me-1"></i>Roles
        </a>
        <a href="<?php echo e(route('admin.permissions.create')); ?>" class="btn btn-admin-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Add Permission
        </a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-card mb-3">
    <div class="admin-card-body py-3">
        <form method="GET" action="<?php echo e(route('admin.permissions.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label" for="filter_module">Module</label>
                <select name="module" id="filter_module" class="form-select form-select-sm">
                    <option value="">All modules</option>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if(request('module') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="filter_search">Search</label>
                <input type="text" name="search" id="filter_search" class="form-control form-control-sm" value="<?php echo e(request('search')); ?>" placeholder="Name or slug">
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-admin-primary btn-sm">Filter</button>
                <?php if(request()->hasAny(['module', 'search'])): ?>
                    <a href="<?php echo e(route('admin.permissions.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Module</th>
                    <th>Roles</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold">
                        <?php echo e($permission->name); ?>

                        <?php if($permission->is_system): ?>
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle ms-1">System</span>
                        <?php endif; ?>
                    </td>
                    <td><code class="small"><?php echo e($permission->slug); ?></code></td>
                    <td><?php echo e($permission->moduleLabel()); ?></td>
                    <td><?php echo e($permission->roles_count); ?></td>
                    <td class="text-end">
                        <?php if (isset($component)) { $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-edit','data' => ['href' => route('admin.permissions.edit', $permission)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.permissions.edit', $permission))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $attributes = $__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__attributesOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b)): ?>
<?php $component = $__componentOriginalf736cd8cb69ce8f1eca537adee13e83b; ?>
<?php unset($__componentOriginalf736cd8cb69ce8f1eca537adee13e83b); ?>
<?php endif; ?>
                        <?php if(!$permission->is_system && $permission->roles_count === 0): ?>
                            <?php if (isset($component)) { $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-action-delete','data' => ['action' => route('admin.permissions.destroy', $permission),'confirm' => 'Delete this permission?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-action-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.permissions.destroy', $permission)),'confirm' => 'Delete this permission?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $attributes = $__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__attributesOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f)): ?>
<?php $component = $__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f; ?>
<?php unset($__componentOriginal98e4fbc07d12726c7ef61dfbde74a65f); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">
                        <div class="admin-empty"><i class="bi bi-key d-block"></i>No permissions found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($permissions->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jissoftware/public_html/panchmukhi.jissoftware.in/resources/views/admin/master/permissions/index.blade.php ENDPATH**/ ?>