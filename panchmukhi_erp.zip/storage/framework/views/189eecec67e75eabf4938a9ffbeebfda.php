<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> — <?php echo e(config('app.name', 'Panchmukhi ERP')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/p.png')); ?>" type="image/x-icon">
    <?php echo $__env->make('partials.bootstrap-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(filemtime(public_path('css/admin.css'))); ?>">
</head>

<body class="admin-body bg-light">
    <div class="admin-wrapper d-flex min-vh-100">
        <?php echo $__env->make('partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="admin-content flex-grow-1 d-flex flex-column min-vh-100">
            <?php echo $__env->make('partials.admin-topbar', [
                'pageTitle' => trim($__env->yieldContent('title')) ?: 'Admin',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="admin-main flex-grow-1">
                <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <div class="offcanvas offcanvas-start sidebar-admin text-white" tabindex="-1" id="adminSidebarOffcanvas"
        aria-labelledby="adminSidebarOffcanvasLabel">
        <div class="offcanvas-header border-bottom border-secondary border-opacity-25">
            <div class="d-flex align-items-center gap-2" id="adminSidebarOffcanvasLabel">
                <span class="sidebar-brand-icon rounded d-flex align-items-center justify-content-center">
                    <img src="<?php echo e(asset('img/PMCMPL.png')); ?>" alt="Panchmukhi" class="img-fluid rounded flex-shrink-0">
                </span>
                <!-- <div>
                    <strong class="d-block">Panchmukhi</strong>
                    <small class="text-white-50">Head Office</small>
                </div> -->
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"
                aria-label="Close"></button>
        </div>
        <div class="offcanvas-body p-0 d-flex flex-column">
            <nav class="sidebar-nav flex-grow-1 overflow-auto p-2">
                <?php if (isset($component)) { $__componentOriginal4cb4f2672758c9af85d391d44bae6987 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cb4f2672758c9af85d391d44bae6987 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal-sidebar-menu','data' => ['portal' => 'admin','menuIdSuffix' => 'Mobile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal-sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['portal' => 'admin','menuIdSuffix' => 'Mobile']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cb4f2672758c9af85d391d44bae6987)): ?>
<?php $attributes = $__attributesOriginal4cb4f2672758c9af85d391d44bae6987; ?>
<?php unset($__attributesOriginal4cb4f2672758c9af85d391d44bae6987); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cb4f2672758c9af85d391d44bae6987)): ?>
<?php $component = $__componentOriginal4cb4f2672758c9af85d391d44bae6987; ?>
<?php unset($__componentOriginal4cb4f2672758c9af85d391d44bae6987); ?>
<?php endif; ?>
            </nav>
            <div class="sidebar-footer p-3 border-top border-secondary border-opacity-25">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="sidebar-user-avatar rounded-circle d-flex align-items-center justify-content-center">
                        <i class="bi bi-person-fill"></i>
                    </span>
                    <div class="small fw-semibold text-truncate"><?php echo e(auth()->user()->name); ?></div>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm w-100">
                        <i class="bi bi-box-arrow-right me-1"></i> Logout
                    </button>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.bootstrap-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script>
        document.querySelectorAll('#adminSidebarOffcanvas .sidebar-link, #adminSidebarOffcanvas .sidebar-sublink').forEach(function (el) {
            el.addEventListener('click', function () {
                var canvas = bootstrap.Offcanvas.getInstance(document.getElementById('adminSidebarOffcanvas'));
                if (canvas) canvas.hide();
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\layouts\admin.blade.php ENDPATH**/ ?>