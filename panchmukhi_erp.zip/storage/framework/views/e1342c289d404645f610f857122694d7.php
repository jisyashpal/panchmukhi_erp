<?php $__env->startSection('title', 'Product Requests'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $activeStatus = $activeStatus ?? request('status');
    ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Requests','subtitle' => $isPurchaser ? 'Product-wise list — select same plant to export or add quotation' : 'Request products for your plant']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Requests','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isPurchaser ? 'Product-wise list — select same plant to export or add quotation' : 'Request products for your plant')]); ?>
        <?php if(auth()->user()->canCreateProductRequests()): ?>
            <a href="<?php echo e(route('plant.product-requests.create')); ?>" class="btn btn-admin-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i>New Request
            </a>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <div class="admin-filters mb-3">
        <?php echo $__env->make('partials.status-tabs', [
            'route' => 'plant.product-requests.index',
            'param' => 'status',
            'tabs' => [
                ['label' => 'PENDING', 'key' => 'pending'],
                ['label' => 'Add Quotation', 'key' => 'add_quotation'],
                ['label' => 'Create PO', 'key' => 'create_po'],
                ['label' => 'Dispatch', 'key' => 'dispatch'],
                ['label' => 'All', 'key' => 'all'],
            ],
            'active' => $activeStatus === '' ? 'all' : $activeStatus,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form method="GET" class="row g-3 mb-3 align-items-end">
            <?php if($activeStatus !== null && $activeStatus !== ''): ?>
                <input type="hidden" name="status" value="<?php echo e($activeStatus); ?>">
            <?php elseif(request('status') === 'all'): ?>
                <input type="hidden" name="status" value="all">
            <?php endif; ?>
            <?php if($isPurchaser): ?>
                <div class="col-12 col-md-2">
                    <label class="form-label small">Plant / Site</label>
                    <select name="plant_id" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">All plants</option>
                        <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($plant->id); ?>" <?php if(request('plant_id') == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
            <div class="col-12 col-md-3 position-relative">
                <label class="form-label small" for="product-search">Search Item Name / SKU</label>
                <input type="text" name="search" id="product-search" value="<?php echo e(request('search')); ?>"
                    class="form-control form-control-sm" placeholder="Enter item name or SKU..." autocomplete="off">
                <div id="autocomplete-suggestions"
                    class="autocomplete-suggestions d-none shadow border rounded-bottom bg-white"></div>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label small">Filter by Product</label>
                <select name="product_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All products</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" <?php if(request('product_id') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small">Priority</label>
                <select name="priority" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All priorities</option>
                    <?php $__currentLoopData = \App\Enums\PriorityLevel::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pLevel->value); ?>" <?php if(request('priority') === $pLevel->value): echo 'selected'; endif; ?>>
                            <?php echo e($pLevel->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-1">
                <label class="form-label small">From Date</label>
                <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control form-control-sm"
                    onchange="this.form.submit()">
            </div>
            <div class="col-6 col-md-1">
                <label class="form-label small">To Date</label>
                <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control form-control-sm"
                    onchange="this.form.submit()">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
                <?php if(request()->anyFilled(['plant_id', 'product_id', 'search', 'priority', 'status', 'from_date', 'to_date'])): ?>
                    <a href="<?php echo e(route('plant.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if($isPurchaser): ?>
        <form method="POST" action="<?php echo e(route('plant.product-requests.bulk-convert')); ?>" id="bulk-quotation-form">
            <?php echo csrf_field(); ?>
            <div class="d-flex flex-wrap align-items-center gap-2 mb-3 sticky-selection-bar">
                <div class="d-inline-flex align-items-center gap-1">
                    <select name="supplier_id" class="form-select form-select-sm" id="export-supplier-select" style="min-width: 210px;" title="Select Supplier for Inquiry Export">
                        <option value="">-- Select Supplier * --</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?> <?php echo e($supplier->city ? '('.$supplier->city.')' : ''); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger btn-sm" id="bulk-export-btn"
                    formaction="<?php echo e(route('plant.product-requests.bulk-export-supplier')); ?>" disabled>
                    <i class="bi bi-file-earmark-excel me-1"></i>Export for Supplier
                </button>
                <?php if($activeStatus !== 'pending'): ?>
                    <button type="submit" class="btn btn-warning btn-sm" id="bulk-generate-btn" disabled>
                        <i class="bi bi-file-earmark-text me-1"></i>Add Quotation (selected)
                    </button>
                <?php endif; ?>
                <span class="small text-muted" id="bulk-selection-hint">
                    <?php if($activeStatus === 'pending'): ?>
                        Select products to export for supplier. Exporting moves items to Add Quotation tab.
                    <?php else: ?>
                        Select products. Export for supplier first, then add quotation. Same plant only.
                    <?php endif; ?>
                </span>
            </div>
    <?php endif; ?>

        <?php
            $isQuotationPoView = in_array($activeStatus, ['add_quotation', 'create_po', 'dispatch']);
        ?>

        <div class="admin-card admin-table-card">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <?php if($isQuotationPoView): ?>
                            <tr>
                                <th><?php echo e($activeStatus === 'dispatch' ? 'PO No.' : ($activeStatus === 'create_po' ? 'Quotation No.' : 'Inquiry / Ref No.')); ?></th>
                                <th>Products</th>
                                <th>Supplier Name</th>
                                <th>Date of Request</th>
                                <th>Site (Plant)</th>
                                <th><?php echo e($activeStatus === 'add_quotation' ? 'Export Date' : 'Create Date'); ?></th>
                                <th class="text-end">Actions</th>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <?php if($isPurchaser): ?>
                                    <th style="width: 2.5rem">
                                        <input type="checkbox" class="form-check-input" id="select-all-requests"
                                            title="Select all eligible products">
                                    </th>
                                <?php endif; ?>
                                <th>#</th>
                                <?php if($isPurchaser): ?>
                                    <th>Plant</th>
                                <?php endif; ?>
                                <th>Product</th>
                                <th>Size</th>
                                <th class="text-end">Qty</th>
                                <th>Unit</th>
                                <th>Requested By</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        <?php endif; ?>
                    </thead>
                    <tbody>
                        <?php if(in_array($activeStatus, ['add_quotation', 'create_po', 'dispatch'])): ?>
                            <?php
                                $groupedItems = $items->getCollection()->groupBy(function($item) use ($activeStatus) {
                                    $quotations = $item->relatedQuotations();
                                    $purchaseOrders = $item->relatedPurchaseOrders();
                                    $primaryQuotation = $quotations->first();
                                    $primaryPurchase = $purchaseOrders->first();

                                    if ($activeStatus === 'dispatch' && $primaryPurchase) {
                                        return 'po_' . $primaryPurchase->id;
                                    }
                                    if ($primaryQuotation) {
                                        return 'quote_' . $primaryQuotation->id;
                                    }
                                    if ($item->supplier_id) {
                                        return 'supplier_' . $item->supplier_id . '_plant_' . ($item->productRequest?->plant_id ?? 0);
                                    }
                                    return 'supplier_0_pr_' . $item->product_request_id;
                                });
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $groupItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    if ($activeStatus === 'add_quotation') {
                                        $groupItems = $groupItems->filter(fn($g) => $g->workflowStatus() === \App\Enums\ProductRequestItemWorkflowStatus::AddQuotation);
                                    } elseif ($activeStatus === 'create_po') {
                                        $groupItems = $groupItems->filter(fn($g) => $g->workflowStatus() === \App\Enums\ProductRequestItemWorkflowStatus::CreatePo);
                                    } elseif ($activeStatus === 'dispatch') {
                                        $groupItems = $groupItems->filter(fn($g) => in_array($g->workflowStatus(), [
                                            \App\Enums\ProductRequestItemWorkflowStatus::PoCreated,
                                            \App\Enums\ProductRequestItemWorkflowStatus::Dispatch,
                                        ], true));
                                    }
                                ?>
                                <?php if($groupItems->isEmpty()): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <?php
                                    $firstItem = $groupItems->first();
                                    $pr = $firstItem->productRequest;
                                    $quotations = $firstItem->relatedQuotations();
                                    $purchaseOrders = $firstItem->relatedPurchaseOrders();
                                    $primaryQuotation = $quotations->first();
                                    $primaryPurchase = $purchaseOrders->first();
                                    $pendingDispatch = $purchaseOrders->first(fn($purchase) => $purchase->dispatched_at === null) ?? $primaryPurchase;
                                    $doc = $activeStatus === 'dispatch' ? ($primaryPurchase ?? $primaryQuotation) : ($primaryQuotation ?? $primaryPurchase);
                                    $refNo = $doc?->reference_no ?? ('Inquiry (#' . $pr->id . ')');
                                    $supplierName = $doc?->supplier?->name ?? $firstItem->supplier?->name ?? '—';
                                    $createDate = $firstItem->exported_at ?? $doc?->ordered_at ?? $doc?->created_at ?? $pr->created_at;
                                ?>
                                <tr>
                                    <td>
                                        <span class="fw-semibold text-primary"><?php echo e($refNo); ?></span>
                                        <?php if($activeStatus === 'dispatch' && $primaryQuotation && $primaryQuotation->reference_no !== $refNo): ?>
                                            <span class="d-block small text-muted">Quote: <?php echo e($primaryQuotation->reference_no); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="product-group-list">
                                            <?php $__currentLoopData = $groupItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="py-1 d-flex align-items-center gap-2 <?php echo e(!$loop->last ? 'border-bottom border-light-subtle' : ''); ?>">
                                                    <?php if($isPurchaser && $activeStatus === 'add_quotation' && $gItem->canSelectForPo()): ?>
                                                        <input type="checkbox" class="form-check-input request-select"
                                                            name="product_request_item_ids[]" value="<?php echo e($gItem->id); ?>"
                                                            data-plant-id="<?php echo e($pr->plant_id); ?>" data-plant-name="<?php echo e($pr->plant->name); ?>"
                                                            data-has-product="<?php echo e($gItem->product_id ? 1 : 0); ?>">
                                                    <?php endif; ?>
                                                    <div>
                                                        <span class="fw-medium text-dark"><?php echo e($gItem->displayName()); ?></span>
                                                        <span class="d-inline-block small text-muted ms-1">
                                                            (Qty: <?php echo e(number_format((float)$gItem->quantity, 2)); ?> <?php echo e($gItem->displayUnit()); ?><?php echo e($gItem->size ? ' | Size: '.$gItem->size : ''); ?>)
                                                        </span>
                                                        <?php if(!$gItem->product_id && auth()->user()->canManagePlantProducts()): ?>
                                                            <a href="<?php echo e(route('plant.products.create', [
                                                                'name' => $gItem->displayName(),
                                                                'size' => $gItem->size,
                                                                'category_id' => $gItem->subCategory?->category_id ?? $gItem->product?->category_id,
                                                                'sub_category_id' => $gItem->sub_category_id,
                                                                'product_request_id' => $pr->id,
                                                                'product_request_item_id' => $gItem->id,
                                                            ])); ?>" class="btn btn-xs btn-outline-primary ms-1 py-0 px-2 d-inline-flex align-items-center gap-1" style="font-size: 0.725rem;" title="Create product in catalog">
                                                                <i class="bi bi-plus-circle"></i>Create Product
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fw-medium text-dark"><?php echo e($supplierName); ?></span>
                                    </td>
                                    <td class="small text-muted"><?php echo e($pr->created_at->format('d M Y')); ?></td>
                                    <td><?php echo e($pr->plant->name); ?></td>
                                    <td class="small text-muted"><?php echo e($createDate?->format('d M Y') ?? '—'); ?></td>
                                    <td class="text-end">
                                        <div class="d-inline-flex gap-2 align-items-center justify-content-end flex-wrap">
                                            <?php if(!in_array($activeStatus, ['add_quotation', 'create_po'])): ?>
                                                <a href="<?php echo e(route('plant.product-requests.show', [$pr, 'item_ids' => $groupItems->pluck('id')->toArray()])); ?>"
                                                    class="btn btn-sm btn-admin-outline" title="View Request">
                                                    <i class="bi bi-eye me-1"></i>View
                                                </a>
                                            <?php endif; ?>
                                            <?php if($doc): ?>
                                                <button type="button" class="btn btn-sm btn-outline-secondary btn-print-purchase"
                                                    data-pdf-url="<?php echo e(route('plant.purchases.pdf', $doc)); ?>"
                                                    data-reference="<?php echo e($doc->reference_no); ?>"
                                                    data-default-name="<?php echo e(($pdfDefaults['company_name'] ?? '') ?: $pr->plant->name); ?>"
                                                    data-default-address="<?php echo e(($pdfDefaults['company_address'] ?? '') ?: ($pr->plant->address ?? '')); ?>"
                                                    data-default-gstin="<?php echo e($pdfDefaults['company_gstin'] ?? ''); ?>">
                                                    <i class="bi bi-printer me-1"></i>Print
                                                </button>
                                            <?php endif; ?>
                                            <?php if($activeStatus === 'add_quotation' && $isPurchaser): ?>
                                                <?php if($primaryQuotation): ?>
                                                    <?php if($primaryQuotation->canBeEdited()): ?>
                                                        <a href="<?php echo e(route('plant.purchases.edit', $primaryQuotation)); ?>"
                                                            class="btn btn-sm btn-outline-primary">
                                                            <i class="bi bi-pencil me-1"></i>Edit Quote
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button type="submit" form="quote-form-<?php echo e($groupKey); ?>" class="btn btn-sm btn-warning">
                                                        <i class="bi bi-file-earmark-text me-1"></i>Add Quotation
                                                    </button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($activeStatus === 'create_po' && $isPurchaser && $primaryQuotation): ?>
                                                <a href="<?php echo e(route('plant.purchases.create', ['quotation_id' => $primaryQuotation->id])); ?>"
                                                    class="btn btn-sm btn-warning">
                                                    <i class="bi bi-cart-plus me-1"></i>Create PO
                                                </a>
                                                <?php if($primaryQuotation->canBeEdited()): ?>
                                                    <a href="<?php echo e(route('plant.purchases.edit', $primaryQuotation)); ?>"
                                                        class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-pencil me-1"></i>Edit
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(($activeStatus === 'dispatch' || $primaryPurchase) && $pendingDispatch): ?>
                                                <?php if($isPurchaser && $pendingDispatch->canBeEdited()): ?>
                                                    <a href="<?php echo e(route('plant.purchases.edit', $pendingDispatch)); ?>"
                                                        class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-pencil me-1"></i>Edit PO
                                                    </a>
                                                <?php endif; ?>
                                                <?php if(auth()->user()->canDispatchOrders()): ?>
                                                    <a href="<?php echo e(route('plant.dispatch.show', $pendingDispatch)); ?>"
                                                        class="btn btn-sm <?php echo e($pendingDispatch->isDispatched() ? 'btn-admin-outline' : 'btn-success'); ?>">
                                                        <i class="bi bi-truck me-1"></i><?php echo e($pendingDispatch->isDispatched() ? 'View Dispatch' : 'Dispatch'); ?>

                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(($isPurchaser || auth()->user()->canManagePurchaseRequests() || auth()->user()->canManagePlantPurchases()) && in_array($pr->status->value, ['submitted', 'in_progress']) && $groupItems->contains(fn($gItem) => $gItem->canSelectForPo())): ?>
                                                <a href="<?php echo e(route('plant.product-requests.edit', [$pr, 'item_ids' => $groupItems->pluck('id')->toArray()])); ?>"
                                                    class="btn btn-sm btn-outline-primary" title="Edit Inquiry Items">
                                                    <i class="bi bi-pencil me-1"></i>Edit PR
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo $__env->make('partials.table-empty', ['colspan' => 7, 'icon' => 'bi-clipboard-check', 'message' => 'No product requests'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $pr = $item->productRequest;
                                    $workflow = $item->workflowStatus();
                                    $canSelect = $isPurchaser && $item->canSelectForPo();
                                    $quotations = $item->relatedQuotations();
                                    $purchaseOrders = $item->relatedPurchaseOrders();
                                    $primaryQuotation = $quotations->first();
                                    $primaryPurchase = $purchaseOrders->first();
                                    $pendingDispatch = $purchaseOrders->first(fn($purchase) => $purchase->dispatched_at === null) ?? $primaryPurchase;
                                    $doc = $primaryPurchase ?? $primaryQuotation;
                                    $refNo = $doc?->reference_no ?? ('#' . $pr->id);
                                    $supplierName = $primaryPurchase?->supplier?->name ?? $primaryQuotation?->supplier?->name ?? $item->supplier?->name ?? '—';
                                    $createDate = $primaryPurchase?->ordered_at ?? $primaryPurchase?->created_at ?? $primaryQuotation?->created_at ?? $pr->created_at;
                                ?>
                                <tr>
                                    <?php if($isPurchaser && ($activeStatus === 'add_quotation' || !$isQuotationPoView)): ?>
                                        <td>
                                            <?php if($canSelect): ?>
                                                <input type="checkbox" class="form-check-input request-select"
                                                    name="product_request_item_ids[]" value="<?php echo e($item->id); ?>"
                                                    data-plant-id="<?php echo e($pr->plant_id); ?>" data-plant-name="<?php echo e($pr->plant->name); ?>"
                                                    data-has-product="<?php echo e($item->product_id ? 1 : 0); ?>">
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                    <td><?php echo e($isQuotationPoView ? $refNo : '#' . $pr->id); ?></td>
                                    <?php if($isPurchaser && !$isQuotationPoView): ?>
                                        <td class="fw-semibold"><?php echo e($pr->plant->name); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <span class="fw-semibold"><?php echo e($item->displayName()); ?></span>
                                        <?php if($isQuotationPoView): ?>
                                            <span class="d-block small text-muted">Qty: <?php echo e($item->quantity); ?> <?php echo e($item->displayUnit()); ?></span>
                                        <?php endif; ?>
                                        <?php if(!$item->product_id): ?>
                                            <div class="mt-1 d-flex align-items-center gap-1 flex-wrap">
                                                <span class="badge bg-warning-subtle text-warning border border-warning-subtle py-1 px-2" style="font-size: 0.725rem;">Product Required</span>
                                                <?php if(auth()->user()->canManagePlantProducts()): ?>
                                                    <a href="<?php echo e(route('plant.products.create', [
                                                        'name' => $item->displayName(),
                                                        'size' => $item->size,
                                                        'category_id' => $item->subCategory?->category_id ?? $item->product?->category_id,
                                                        'sub_category_id' => $item->sub_category_id,
                                                        'product_request_id' => $pr->id,
                                                        'product_request_item_id' => $item->id,
                                                    ])); ?>" class="btn btn-xs btn-outline-primary py-0 px-2 d-inline-flex align-items-center gap-1" style="font-size: 0.725rem;" title="Create product in catalog">
                                                        <i class="bi bi-plus-circle"></i>Create Product
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <?php if($isQuotationPoView): ?>
                                        <td><?php echo e($supplierName); ?></td>
                                        <td class="small text-muted"><?php echo e($pr->created_at->format('d M Y')); ?></td>
                                        <td><?php echo e($pr->plant->name); ?></td>
                                        <td class="small text-muted"><?php echo e($createDate?->format('d M Y') ?? '—'); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($item->size ?? '—'); ?></td>
                                        <td class="text-end"><?php echo e(number_format((float) $item->quantity, 2)); ?></td>
                                        <td><?php echo e($item->displayUnit()); ?></td>
                                        <td><?php echo e($pr->displayRequesterName()); ?></td>
                                        <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $item->priority]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->priority)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                                        <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $workflow]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($workflow)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                                        <td><?php echo e($pr->created_at->format('d M Y')); ?></td>
                                    <?php endif; ?>
                                    <td class="text-end">
                                        <div class="d-inline-flex gap-2 align-items-center justify-content-end flex-wrap">
                                            <a href="<?php echo e(route('plant.product-requests.show', $pr)); ?>"
                                                class="btn btn-sm btn-admin-outline" title="View Request">
                                                <i class="bi bi-eye me-1"></i>View
                                            </a>
                                            <?php if($doc): ?>
                                                <button type="button" class="btn btn-sm btn-outline-secondary btn-print-purchase"
                                                    data-pdf-url="<?php echo e(route('plant.purchases.pdf', $doc)); ?>"
                                                    data-reference="<?php echo e($doc->reference_no); ?>"
                                                    data-default-name="<?php echo e(($pdfDefaults['company_name'] ?? '') ?: $pr->plant->name); ?>"
                                                    data-default-address="<?php echo e(($pdfDefaults['company_address'] ?? '') ?: ($pr->plant->address ?? '')); ?>"
                                                    data-default-gstin="<?php echo e($pdfDefaults['company_gstin'] ?? ''); ?>">
                                                    <i class="bi bi-printer me-1"></i>Print
                                                </button>
                                            <?php endif; ?>
                                            <?php if($isPurchaser): ?>
                                                <?php if($workflow === \App\Enums\ProductRequestItemWorkflowStatus::Pending): ?>
                                                    <button type="submit" class="btn btn-sm btn-admin-outline js-single-product"
                                                        formaction="<?php echo e(route('plant.product-requests.bulk-export-supplier')); ?>"
                                                        data-item-id="<?php echo e($item->id); ?>" title="Export this product for supplier">
                                                        <i class="bi bi-file-earmark-excel me-1"></i>Export
                                                    </button>
                                                <?php elseif($workflow === \App\Enums\ProductRequestItemWorkflowStatus::AddQuotation): ?>
                                                    <button type="submit" class="btn btn-sm btn-admin-outline js-single-product"
                                                        formaction="<?php echo e(route('plant.product-requests.bulk-export-supplier')); ?>"
                                                        data-item-id="<?php echo e($item->id); ?>" title="Export this product for supplier">
                                                        <i class="bi bi-file-earmark-excel me-1"></i>Export
                                                    </button>
                                                    <button type="submit" class="btn btn-sm btn-warning js-single-product"
                                                        data-item-id="<?php echo e($item->id); ?>">
                                                        <i class="bi bi-file-earmark-text me-1"></i>Add Quotation
                                                    </button>
                                                <?php elseif($workflow === \App\Enums\ProductRequestItemWorkflowStatus::CreatePo && $primaryQuotation): ?>
                                                    <a href="<?php echo e(route('plant.purchases.create', ['quotation_id' => $primaryQuotation->id])); ?>"
                                                        class="btn btn-sm btn-warning">
                                                        <i class="bi bi-cart-plus me-1"></i>Create PO
                                                    </a>
                                                    <?php if($primaryQuotation->canBeEdited()): ?>
                                                        <a href="<?php echo e(route('plant.purchases.edit', $primaryQuotation)); ?>"
                                                            class="btn btn-sm btn-outline-primary">
                                                            <i class="bi bi-pencil me-1"></i>Edit
                                                        </a>
                                                    <?php endif; ?>
                                                <?php elseif($primaryPurchase): ?>
                                                    <?php if($primaryPurchase->canBeEdited()): ?>
                                                        <a href="<?php echo e(route('plant.purchases.edit', $primaryPurchase)); ?>"
                                                            class="btn btn-sm btn-outline-primary">
                                                            <i class="bi bi-pencil me-1"></i>Edit
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->canDispatchOrders() && $pendingDispatch): ?>
                                                <a href="<?php echo e(route('plant.dispatch.show', $pendingDispatch)); ?>"
                                                    class="btn btn-sm <?php echo e($workflow === \App\Enums\ProductRequestItemWorkflowStatus::Dispatch ? 'btn-admin-outline' : 'btn-success'); ?>">
                                                    <i class="bi bi-truck me-1"></i><?php echo e($workflow === \App\Enums\ProductRequestItemWorkflowStatus::Dispatch ? 'View Dispatch' : 'Dispatch'); ?>

                                                </a>
                                            <?php endif; ?>
                                            <?php if(($isPurchaser || auth()->user()->canManagePurchaseRequests() || auth()->user()->canManagePlantPurchases()) && in_array($pr->status->value, ['submitted', 'in_progress']) && $item->canSelectForPo()): ?>
                                                <a href="<?php echo e(route('plant.product-requests.edit', [$pr, 'item_id' => $item->id])); ?>"
                                                    class="btn btn-sm btn-outline-primary" title="Edit Request Item">
                                                    <i class="bi bi-pencil me-1"></i>Edit
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                 <?php echo $__env->make('partials.table-empty', ['colspan' => $isQuotationPoView ? 7 : ($isPurchaser ? 12 : 10), 'icon' => 'bi-clipboard-check', 'message' => 'No product requests'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($isPurchaser): ?>
            </form>
        <?php endif; ?>

        <?php if(in_array($activeStatus, ['add_quotation', 'create_po', 'dispatch']) && isset($groupedItems) && $isPurchaser): ?>
            <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $groupItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $firstGroupItem = $groupItems->first();
                ?>
                <form method="POST" action="<?php echo e(route('plant.product-requests.bulk-convert')); ?>" id="quote-form-<?php echo e($groupKey); ?>">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $groupItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($gItem->canSelectForPo()): ?>
                            <input type="hidden" name="product_request_item_ids[]" value="<?php echo e($gItem->id); ?>">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($firstGroupItem->supplier_id): ?>
                        <input type="hidden" name="supplier_id" value="<?php echo e($firstGroupItem->supplier_id); ?>">
                    <?php endif; ?>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <div class="mt-3"><?php echo e($items->links()); ?></div>

    <div class="modal fade" id="purchasePrintModal" tabindex="-1" aria-labelledby="purchasePrintModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="purchasePrintModalLabel">Print document</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-3">Enter letterhead details for <strong
                            id="print_modal_reference">—</strong> PDF.</p>
                    <div class="mb-2">
                        <label class="form-label small mb-1" for="print_company_name">Company name</label>
                        <input type="text" id="print_company_name" class="form-control form-control-sm" required
                            maxlength="200">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small mb-1" for="print_company_address">Address</label>
                        <textarea id="print_company_address" class="form-control form-control-sm" rows="3"
                            maxlength="1000"></textarea>
                    </div>
                    <div class="mb-0">
                        <label class="form-label small mb-1" for="print_company_gstin">GSTIN</label>
                        <input type="text" id="print_company_gstin" class="form-control form-control-sm" maxlength="20"
                            placeholder="e.g. 22AAAAA0000A1Z5">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-admin-outline btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary btn-sm" id="btn_confirm_print">
                        <i class="bi bi-printer me-1"></i>Print PDF
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if($isPurchaser): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            (() => {
                const form = document.getElementById('bulk-quotation-form');
                if (!form) return;

                const selectAll = document.getElementById('select-all-requests');
                const boxes = () => Array.from(document.querySelectorAll('.request-select'));
                const btn = document.getElementById('bulk-generate-btn');
                const exportBtn = document.getElementById('bulk-export-btn');
                const hint = document.getElementById('bulk-selection-hint');

                const STORAGE_KEY = 'pr_selected_items';
                const LAST_STATUS_KEY = 'pr_last_status';
                const currentStatus = '<?php echo e($activeStatus ?? ""); ?>';

                const lastStatus = sessionStorage.getItem(LAST_STATUS_KEY);
                if (lastStatus !== null && lastStatus !== currentStatus) {
                    sessionStorage.removeItem(STORAGE_KEY);
                }
                sessionStorage.setItem(LAST_STATUS_KEY, currentStatus);

                function getStoredItems() {
                    try {
                        return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || '{}');
                    } catch (e) {
                        return {};
                    }
                }

                function saveStoredItems(items) {
                    try {
                        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(items));
                    } catch (e) {}
                }

                function restoreDomCheckboxes() {
                    const stored = getStoredItems();
                    boxes().forEach((el) => {
                        if (stored[el.value]) {
                            el.checked = true;
                        }
                    });
                }

                function updateStorageFromDomItem(el) {
                    const stored = getStoredItems();
                    if (el.checked) {
                        stored[el.value] = {
                            id: String(el.value),
                            plantId: String(el.dataset.plantId || ''),
                            plantName: String(el.dataset.plantName || '')
                        };
                    } else {
                        delete stored[el.value];
                    }
                    saveStoredItems(stored);
                }

                function clearAllSelection() {
                    saveStoredItems({});
                    boxes().forEach((el) => { el.checked = false; });
                    sync();
                }

                function sync() {
                    const stored = getStoredItems();
                    const allSelected = Object.values(stored);
                    const plantIds = [...new Set(allSelected.map((el) => el.plantId).filter(Boolean))];
                    const samePlant = plantIds.length <= 1;

                    if (btn) btn.disabled = allSelected.length === 0 || !samePlant;
                    if (exportBtn) exportBtn.disabled = allSelected.length === 0;

                    if (allSelected.length === 0) {
                        hint.innerHTML = 'Select products. Export for supplier first, then add quotation. Same plant only.';
                        hint.classList.remove('text-danger');
                    } else if (!samePlant) {
                        hint.innerHTML = 'Adding quotation requires products from 1 plant/site. Use "Plant / Site" filter at top to select requests for one plant (or click Export for Supplier). <a href="#" id="js-clear-selection" class="ms-2 text-danger text-decoration-underline small">Clear selection</a>';
                        hint.classList.add('text-danger');
                    } else {
                        hint.classList.remove('text-danger');
                        const name = allSelected[0]?.plantName || 'site';
                        const label = allSelected.length === 1 ? '1 product' : `${allSelected.length} products`;
                        const visibleCheckedCount = boxes().filter((el) => el.checked).length;
                        const pageNote = allSelected.length > visibleCheckedCount ? ' (across pages)' : '';
                        hint.innerHTML = `${label}${pageNote} selected from ${name} — Export for supplier, then Add Quotation <a href="#" id="js-clear-selection" class="btn btn-sm btn-secondary ms-2">Clear selection</a>`;
                    }

                    const clearBtn = document.getElementById('js-clear-selection');
                    if (clearBtn) {
                        clearBtn.onclick = (e) => {
                            e.preventDefault();
                            clearAllSelection();
                        };
                    }

                    if (selectAll) {
                        const enabled = boxes();
                        const checkedOnPage = enabled.filter((el) => el.checked);
                        selectAll.checked = enabled.length > 0 && checkedOnPage.length === enabled.length;
                        selectAll.indeterminate = (checkedOnPage.length > 0 && checkedOnPage.length < enabled.length) || (checkedOnPage.length === 0 && allSelected.length > 0);
                    }
                }

                restoreDomCheckboxes();

                selectAll?.addEventListener('change', () => {
                    const enabled = boxes();
                    const stored = getStoredItems();
                    if (selectAll.checked && enabled.length) {
                        const firstPlant = enabled[0].dataset.plantId;
                        enabled.forEach((el) => {
                            if (el.dataset.plantId === firstPlant) {
                                el.checked = true;
                                stored[el.value] = {
                                    id: String(el.value),
                                    plantId: String(el.dataset.plantId || ''),
                                    plantName: String(el.dataset.plantName || '')
                                };
                            }
                        });
                    } else {
                        enabled.forEach((el) => {
                            el.checked = false;
                            delete stored[el.value];
                        });
                    }
                    saveStoredItems(stored);
                    sync();
                });

                document.addEventListener('change', (e) => {
                    if (e.target.classList.contains('request-select')) {
                        updateStorageFromDomItem(e.target);
                        sync();
                    }
                });

                form.addEventListener('click', (e) => {
                    const single = e.target.closest('.js-single-product');
                    if (!single || !form.contains(single)) return;
                    const id = String(single.dataset.itemId || '');
                    const targetBox = boxes().find((el) => el.value === id);
                    const stored = {};
                    boxes().forEach((el) => { el.checked = el.value === id; });
                    if (targetBox) {
                        stored[id] = {
                            id: id,
                            plantId: String(targetBox.dataset.plantId || ''),
                            plantName: String(targetBox.dataset.plantName || '')
                        };
                    }
                    saveStoredItems(stored);
                    sync();
                });

                form.addEventListener('submit', (e) => {
                    const stored = getStoredItems();
                    const allSelected = Object.values(stored);
                    const plantIds = [...new Set(allSelected.map((el) => el.plantId).filter(Boolean))];

                    if (allSelected.length === 0) {
                        e.preventDefault();
                        alert('Please select at least one product.');
                        return;
                    }

                    const unlinkedBoxes = boxes().filter((box) => box.checked && box.dataset.hasProduct === '0');
                    if (unlinkedBoxes.length > 0) {
                        e.preventDefault();
                        alert('One or more selected items do not have a catalog product assigned. Please click "+ Create Product" to link the product first.');
                        return;
                    }

                    const action = (e.submitter && e.submitter.getAttribute('formaction')) || form.action;
                    const isExport = action.includes('export-supplier');

                    if (isExport) {
                        const supplierSelect = document.getElementById('export-supplier-select');
                        if (!supplierSelect || !supplierSelect.value) {
                            e.preventDefault();
                            alert('Please select a supplier before exporting inquiry.');
                            return;
                        }
                    }

                    if (!isExport && plantIds.length > 1) {
                        e.preventDefault();
                        alert('Select products from one plant/site only.');
                        return;
                    }

                    if (!isExport) {
                        const label = allSelected.length === 1 ? '1 product' : `${allSelected.length} products`;
                        if (!confirm(`Add quotation for ${label}?`)) {
                            e.preventDefault();
                            return;
                        }
                    }

                    form.querySelectorAll('.js-hidden-request-item').forEach((el) => el.remove());
                    boxes().forEach((el) => el.removeAttribute('name'));

                    allSelected.forEach((item) => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'product_request_item_ids[]';
                        input.value = item.id;
                        input.className = 'js-hidden-request-item';
                        form.appendChild(input);
                    });

                    if (!isExport) {
                        sessionStorage.removeItem(STORAGE_KEY);
                    } else {
                        sessionStorage.removeItem(STORAGE_KEY);
                        setTimeout(() => {
                            window.location.href = "<?php echo e(route('plant.product-requests.index', ['status' => 'add_quotation'])); ?>";
                        }, 1200);
                    }
                });

                sync();
            })();

            (function () {
                const modalEl = document.getElementById('purchasePrintModal');
                if (!modalEl) return;

                const modal = new bootstrap.Modal(modalEl);
                let activePdfUrl = '';

                document.querySelectorAll('.btn-print-purchase').forEach(function (btn) {
                    btn.addEventListener('click', function () {
                        activePdfUrl = btn.dataset.pdfUrl || '';
                        document.getElementById('print_modal_reference').textContent = btn.dataset.reference || '—';
                        document.getElementById('print_company_name').value = btn.dataset.defaultName || '';
                        document.getElementById('print_company_address').value = btn.dataset.defaultAddress || '';
                        document.getElementById('print_company_gstin').value = btn.dataset.defaultGstin || '';
                        modal.show();
                    });
                });

                document.getElementById('btn_confirm_print')?.addEventListener('click', function () {
                    const name = document.getElementById('print_company_name').value.trim();
                    if (!name || !activePdfUrl) return;
                    const params = new URLSearchParams({
                        company_name: name,
                        company_address: document.getElementById('print_company_address').value.trim(),
                        company_gstin: document.getElementById('print_company_gstin').value.trim(),
                    });
                    window.open(activePdfUrl + (activePdfUrl.includes('?') ? '&' : '?') + params.toString(), '_blank');
                    modal.hide();
                });
            })();
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
    <style>
        .autocomplete-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            max-height: 250px;
            overflow-y: auto;
            z-index: 1050;
            margin-top: 2px;
        }

        .suggestion-item {
            cursor: pointer;
            transition: background 0.15s ease-in-out;
        }

        .suggestion-item:hover {
            background-color: #f8f9fa;
        }

        .suggestion-item:last-child {
            border-bottom: none !important;
        }
    </style>
    <?php echo $__env->make('partials.infinite-suggestions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php
        $productSearchData = $products->map(fn($p) => [
            'id' => $p->id,
            'name' => $p->name,
            'sku' => $p->sku ?? '',
        ])->values();
    ?>
    <script type="application/json" id="products-search-data"><?php echo json_encode($productSearchData, 15, 512) ?></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('product-search');
            const suggestionsBox = document.getElementById('autocomplete-suggestions');
            const productsDataEl = document.getElementById('products-search-data');
            if (!searchInput || !suggestionsBox || !productsDataEl) {
                return;
            }

            const products = JSON.parse(productsDataEl.textContent);

            const infinite = window.PanchmukhiInfiniteSuggestions.create(suggestionsBox, {
                pageSize: 25,
                renderItem: function (p) {
                    const div = document.createElement('div');
                    div.className = 'suggestion-item px-3 py-2 border-bottom text-start';
                    div.innerHTML = `<span class="fw-semibold text-dark d-block text-truncate" style="max-width:100%">${p.name}</span> <span class="text-muted small">${p.sku}</span>`;
                    div.addEventListener('click', function () {
                        searchInput.value = p.name;
                        infinite.reset();
                        suggestionsBox.classList.add('d-none');
                        searchInput.form.submit();
                    });
                    return div;
                },
            });

            searchInput.addEventListener('input', function () {
                const val = this.value.trim().toLowerCase();

                if (!val) {
                    infinite.reset();
                    suggestionsBox.classList.add('d-none');
                    return;
                }

                const filtered = products.filter(function (p) {
                    return p.name.toLowerCase().includes(val) ||
                        (p.sku && p.sku.toLowerCase().includes(val));
                });

                if (!infinite.setResults(filtered)) {
                    suggestionsBox.classList.add('d-none');
                    return;
                }

                suggestionsBox.classList.remove('d-none');
            });

            document.addEventListener('click', function (e) {
                if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
                    infinite.reset();
                    suggestionsBox.classList.add('d-none');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/request-po/product-requests/index.blade.php ENDPATH**/ ?>