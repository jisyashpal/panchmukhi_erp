<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Dashboard','subtitle' => 'System overview — master data & operations oversight']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','subtitle' => 'System overview — master data & operations oversight']); ?>
    <form method="GET" class="d-flex align-items-center gap-2">
        <select name="plant_id" onchange="this.form.submit()" class="form-select form-select-sm" style="min-width: 180px;">
            <option value="">All plants</option>
            <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($plant->id); ?>" <?php if($plantId == $plant->id): echo 'selected'; endif; ?>><?php echo e($plant->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-stat-grid mb-3">
    <a href="<?php echo e(route('admin.plants.index')); ?>" class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-building"></i></div>
        <div class="stat-label">Active Plants</div>
        <div class="stat-value"><?php echo e($activePlants); ?></div>
    </a>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="admin-stat-card stat-accent-violet">
        <div class="stat-icon stat-icon-violet"><i class="bi bi-people"></i></div>
        <div class="stat-label">Active Users</div>
        <div class="stat-value"><?php echo e($usersCount); ?></div>
    </a>
    <a href="<?php echo e(route('admin.products.index')); ?>" class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-box"></i></div>
        <div class="stat-label">Products</div>
        <div class="stat-value"><?php echo e($productsCount); ?></div>
    </a>
    <a href="<?php echo e(route('ho.stocks.index', array_filter(['plant_id' => $plantId ?: null]))); ?>" class="admin-stat-card stat-accent-amber">
        <div class="stat-icon stat-icon-amber"><i class="bi bi-boxes"></i></div>
        <div class="stat-label">Stock Lines</div>
        <div class="stat-value"><?php echo e($totalStockLines); ?></div>
    </a>
    <a href="<?php echo e(route('ho.purchases.index', array_filter(['plant_id' => $plantId ?: null, 'status' => 'ordered']))); ?>" class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-cart"></i></div>
        <div class="stat-label">Pending Orders</div>
        <div class="stat-value"><?php echo e($pendingOrders); ?></div>
    </a>
    <a href="<?php echo e(route('ho.purchases.index', array_filter(['plant_id' => $plantId ?: null, 'status' => 'delivered']))); ?>" class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-check2-circle"></i></div>
        <div class="stat-label">Delivered Purchases</div>
        <div class="stat-value"><?php echo e($deliveredPurchases); ?></div>
    </a>
</div>

<div class="row g-4 mt-1">
    <div class="col-lg-4">
        <div class="admin-card admin-card-body h-100">
            <h2 class="h6">Operations Overview</h2>
            <p class="small text-muted">Access HO operations (stock, PO, reports) with full Super Admin visibility.</p>
            <div class="d-grid gap-2">
                <a href="<?php echo e(route('ho.dashboard')); ?>" class="btn btn-admin-outline btn-sm">HO Dashboard</a>
                <a href="<?php echo e(route('ho.product-requests.index')); ?>" class="btn btn-admin-outline btn-sm">Product Requests</a>
                <a href="<?php echo e(route('ho.stocks.index')); ?>" class="btn btn-admin-outline btn-sm">Stocks</a>
                <a href="<?php echo e(route('ho.product-life.index')); ?>" class="btn btn-admin-outline btn-sm">Product Life</a>
                <a href="<?php echo e(route('ho.reports.index')); ?>" class="btn btn-admin-outline btn-sm">Reports</a>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Low Stock</h2>
                <a href="<?php echo e(route('ho.stocks.index', array_filter(['plant_id' => $plantId ?: null]))); ?>" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Plant</th><th>Product</th><th class="text-end">Qty</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row->plant->name); ?></td>
                            <td>
                                <?php if($row->product && $row->plant_id): ?>
                                    <a href="<?php echo e(route('ho.stocks.show', ['plant_id' => $row->plant_id, 'product_id' => $row->product_id])); ?>">
                                        <?php echo e($row->product->name); ?>

                                    </a>
                                <?php else: ?>
                                    <?php echo e($row->product->name ?? ''); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-end text-danger fw-semibold"><?php echo e($row->quantity); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3"><div class="admin-empty">No low stock</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="admin-card admin-table-card h-100">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Recent Purchases</h2>
                <a href="<?php echo e(route('ho.purchases.index', array_filter(['plant_id' => $plantId ?: null]))); ?>" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Ref</th><th>Plant</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('ho.purchases.show', $purchase)); ?>"><?php echo e($purchase->reference_no); ?></a></td>
                            <td><?php echo e($purchase->plant->name); ?></td>
                            <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchase->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchase->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3"><div class="admin-empty">No purchases</div></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/admin/operation/dashboard.blade.php ENDPATH**/ ?>