<?php $__env->startSection('title', 'Reset password'); ?>
<?php $__env->startSection('content'); ?>
    <div class="text-center mb-4">
        <h1 class="h4 fw-bold mb-1">Reset password</h1>
        <p class="text-muted small mb-0">Choose a new password for your account</p>
    </div>

    <form method="POST" action="<?php echo e(route('password.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

        <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Email','name' => 'email','type' => 'email','icon' => 'bi-envelope','value' => $request->email,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'email','type' => 'email','icon' => 'bi-envelope','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($request->email),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'New password','name' => 'password','type' => 'password','icon' => 'bi-lock','required' => true,'toggle' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'New password','name' => 'password','type' => 'password','icon' => 'bi-lock','required' => true,'toggle' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Confirm password','name' => 'password_confirmation','type' => 'password','icon' => 'bi-lock-fill','required' => true,'toggle' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Confirm password','name' => 'password_confirmation','type' => 'password','icon' => 'bi-lock-fill','required' => true,'toggle' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

        <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check2-circle me-1"></i> Reset password
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\auth\reset-password.blade.php ENDPATH**/ ?>