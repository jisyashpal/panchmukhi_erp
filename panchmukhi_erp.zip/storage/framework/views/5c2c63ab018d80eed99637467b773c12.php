<?php $__env->startSection('title', 'Product Life Report'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Product Life Usage Report','subtitle' => 'Vehicle-wise part changes with meter readings and life used']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Life Usage Report','subtitle' => 'Vehicle-wise part changes with meter readings and life used']); ?>
        <?php if (isset($component)) { $__componentOriginal936094a68edd25a90036587134359cc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal936094a68edd25a90036587134359cc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-export-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-export-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $attributes = $__attributesOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__attributesOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $component = $__componentOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__componentOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginald01db17e57e28d17475e8f3829de3bd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01db17e57e28d17475e8f3829de3bd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-filters','data' => ['plants' => $plants,'categories' => $categories,'products' => $products,'vehicles' => $vehicles,'showDates' => true,'searchPlaceholder' => 'Product, vehicle, subcategory or plant...','clearRoute' => route('ho.reports.product-life')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['plants' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($plants),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'vehicles' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicles),'show-dates' => true,'search-placeholder' => 'Product, vehicle, subcategory or plant...','clear-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.reports.product-life'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $attributes = $__attributesOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $component = $__componentOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__componentOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>

    <?php if($entries->isNotEmpty()): ?>
        <div class="admin-stat-grid mb-3">
            <div class="admin-stat-card stat-accent-blue">
                <div class="stat-icon stat-icon-blue"><i class="bi bi-clock-history"></i></div>
                <div class="stat-label">Total Life Used</div>
                <div class="stat-value"><?php echo e(number_format($entries->sum('life_hours'), 1)); ?></div>
            </div>
            <div class="admin-stat-card stat-accent-violet">
                <div class="stat-icon stat-icon-violet"><i class="bi bi-boxes"></i></div>
                <div class="stat-label">Total Qty Used</div>
                <div class="stat-value"><?php echo e(number_format($entries->sum('quantity'), 0)); ?></div>
            </div>
            <div class="admin-stat-card stat-accent-emerald">
                <div class="stat-icon stat-icon-emerald"><i class="bi bi-truck"></i></div>
                <div class="stat-label">Vehicles</div>
                <div class="stat-value"><?php echo e(number_format($entries->pluck('vehicle_id')->filter()->unique()->count(), 0)); ?></div>
            </div>
            <div class="admin-stat-card stat-accent-amber">
                <div class="stat-icon stat-icon-amber"><i class="bi bi-calculator"></i></div>
                <div class="stat-label">Avg Life Used / Entry</div>
                <div class="stat-value"><?php echo e(number_format($entries->avg('life_hours'), 1)); ?></div>
            </div>
        </div>
    <?php endif; ?>

    <div class="admin-card admin-table-card">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Plant</th>
                        <th>Vehicle</th>
                        <th>Current item</th>
                        <th>Replaced item</th>
                        <th>Item Type</th>
                        <th>Meter</th>
                        <th class="text-end">Prev</th>
                        <th class="text-end">Current</th>
                        <th class="text-end">Prev. item life</th>
                        <th class="text-end">Qty</th>
                        <th>Recorded By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $unit = $e->meterUnitLabel(); ?>
                        <tr>
                            <td class="text-nowrap text-muted"><?php echo e($e->used_at->format('d M Y')); ?></td>
                            <td><?php echo e($e->plant->name); ?></td>
                            <td class="fw-semibold"><?php echo e($e->vehicle?->displayLabel() ?? '—'); ?></td>
                            <td>
                                <span class="fw-semibold"><?php echo e($e->product->name); ?></span>
                                <?php if($e->product->category): ?>
                                    <div class="small text-muted"><?php echo e($e->product->category->name); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted"><?php echo e($e->replacedProduct?->name ?? '—'); ?></td>
                            <td><?php echo e($e->subCategory?->name ?? '—'); ?></td>
                            <td><?php echo e($e->meter_type === 'km' ? 'KM' : 'Hours'); ?></td>
                            <td class="text-end text-muted">
                                <?php echo e($e->previous_reading !== null ? number_format($e->previous_reading, 2).' '.$unit : '—'); ?>

                            </td>
                            <td class="text-end">
                                <?php echo e($e->current_reading !== null ? number_format($e->current_reading, 2).' '.$unit : '—'); ?>

                            </td>
                            <td class="text-end fw-semibold text-primary">
                                <?php echo e(number_format($e->life_hours, 2)); ?> <?php echo e($unit); ?>

                            </td>
                            <td class="text-end"><?php echo e(number_format($e->quantity, 2)); ?></td>
                            <td class="small text-muted"><?php echo e($e->recorder->name ?? '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php echo $__env->make('partials.table-empty', [
                            'colspan' => 12,
                            'icon' => 'bi-clock-history',
                            'message' => 'No usage entries found for the selected filters.'
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                </tbody>
                <?php if($entries->isNotEmpty()): ?>
                    <tfoot class="table-light fw-bold">
                        <tr>
                            <td colspan="9">Total / Summary</td>
                            <td class="text-end text-primary"><?php echo e(number_format($entries->sum('life_hours'), 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format($entries->sum('quantity'), 2)); ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/ho/reports/product-life.blade.php ENDPATH**/ ?>