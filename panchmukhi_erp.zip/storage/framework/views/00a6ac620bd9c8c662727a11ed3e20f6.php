<?php if(request('redirect') === 'products.create'): ?>
    <input type="hidden" name="redirect" value="products.create">
    <?php $__currentLoopData = [
        'product_request_id',
        'product_request_item_id',
        'pc_name',
        'pc_size',
        'pc_sku_code',
        'pc_category_id',
        'pc_sub_category_id',
        'pc_brand_id',
        'pc_unit_id',
        'pc_reorder_level',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(request()->filled($key)): ?>
            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e(request($key)); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views/partials/catalog-form-return.blade.php ENDPATH**/ ?>