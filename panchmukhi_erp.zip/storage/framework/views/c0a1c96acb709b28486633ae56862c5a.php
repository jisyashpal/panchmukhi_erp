<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['route', 'param' => 'tab', 'tabs' => [], 'active' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['route', 'param' => 'tab', 'tabs' => [], 'active' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $key = $tab['key'] ?? null;
            $isActive = $active !== null
                ? (string) $active === (string) ($key ?? '')
                : ($key === null ? !request($param) : request($param) === $key);
            $query = request()->except($param);
            $url = $key === null
                ? route($route, $query)
                : route($route, array_merge($query, [$param => $key]));
        ?>
        <a href="<?php echo e($url); ?>" class="btn btn-sm <?php echo e($isActive ? 'btn-admin-primary' : 'btn-admin-outline'); ?>">
            <?php echo e($tab['label']); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/partials/status-tabs.blade.php ENDPATH**/ ?>