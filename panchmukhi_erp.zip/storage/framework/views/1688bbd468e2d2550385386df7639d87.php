<a href="<?php echo e(request()->fullUrlWithQuery(['export' => 'excel'])); ?>" class="btn btn-success btn-sm">
    <i class="bi bi-file-earmark-excel me-1"></i>Export Excel
</a>
<?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views/components/report-export-button.blade.php ENDPATH**/ ?>