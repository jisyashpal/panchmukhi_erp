<?php
    $user = auth()->user();
    $unread = $user->unreadNotifications()->limit(5)->get();
    $unreadCount = $user->unreadNotifications()->count();
    $indexRoute = $indexRoute ?? (auth()->user()->isSuperAdmin() ? 'admin.notifications.index' : 'plant.notifications.index');
    $readRoute = $readRoute ?? (auth()->user()->isSuperAdmin() ? 'admin.notifications.read' : 'plant.notifications.read');
    $readAllRoute = $readAllRoute ?? (auth()->user()->isSuperAdmin() ? 'admin.notifications.read-all' : 'plant.notifications.read-all');
?>
<div class="dropdown">
    <button class="btn btn-admin-outline btn-sm position-relative" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-bell"></i>
        <?php if($unreadCount > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:.6rem"><?php echo e($unreadCount > 9 ? '9+' : $unreadCount); ?></span>
        <?php endif; ?>
    </button>
    <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width: 280px;">
        <li class="dropdown-header d-flex justify-content-between align-items-center">
            <span>Notifications</span>
            <?php if($unreadCount > 0): ?>
                <form method="POST" action="<?php echo e(route($readAllRoute)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-link btn-sm p-0">Mark all read</button>
                </form>
            <?php endif; ?>
        </li>
        <?php $__empty_1 = true; $__currentLoopData = $unread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
                <form method="POST" action="<?php echo e(route($readRoute, $notification->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item py-2 text-wrap">
                        <strong class="d-block small"><?php echo e($notification->data['title'] ?? 'Notification'); ?></strong>
                        <span class="text-muted small"><?php echo e($notification->data['body'] ?? ''); ?></span>
                    </button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li><span class="dropdown-item text-muted small">No new notifications</span></li>
        <?php endif; ?>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item small" href="<?php echo e(route($indexRoute)); ?>">View all</a></li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\partials\notification-bell.blade.php ENDPATH**/ ?>