<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'permission' => null,
    'modules' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'permission' => null,
    'modules' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Permission Name','name' => 'name','value' => old('name', $permission?->name),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Permission Name','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $permission?->name)),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Slug','name' => 'slug']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Slug','name' => 'slug']); ?>
    <input
        type="text"
        name="slug"
        id="slug"
        value="<?php echo e(old('slug', $permission?->slug)); ?>"
        class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        <?php if($permission?->is_system): ?> readonly <?php endif; ?>
    >
    <?php if($permission?->is_system): ?>
        <div class="form-text">System permission slug cannot be changed.</div>
    <?php else: ?>
        <div class="form-text">Use module.action format, e.g. plant.manage_stocks</div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Module','name' => 'module','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Module','name' => 'module','required' => true]); ?>
    <select name="module" id="module" class="form-select" required <?php if($permission?->is_system): ?> disabled <?php endif; ?>>
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if(old('module', $permission?->module) === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($permission?->is_system): ?>
        <input type="hidden" name="module" value="<?php echo e($permission->module); ?>">
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal0244777875246e7d173bea3ea5b97cf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0244777875246e7d173bea3ea5b97cf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-group','data' => ['label' => 'Description','name' => 'description','col' => 'col-md-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Description','name' => 'description','col' => 'col-md-12']); ?>
    <textarea name="description" id="description" class="form-control" rows="2"><?php echo e(old('description', $permission?->description)); ?></textarea>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $attributes = $__attributesOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__attributesOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0244777875246e7d173bea3ea5b97cf0)): ?>
<?php $component = $__componentOriginal0244777875246e7d173bea3ea5b97cf0; ?>
<?php unset($__componentOriginal0244777875246e7d173bea3ea5b97cf0); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal27ffeafbd49997657e042154724f3e70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ffeafbd49997657e042154724f3e70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-form-input','data' => ['label' => 'Sort Order','name' => 'sort_order','type' => 'number','value' => old('sort_order', $permission?->sort_order ?? 10)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sort Order','name' => 'sort_order','type' => 'number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('sort_order', $permission?->sort_order ?? 10))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $attributes = $__attributesOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__attributesOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ffeafbd49997657e042154724f3e70)): ?>
<?php $component = $__componentOriginal27ffeafbd49997657e042154724f3e70; ?>
<?php unset($__componentOriginal27ffeafbd49997657e042154724f3e70); ?>
<?php endif; ?>
<?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\admin\master\permissions\partials\form-fields.blade.php ENDPATH**/ ?>