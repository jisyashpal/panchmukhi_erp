<?php
    $pageTitle = $pageTitle ?? 'Admin';
?>
<header class="admin-topbar">
    <div class="admin-topbar-start">
        <button class="admin-menu-btn d-lg-none flex-shrink-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebarOffcanvas" aria-label="Open menu">
            <i class="bi bi-list fs-5"></i>
        </button>

        <div class="admin-topbar-heading min-w-0">
            <nav class="admin-topbar-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
                <i class="bi bi-chevron-right"></i>
                <span><?php echo e($pageTitle); ?></span>
            </nav>
            <h1 class="admin-topbar-title text-truncate"><?php echo e($pageTitle); ?></h1>
        </div>
    </div>

    <div class="admin-topbar-center d-none d-lg-flex">
        <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="admin-topbar-search">
            <i class="bi bi-search"></i>
            <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search products..." aria-label="Search products">
        </form>
    </div>

    <div class="admin-topbar-end">
        <?php if(isset($financialYear)): ?>
            <div class="d-none d-lg-flex align-items-center gap-2 me-2">
                <?php if (isset($component)) { $__componentOriginal4be369a9030485a61f998f024d2f0b89 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4be369a9030485a61f998f024d2f0b89 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.financial-year-select','data' => ['compact' => true,'formAction' => route('ho.financial-year.set'),'style' => 'min-width: 8rem;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('financial-year-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['compact' => true,'form-action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.financial-year.set')),'style' => 'min-width: 8rem;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $attributes = $__attributesOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__attributesOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4be369a9030485a61f998f024d2f0b89)): ?>
<?php $component = $__componentOriginal4be369a9030485a61f998f024d2f0b89; ?>
<?php unset($__componentOriginal4be369a9030485a61f998f024d2f0b89); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>

        <span class="admin-topbar-date d-none d-xl-inline-flex">
            <i class="bi bi-calendar3"></i>
            <?php echo e(now()->format('l, d M Y')); ?>

        </span>

        <a href="<?php echo e(route('admin.dashboard')); ?>" class="admin-topbar-icon-btn d-none d-sm-inline-flex" title="Dashboard">
            <i class="bi bi-speedometer2"></i>
        </a>

        <div class="dropdown">
            <button type="button" class="admin-topbar-icon-btn" data-bs-toggle="dropdown" aria-expanded="false" title="Quick links">
                <i class="bi bi-grid-3x3-gap"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end admin-topbar-dropdown shadow border-0">
                <li class="dropdown-header small text-uppercase">Quick access</li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.plants.index')); ?>"><i class="bi bi-building me-2"></i>Plants</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.products.index')); ?>"><i class="bi bi-box-seam me-2"></i>Products</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('ho.product-requests.index')); ?>"><i class="bi bi-clipboard-check me-2"></i>Product Requests</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('ho.purchases.index')); ?>"><i class="bi bi-cart me-2"></i>Purchases</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('ho.stocks.index')); ?>"><i class="bi bi-boxes me-2"></i>Stock</a></li>
            </ul>
        </div>

        <?php if (! empty(trim($__env->yieldContent('topbar-actions')))): ?>
            <div class="admin-topbar-page-actions d-none d-md-flex align-items-center gap-2">
                <?php echo $__env->yieldContent('topbar-actions'); ?>
            </div>
        <?php endif; ?>

        <?php echo $__env->make('partials.notification-bell', ['indexRoute' => 'admin.notifications.index', 'readRoute' => 'admin.notifications.read'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="dropdown">
            <a href="#" class="admin-user-chip dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="admin-user-chip-avatar">
                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                </span>
                <span class="d-none d-sm-block text-start">
                    <span class="d-block small fw-semibold lh-1 text-truncate" style="max-width: 120px;"><?php echo e(auth()->user()->name); ?></span>
                    <span class="text-muted" style="font-size: .7rem;">Super Admin</span>
                </span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end admin-topbar-dropdown shadow border-0">
                <li class="px-3 py-2 border-bottom">
                    <div class="small fw-semibold"><?php echo e(auth()->user()->name); ?></div>
                    <div class="text-muted" style="font-size: .75rem;"><?php echo e(auth()->user()->email); ?></div>
                </li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.profile.edit')); ?>"><i class="bi bi-person me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\partials\admin-topbar.blade.php ENDPATH**/ ?>