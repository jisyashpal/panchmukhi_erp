<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'permissionsByModule' => [],
    'assignedPermissionIds' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'permissionsByModule' => [],
    'assignedPermissionIds' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($permissionsByModule === []): ?>
    <div class="col-12">
        <div class="alert alert-light border mb-0">
            No permissions defined yet.
            <a href="<?php echo e(route('admin.permissions.create')); ?>">Add a permission</a> first.
        </div>
    </div>
<?php else: ?>
    <div class="col-12">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <label class="form-label fw-semibold mb-0">Permissions</label>
                <p class="text-muted small mb-0">Select what users with this role can do across each portal.</p>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-admin-outline btn-sm" data-permission-select-all>
                    <i class="bi bi-check2-square me-1"></i>Select all
                </button>
                <button type="button" class="btn btn-admin-outline btn-sm" data-permission-clear-all>
                    <i class="bi bi-square me-1"></i>Clear all
                </button>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $permissionsByModule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="border rounded p-3 mb-2">
                <div class="d-flex justify-content-between align-items-center gap-2 mb-2">
                    <div class="fw-semibold small text-uppercase text-muted">
                        <?php echo e(config("permissions.modules.{$module}", ucfirst($module))); ?>

                    </div>
                    <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none" data-permission-module="<?php echo e($module); ?>">
                        Select all
                    </button>
                </div>
                <div class="row g-2">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-check">
                                <input
                                    type="checkbox"
                                    name="permission_ids[]"
                                    value="<?php echo e($permission->id); ?>"
                                    class="form-check-input permission-checkbox"
                                    data-permission-module="<?php echo e($module); ?>"
                                    id="permission_<?php echo e($permission->id); ?>"
                                    <?php if(in_array($permission->id, old('permission_ids', $assignedPermissionIds))): echo 'checked'; endif; ?>
                                >
                                <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>">
                                    <?php echo e($permission->name); ?>

                                    <code class="small text-muted d-block"><?php echo e($permission->slug); ?></code>
                                </label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkboxes = () => Array.from(document.querySelectorAll('.permission-checkbox'));

        document.querySelector('[data-permission-select-all]')?.addEventListener('click', function () {
            checkboxes().forEach((checkbox) => checkbox.checked = true);
        });

        document.querySelector('[data-permission-clear-all]')?.addEventListener('click', function () {
            checkboxes().forEach((checkbox) => checkbox.checked = false);
        });

        document.querySelectorAll('[data-permission-module]').forEach(function (button) {
            if (button.matches('button')) {
                button.addEventListener('click', function () {
                    const module = button.dataset.permissionModule;
                    document.querySelectorAll('.permission-checkbox[data-permission-module="' + module + '"]')
                        .forEach((checkbox) => checkbox.checked = true);
                });
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\admin\master\roles\partials\permission-fields.blade.php ENDPATH**/ ?>