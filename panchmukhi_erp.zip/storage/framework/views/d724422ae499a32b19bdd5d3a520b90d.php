<?php $__env->startSection('title', 'Purchases'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $quotations = $quotations ?? collect();
    $purchaseOrders = $purchaseOrders ?? $purchases;
?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Purchases','subtitle' => $isPurchaser ? 'Quotations and purchase orders' : 'View purchase orders for this plant']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Purchases','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isPurchaser ? 'Quotations and purchase orders' : 'View purchase orders for this plant')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="admin-filters mb-3">
    <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-md-4">
            <label class="form-label small">Search Quotation / PO / Supplier / Product</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm"
                placeholder="Reference, supplier, or product name...">
        </div>
        <div class="col-6 col-md-3">
            <label class="form-label small">From Date</label>
            <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-3">
            <label class="form-label small">To Date</label>
            <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control form-control-sm">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-admin-primary btn-sm"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->anyFilled(['search', 'from_date', 'to_date', 'purchase_request_id'])): ?>
                <a href="<?php echo e(route('plant.purchases.index')); ?>" class="btn btn-admin-outline btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<?php if($isPurchaser): ?>
<div class="admin-card admin-table-card mb-4">
    <div class="admin-card-header"><h2 class="h6 mb-0">Quotation Section</h2></div>
    <div class="table-responsive">
        <table class="table mb-0 align-middle">
            <thead>
                <tr>
                    <th>Quotation No.</th>
                    <th>Supplier Name</th>
                    <th>Date of Request</th>
                    <th>Site (Plant)</th>
                    <th class="text-end">Grand Total</th>
                    <th>Create Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $requestDate = $purchase->purchaseRequest?->productRequest?->created_at
                        ?? $purchase->purchaseRequest?->created_at;
                    $productNames = $purchase->items->map(fn ($item) => $item->product?->name)->filter()->unique()->values();
                ?>
                <tr>
                    <td>
                        <span class="fw-semibold text-dark"><?php echo e($purchase->reference_no); ?></span>
                        <?php if($productNames->isNotEmpty()): ?>
                            <span class="d-block small text-muted"><?php echo e($productNames->take(3)->implode(', ')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($purchase->supplier->name); ?></td>
                    <td class="small text-muted"><?php echo e($requestDate?->format('d M Y') ?? '—'); ?></td>
                    <td><?php echo e($purchase->plant->name); ?></td>
                    <td class="text-end fw-semibold">₹<?php echo e(number_format((float) $purchase->grand_total, 2)); ?></td>
                    <td class="small text-muted"><?php echo e($purchase->ordered_at?->format('d M Y') ?? $purchase->created_at?->format('d M Y') ?? '—'); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(route('plant.purchases.show', $purchase)); ?>" class="btn btn-sm btn-admin-outline me-1">
                            <i class="bi bi-eye me-1"></i>View
                        </a>
                        <button type="button"
                            class="btn btn-sm btn-outline-secondary me-1 btn-print-purchase"
                            data-pdf-url="<?php echo e(route('plant.purchases.pdf', $purchase)); ?>"
                            data-reference="<?php echo e($purchase->reference_no); ?>"
                            data-default-name="<?php echo e($pdfDefaults['company_name'] ?: $purchase->plant->name); ?>"
                            data-default-address="<?php echo e($pdfDefaults['company_address'] ?: ($purchase->plant->address ?? '')); ?>"
                            data-default-gstin="<?php echo e($pdfDefaults['company_gstin']); ?>">
                            <i class="bi bi-printer me-1"></i>Print
                        </button>
                        <?php if(! $purchase->hasConvertedPurchaseOrder()): ?>
                            <a href="<?php echo e(route('plant.purchases.create', ['quotation_id' => $purchase->id])); ?>" class="btn btn-sm btn-warning me-1">
                                <i class="bi bi-cart-plus me-1"></i>Create PO
                            </a>
                        <?php endif; ?>
                        <?php if($purchase->canBeEdited()): ?>
                            <a href="<?php echo e(route('plant.purchases.edit', $purchase)); ?>" class="btn btn-sm btn-outline-primary me-1">
                                <i class="bi bi-pencil me-1"></i>Edit
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        <div class="admin-empty">
                            <i class="bi bi-file-earmark-text d-block"></i>
                            No quotations found
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if(method_exists($quotations, 'links')): ?>
        <div class="admin-card-body border-top py-2"><?php echo e($quotations->links()); ?></div>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="admin-card-header"><h2 class="h6 mb-0"><?php echo e($isPurchaser ? 'PO Section (Purchase Orders)' : 'Purchase Orders'); ?></h2></div>
    <div class="table-responsive">
        <table class="table mb-0 align-middle">
            <thead>
                <tr>
                    <th>PO No.</th>
                    <th>Supplier Name</th>
                    <th>Date of Request</th>
                    <th>Site (Plant)</th>
                    <th class="text-end">Grand Total</th>
                    <th>Status</th>
                    <th>PO Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $requestDate = $purchase->purchaseRequest?->productRequest?->created_at
                        ?? $purchase->purchaseRequest?->created_at;
                    $productNames = $purchase->items->map(fn ($item) => $item->product?->name)->filter()->unique()->values();
                ?>
                <tr>
                    <td>
                        <span class="fw-semibold text-dark"><?php echo e($purchase->reference_no); ?></span>
                        <?php if($productNames->isNotEmpty()): ?>
                            <span class="d-block small text-muted"><?php echo e($productNames->take(3)->implode(', ')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($purchase->supplier->name); ?></td>
                    <td class="small text-muted"><?php echo e($requestDate?->format('d M Y') ?? '—'); ?></td>
                    <td><?php echo e($purchase->plant->name); ?></td>
                    <td class="text-end fw-semibold">₹<?php echo e(number_format((float) $purchase->grand_total, 2)); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchase->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchase->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td class="small text-muted"><?php echo e($purchase->ordered_at?->format('d M Y') ?? $purchase->created_at?->format('d M Y') ?? '—'); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(route('plant.purchases.show', $purchase)); ?>" class="btn btn-sm btn-admin-outline me-1">
                            <i class="bi bi-eye me-1"></i>View
                        </a>
                        <?php if($isPurchaser): ?>
                            <button type="button"
                                class="btn btn-sm btn-outline-secondary me-1 btn-print-purchase"
                                data-pdf-url="<?php echo e(route('plant.purchases.pdf', $purchase)); ?>"
                                data-reference="<?php echo e($purchase->reference_no); ?>"
                                data-default-name="<?php echo e($pdfDefaults['company_name'] ?: $purchase->plant->name); ?>"
                                data-default-address="<?php echo e($pdfDefaults['company_address'] ?: ($purchase->plant->address ?? '')); ?>"
                                data-default-gstin="<?php echo e($pdfDefaults['company_gstin']); ?>">
                                <i class="bi bi-printer me-1"></i>Print
                            </button>
                            <?php if($purchase->canBeEdited()): ?>
                                <a href="<?php echo e(route('plant.purchases.edit', $purchase)); ?>" class="btn btn-sm btn-outline-primary me-1">
                                    <i class="bi bi-pencil me-1"></i>Edit
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->user()->canManagePlantStocks() && $purchase->isDispatched() && $purchase->status !== \App\Enums\PurchaseStatus::Delivered): ?>
                            <a href="<?php echo e(route('plant.purchases.receive', $purchase)); ?>" class="btn btn-sm btn-success me-1">
                                <i class="bi bi-box-arrow-in-down me-1"></i>Receive
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">
                        <div class="admin-empty">
                            <i class="bi bi-truck d-block"></i>
                            No purchase orders found
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if(method_exists($purchaseOrders, 'links')): ?>
    <div class="mt-3"><?php echo e($purchaseOrders->links()); ?></div>
<?php endif; ?>

<?php if($isPurchaser): ?>
<div class="modal fade" id="purchasePrintModal" tabindex="-1" aria-labelledby="purchasePrintModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="purchasePrintModalLabel">Print document</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-3">Enter letterhead details for <strong id="print_modal_reference">—</strong> PDF.</p>
                <div class="mb-2">
                    <label class="form-label small mb-1" for="print_company_name">Company name</label>
                    <input type="text" id="print_company_name" class="form-control form-control-sm" required maxlength="200">
                </div>
                <div class="mb-2">
                    <label class="form-label small mb-1" for="print_company_address">Address</label>
                    <textarea id="print_company_address" class="form-control form-control-sm" rows="3" maxlength="1000"></textarea>
                </div>
                <div class="mb-0">
                    <label class="form-label small mb-1" for="print_company_gstin">GSTIN</label>
                    <input type="text" id="print_company_gstin" class="form-control form-control-sm" maxlength="20" placeholder="e.g. 22AAAAA0000A1Z5">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-admin-outline btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-sm" id="btn_confirm_print">
                    <i class="bi bi-printer me-1"></i>Print PDF
                </button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const modalEl = document.getElementById('purchasePrintModal');
    if (!modalEl) return;

    const modal = new bootstrap.Modal(modalEl);
    let activePdfUrl = '';

    document.querySelectorAll('.btn-print-purchase').forEach(function (btn) {
        btn.addEventListener('click', function () {
            activePdfUrl = btn.dataset.pdfUrl || '';
            document.getElementById('print_modal_reference').textContent = btn.dataset.reference || '—';
            document.getElementById('print_company_name').value = btn.dataset.defaultName || '';
            document.getElementById('print_company_address').value = btn.dataset.defaultAddress || '';
            document.getElementById('print_company_gstin').value = btn.dataset.defaultGstin || '';
            modal.show();
        });
    });

    document.getElementById('btn_confirm_print')?.addEventListener('click', function () {
        const name = document.getElementById('print_company_name').value.trim();
        if (!name || !activePdfUrl) return;
        const params = new URLSearchParams({
            company_name: name,
            company_address: document.getElementById('print_company_address').value.trim(),
            company_gstin: document.getElementById('print_company_gstin').value.trim(),
        });
        window.open(activePdfUrl + (activePdfUrl.includes('?') ? '&' : '?') + params.toString(), '_blank');
        modal.hide();
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/plant/request-po/purchases/index.blade.php ENDPATH**/ ?>