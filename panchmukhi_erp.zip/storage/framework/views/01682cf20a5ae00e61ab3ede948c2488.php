<?php $__env->startSection('title', 'Dispatch — '.$purchase->reference_no); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Dispatch — '.e($purchase->reference_no).'','subtitle' => ''.e($purchase->plant->name).' · '.e($purchase->supplier->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dispatch — '.e($purchase->reference_no).'','subtitle' => ''.e($purchase->plant->name).' · '.e($purchase->supplier->name).'']); ?>
    <a href="<?php echo e(route('plant.dispatch.index')); ?>" class="btn btn-admin-outline btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Back
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<div class="purchase-create-pr-strip mb-4">
    <div class="d-flex flex-wrap align-items-center gap-3">
        <span class="purchase-create-pr-icon"><i class="bi bi-truck"></i></span>
        <div class="flex-grow-1">
            <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                <span class="badge bg-primary"><?php echo e($purchase->reference_no); ?></span>
                <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $purchase->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($purchase->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                <?php if($purchase->dispatched_at): ?>
                    <span class="badge bg-success-subtle text-success border">Dispatched <?php echo e($purchase->dispatched_at->format('d M Y')); ?></span>
                <?php else: ?>
                    <span class="badge bg-warning-subtle text-warning border">Awaiting product-wise dispatch</span>
                <?php endif; ?>
            </div>
            <p class="mb-0 small text-muted">
                Set dispatch date per product. Mark items not sent by supplier, or choose an alternative product.
            </p>
        </div>
    </div>
</div>

<?php if($locked): ?>
<div class="alert alert-info">
    Dispatch is locked
    <?php if($purchase->dispatched_at): ?>
        (submitted <?php echo e($purchase->dispatched_at->format('d M Y')); ?><?php if($purchase->dispatcher): ?> by <?php echo e($purchase->dispatcher->name); ?><?php endif; ?>)
    <?php endif; ?>.
</div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('plant.dispatch.store', $purchase)); ?>" id="dispatch-form">
    <?php echo csrf_field(); ?>

    <div class="admin-card admin-table-card mb-4">
        <div class="admin-card-header">
            <h2 class="h6 mb-0"><i class="bi bi-box-seam me-2 text-primary"></i>Product-wise dispatch</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-sm mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th class="text-end">Ordered</th>
                        <th style="min-width: 11rem;">Status</th>
                        <th style="min-width: 9rem;">Dispatch date</th>
                        <th style="min-width: 6rem;" class="text-end">Dispatch qty</th>
                        <th style="min-width: 12rem;">Alternative / remark</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $status = old("items.$i.dispatch_status", $item->dispatch_status?->value);
                            $orderedName = $item->originalProduct?->name ?? $item->product?->name;
                        ?>
                        <tr class="dispatch-line" data-index="<?php echo e($i); ?>">
                            <td>
                                <input type="hidden" name="items[<?php echo e($i); ?>][id]" value="<?php echo e($item->id); ?>">
                                <span class="fw-semibold d-block"><?php echo e($orderedName); ?></span>
                                <?php if($item->product?->sku): ?>
                                    <code class="small text-muted"><?php echo e($item->product->sku); ?></code>
                                <?php endif; ?>
                                <?php if($item->dispatch_status === \App\Enums\PurchaseItemDispatchStatus::Alternative && $item->originalProduct): ?>
                                    <div class="small text-muted mt-1">
                                        Ordered: <?php echo e($item->originalProduct->name); ?> → Receiving: <?php echo e($item->product?->name); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end"><?php echo e(number_format($item->quantity, 2)); ?></td>
                            <td>
                                <select name="items[<?php echo e($i); ?>][dispatch_status]"
                                    class="form-select form-select-sm dispatch-status"
                                    <?php if($locked): echo 'disabled'; endif; ?> required>
                                    <option value="">— Select —</option>
                                    <?php $__currentLoopData = \App\Enums\PurchaseItemDispatchStatus::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($case->value); ?>" <?php if($status === $case->value): echo 'selected'; endif; ?>>
                                            <?php echo e($case->label()); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <input type="date" name="items[<?php echo e($i); ?>][dispatched_at]"
                                    value="<?php echo e(old("items.$i.dispatched_at", $item->dispatched_at?->format('Y-m-d') ?? now()->format('Y-m-d'))); ?>"
                                    class="form-control form-control-sm dispatch-date"
                                    <?php if($locked): echo 'disabled'; endif; ?>>
                            </td>
                            <td>
                                <input type="number" step="0.01" min="0.01" max="<?php echo e($item->quantity); ?>"
                                    name="items[<?php echo e($i); ?>][dispatched_quantity]"
                                    value="<?php echo e(old("items.$i.dispatched_quantity", $item->dispatched_quantity ?? $item->quantity)); ?>"
                                    class="form-control form-control-sm text-end dispatch-qty"
                                    <?php if($locked): echo 'disabled'; endif; ?>>
                            </td>
                            <td>
                                <select name="items[<?php echo e($i); ?>][alternative_product_id]"
                                    class="form-select form-select-sm dispatch-alt mb-1 d-none"
                                    <?php if($locked): echo 'disabled'; endif; ?>>
                                    <option value="">— Alternative product —</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($p->id !== ($item->original_product_id ?: $item->product_id) || $status === \App\Enums\PurchaseItemDispatchStatus::Alternative->value): ?>
                                            <option value="<?php echo e($p->id); ?>"
                                                <?php if(old("items.$i.alternative_product_id", $item->alternative_product_id) == $p->id): echo 'selected'; endif; ?>>
                                                <?php echo e($p->name); ?><?php if($p->sku): ?> (<?php echo e($p->sku); ?>)<?php endif; ?>
                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <textarea name="items[<?php echo e($i); ?>][dispatch_remark]" rows="2"
                                    class="form-control form-control-sm dispatch-remark"
                                    placeholder="Remark (required if not provided)"
                                    <?php if($locked): echo 'disabled'; endif; ?>><?php echo e(old("items.$i.dispatch_remark", $item->dispatch_remark)); ?></textarea>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (! ($locked)): ?>
    <div class="d-flex flex-wrap gap-2">
        <button type="submit" class="btn btn-success">
            <i class="bi bi-truck me-1"></i>Submit dispatch
        </button>
        <a href="<?php echo e(route('plant.dispatch.index')); ?>" class="btn btn-admin-outline">Cancel</a>
    </div>
    <?php endif; ?>
</form>

<?php $__env->startPush('scripts'); ?>
<script>
    function syncDispatchRow(row) {
        const status = row.querySelector('.dispatch-status')?.value || '';
        const dateInput = row.querySelector('.dispatch-date');
        const qtyInput = row.querySelector('.dispatch-qty');
        const altSelect = row.querySelector('.dispatch-alt');
        const remark = row.querySelector('.dispatch-remark');

        if (!dateInput || !qtyInput || !altSelect || !remark) return;

        const needsDate = status === 'dispatched' || status === 'alternative';
        const needsAlt = status === 'alternative';
        const needsRemark = status === 'not_provided';

        dateInput.disabled = dateInput.hasAttribute('data-locked') || !needsDate;
        qtyInput.disabled = qtyInput.hasAttribute('data-locked') || !needsDate;
        dateInput.required = needsDate && !dateInput.hasAttribute('data-locked');
        qtyInput.required = needsDate && !qtyInput.hasAttribute('data-locked');
        altSelect.classList.toggle('d-none', !needsAlt);
        altSelect.required = needsAlt;
        remark.required = needsRemark;
        remark.placeholder = needsRemark
            ? 'Why supplier did not provide this item *'
            : (needsAlt ? 'Optional note about alternative' : 'Optional remark');
    }

    document.addEventListener('DOMContentLoaded', () => {
        const locked = <?php echo json_encode($locked, 15, 512) ?>;
        document.querySelectorAll('.dispatch-line').forEach(row => {
            if (locked) {
                row.querySelectorAll('input, select, textarea').forEach(el => {
                    el.setAttribute('data-locked', '1');
                });
            }
            const statusEl = row.querySelector('.dispatch-status');
            statusEl?.addEventListener('change', () => syncDispatchRow(row));
            syncDispatchRow(row);
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views\plant\request-po\dispatch\show.blade.php ENDPATH**/ ?>