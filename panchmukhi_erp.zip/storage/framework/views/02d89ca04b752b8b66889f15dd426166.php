<?php $__env->startSection('title', 'Forgot password'); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-link btn-sm text-muted text-decoration-none px-0 mb-3">
        <i class="bi bi-arrow-left"></i> Back to sign in
    </a>

    <div class="text-center mb-4">
        <h1 class="h4 fw-bold mb-1">Forgot password?</h1>
        <p class="text-muted small mb-0">Enter your email and we will send a reset link</p>
    </div>

    <?php if(session('status')): ?>
    <div class="alert alert-success auth-form-alert d-flex align-items-start gap-2 mb-4" role="alert">
        <i class="bi bi-check-circle-fill flex-shrink-0 mt-1" aria-hidden="true"></i>
        <span><?php echo e(session('status')); ?></span>
    </div>
    <?php endif; ?>

    <?php echo $__env->make('partials.auth-form-errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.field','data' => ['label' => 'Email address','name' => 'email','type' => 'email','icon' => 'bi-envelope','placeholder' => 'you@company.com','required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email address','name' => 'email','type' => 'email','icon' => 'bi-envelope','placeholder' => 'you@company.com','required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $attributes = $__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__attributesOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084)): ?>
<?php $component = $__componentOriginalf40c869cfe85fb48932f2f2fcdacc084; ?>
<?php unset($__componentOriginalf40c869cfe85fb48932f2f2fcdacc084); ?>
<?php endif; ?>

        <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-send me-1"></i> Send reset link
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jissoftware/public_html/panchmukhi.jissoftware.in/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>