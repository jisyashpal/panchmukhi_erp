<?php $__env->startSection('title', 'Notifications'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Notifications','subtitle' => 'Alerts for requests, purchases and stock updates']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Notifications','subtitle' => 'Alerts for requests, purchases and stock updates']); ?>
        <?php if(auth()->user()->unreadNotifications()->count()): ?>
            <form method="POST" action="<?php echo e(route('admin.notifications.read-all')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-admin-outline btn-sm">
                    <i class="bi bi-check2-all me-1"></i>Mark all read
                </button>
            </form>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

    <div class="admin-card">
        <div class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $type = $n->data['type'] ?? '';
                    $iconClass = match($type) {
                        'stock_updated' => 'bi-box-seam text-primary bg-primary-subtle',
                        'product_request_new' => 'bi-file-earmark-text text-success bg-success-subtle',
                        'purchase_request_new' => 'bi-cart-plus text-warning bg-warning-subtle',
                        default => 'bi-bell text-secondary bg-secondary-subtle',
                    };
                    $targetUrl = \App\Support\RelativeUrl::normalize($n->data['url'] ?? null);
                ?>
                <form method="POST" action="<?php echo e(route('admin.notifications.read', $n->id)); ?>" class="d-block w-100 m-0">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="list-group-item list-group-item-action text-start p-3 border-bottom d-flex align-items-center justify-content-between gap-3 <?php echo e($n->read_at ? 'bg-white' : 'bg-light-subtle'); ?>">
                        <div class="d-flex align-items-center gap-3 min-w-0">
                            <div class="rounded-circle p-2 d-flex align-items-center justify-content-center flex-shrink-0 <?php echo e(explode(' ', $iconClass)[2] ?? 'bg-light'); ?>" style="width: 40px; height: 40px;">
                                <i class="bi <?php echo e(explode(' ', $iconClass)[0]); ?> <?php echo e(explode(' ', $iconClass)[1]); ?> fs-5"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="d-flex align-items-center gap-2 flex-wrap">
                                    <span class="fw-semibold text-dark <?php echo e($n->read_at ? '' : 'fw-bold'); ?>"><?php echo e($n->data['title'] ?? 'Notification'); ?></span>
                                    <?php if(!$n->read_at): ?>
                                        <span class="badge bg-primary rounded-pill" style="font-size: 0.65rem;">New</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-secondary small text-truncate mt-1" style="max-width: 600px;"><?php echo e($n->data['body'] ?? ''); ?></div>
                            </div>
                        </div>
                        <div class="text-end flex-shrink-0">
                            <small class="text-muted d-block" style="font-size: 0.75rem;"><?php echo e($n->created_at->diffForHumans()); ?></small>
                            <?php if($targetUrl): ?>
                                <small class="text-primary d-inline-flex align-items-center gap-1 mt-1" style="font-size: 0.75rem;">
                                    View <i class="bi bi-arrow-right"></i>
                                </small>
                            <?php endif; ?>
                        </div>
                    </button>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-5 text-muted text-center">
                    <i class="bi bi-bell-slash fs-1 d-block mb-2 text-secondary opacity-50"></i>
                    No notifications found
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="mt-3"><?php echo e($notifications->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\yashpal\panchmukhi_erp\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>