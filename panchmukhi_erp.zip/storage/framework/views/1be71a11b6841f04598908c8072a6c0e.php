<?php $__env->startSection('title', 'Purchase Ledger — ' . $category->name); ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e6ccc94deb46dfd1314097afabe5570 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-page-header','data' => ['title' => 'Purchase Ledger: '.e($category->name).'','subtitle' => 'All purchased items under this category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Purchase Ledger: '.e($category->name).'','subtitle' => 'All purchased items under this category']); ?>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('ho.reports.category-purchase', $filters->toQueryArray())); ?>"
           class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Back
        </a>
        <?php if (isset($component)) { $__componentOriginal936094a68edd25a90036587134359cc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal936094a68edd25a90036587134359cc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-export-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-export-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $attributes = $__attributesOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__attributesOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal936094a68edd25a90036587134359cc4)): ?>
<?php $component = $__componentOriginal936094a68edd25a90036587134359cc4; ?>
<?php unset($__componentOriginal936094a68edd25a90036587134359cc4); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $attributes = $__attributesOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__attributesOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570)): ?>
<?php $component = $__componentOriginal8e6ccc94deb46dfd1314097afabe5570; ?>
<?php unset($__componentOriginal8e6ccc94deb46dfd1314097afabe5570); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginald01db17e57e28d17475e8f3829de3bd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01db17e57e28d17475e8f3829de3bd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.report-filters','data' => ['plants' => $plants,'showDates' => true,'searchPlaceholder' => 'Product, PO ref, supplier...','clearRoute' => route('ho.reports.category-purchase.ledger', $category)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('report-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['plants' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($plants),'show-dates' => true,'search-placeholder' => 'Product, PO ref, supplier...','clear-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ho.reports.category-purchase.ledger', $category))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $attributes = $__attributesOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__attributesOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01db17e57e28d17475e8f3829de3bd7)): ?>
<?php $component = $__componentOriginald01db17e57e28d17475e8f3829de3bd7; ?>
<?php unset($__componentOriginald01db17e57e28d17475e8f3829de3bd7); ?>
<?php endif; ?>


<?php if($items->isNotEmpty()): ?>
<div class="admin-stat-grid mb-3">
    <div class="admin-stat-card stat-accent-blue">
        <div class="stat-icon stat-icon-blue"><i class="bi bi-list-ul"></i></div>
        <div class="stat-label">Line Items</div>
        <div class="stat-value"><?php echo e($items->count()); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-emerald">
        <div class="stat-icon stat-icon-emerald"><i class="bi bi-boxes"></i></div>
        <div class="stat-label">Total Qty</div>
        <div class="stat-value"><?php echo e(number_format($items->sum('quantity'), 0)); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-violet">
        <div class="stat-icon stat-icon-violet"><i class="bi bi-currency-rupee"></i></div>
        <div class="stat-label">Total Amount</div>
        <div class="stat-value">₹<?php echo e(number_format($items->sum('line_total'), 0)); ?></div>
    </div>
    <div class="admin-stat-card stat-accent-amber">
        <div class="stat-icon stat-icon-amber"><i class="bi bi-box-seam"></i></div>
        <div class="stat-label">Unique Products</div>
        <div class="stat-value"><?php echo e($items->pluck('product_name')->unique()->count()); ?></div>
    </div>
</div>
<?php endif; ?>

<div class="admin-card admin-table-card">
    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>PO Ref</th>
                    <th>Plant</th>
                    <th>Supplier</th>
                    <th>Product</th>
                    <th class="text-end">Qty</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Line Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-nowrap text-muted">
                            <?php echo e($item->ordered_at ? \Carbon\Carbon::parse($item->ordered_at)->format('d M Y') : '—'); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('ho.purchases.show', $item->purchase_id)); ?>" class="fw-semibold">
                                <?php echo e($item->reference_no); ?>

                            </a>
                        </td>
                        <td><?php echo e($item->plant_name); ?></td>
                        <td class="text-muted"><?php echo e($item->supplier_name ?? '—'); ?></td>
                        <td class="fw-semibold"><?php echo e($item->product_name); ?></td>
                        <td class="text-end"><?php echo e(number_format($item->quantity, 0)); ?></td>
                        <td class="text-end text-muted">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                        <td class="text-end fw-semibold text-success">₹<?php echo e(number_format($item->line_total, 2)); ?></td>
                        <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => \App\Enums\PurchaseStatus::from($item->status)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\App\Enums\PurchaseStatus::from($item->status))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo $__env->make('partials.table-empty', [
                        'colspan' => 9,
                        'icon'    => 'bi-journal-text',
                        'message' => 'No purchase items found for this category.',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </tbody>
            <?php if($items->isNotEmpty()): ?>
            <tfoot class="table-light fw-bold">
                <tr>
                    <td colspan="5">Total</td>
                    <td class="text-end"><?php echo e(number_format($items->sum('quantity'), 0)); ?></td>
                    <td></td>
                    <td class="text-end text-success">₹<?php echo e(number_format($items->sum('line_total'), 2)); ?></td>
                    <td></td>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($portalLayout ?? 'layouts.ho', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\office\panchmukhi\resources\views\ho\reports\category-purchase-ledger.blade.php ENDPATH**/ ?>